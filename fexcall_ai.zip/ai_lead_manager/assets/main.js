$(function () {
    $('.ai-lead-manager').on('click', function (e) {
        e.preventDefault();
    });

    initDataTable('.table-alm_call_logs', admin_url + '/ai_lead_manager/call_logs/table', [], [], [], [0, 'desc']);

    $('#vapi_ai_is_custom_voice_id').on('change', function () {
        if ($(this).is(':checked')) {
            $('#vapi_custom_id_input').show();
            $('#vapi_agent_voice_select').hide();
        } else {
            $('#vapi_custom_id_input').hide();
            $('#vapi_agent_voice_select').show();
        }
    });

    $('select[name="settings[vapi_ai_voice_provider]"]').on('change', function () {
        let provider_id = $('select[name="settings[vapi_ai_voice_provider]"]').val();
        requestGet('ai_lead_manager/get_vapi_voices/' + provider_id).done(function (response) {
            response = JSON.parse(response);
            const $select = $('select[name="settings[vapi_ai_agent_voice]"]');
            $select.empty();

            response.forEach(option => {
                if (option.previewUrl) {
                    $select.append(`<option value="${option.providerId}" data-subtext="${option.gender}" data-preview-url="${option.previewUrl}">${option.name.charAt(0).toUpperCase() + option.name.slice(1)}</option>`);
                } else {
                    $select.append(`<option value="${option.providerId}" data-subtext="${option.provider}">${option.name.charAt(0).toUpperCase() + option.name.slice(1)}</option>`);
                }
            });

            $select.selectpicker('refresh');

        }).fail(function (data) {
            $('#general_modal').modal('hide');
            alert_float('danger', data.responseText);
        });
    });

    $("#vapi_ai_temperature").on("input", function () {
        $("input[name='settings[vapi_ai_temperature]']").val(parseFloat($(this).val()).toFixed(1));
    });

    $("#bland_ai_temperature").on("input", function () {
        $("input[name='settings[bland_ai_temperature]']").val(parseFloat($(this).val()).toFixed(1));
    });
});

/**
 * Function to initialize the call log modal.
 * @param {Number} call_log_id ID of the call log to load
 */
function init_alm_call_log_modal(call_log_id) {
    var $callModal = $('#alm_call_log_modal_view');
    if ($callModal.is(':visible')) {
        $callModal.modal('hide');
    }
    requestGet('ai_lead_manager/call_logs/get_call_data/' + call_log_id).done(function (response) {
        var t = $("#alm_call_log_div").html(response);
        setTimeout(function () {
            t.find('#alm_call_log_modal_view').modal({ show: true, backdrop: 'static' });
        }, 150);

    }).fail(function (data) {
        $('#general_modal').modal('hide');
        alert_float('danger', data.responseText);
    });
}

/**
 * Play the preview audio for the selected voice for Bland AI.
 *
 * The selected voice ID is obtained from the select field.
 * The preview text is "Hey there, this is Blandie. How are you doing today?"
 * The response type is "stream".
 *
 * @return {boolean} false
 */
function play_selected_voice_bland() {
    const voiceId = $('select[name="settings[bland_ai_agent_voice]"]').val();
    const options = {
        method: 'POST',
        headers: {
            authorization: $('input[name="settings[bland_ai_api_key]"]').val(),
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            text: "Hey there, this is Blandie. How are you doing today?",
            response_type: "stream"
        })
    };

    fetch(`https://api.bland.ai/v1/voices/${voiceId}/sample`, options)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status} - ${response.statusText}`);
            }
            return response.blob(); // Handle binary response as a Blob
        })
        .then(blob => {
            const audioUrl = URL.createObjectURL(blob); // Create a URL for the audio
            const audio = new Audio(audioUrl); // Create a new audio element
            audio.play() // Play the audio
                .then(() => console.log('Audio is playing...'))
                .catch(err => console.error('Error playing audio:', err));
        })
        .catch(err => console.error('Fetch error:', err));
    return false;
}

/**
 * Play the preview audio for the selected voice for Vapi AI.
 *
 * The preview URL is obtained from the selected option in the select field.
 * The audio is played using the Audio() constructor and the play() method.
 *
 * @return {boolean} false
 */
function play_selected_voice_vapi() {
    const selectedOption = $('select[name="settings[vapi_ai_agent_voice]"]').find('option:selected');
    const previewUrl = selectedOption.data('preview-url');
    const audio = new Audio(previewUrl); // Create a new audio element
    audio.play() // Play the audio
        .then(() => console.log('Audio is playing...'))
        .catch(err => console.error('Error playing audio:', err));

    return false;
}

/**
 * Copies the given text to the user's clipboard.
 *
 * Uses the Clipboard API (navigator.clipboard) if supported, otherwise logs an error.
 *
 * @param {string} text - The text to copy to the clipboard.
 */
alm_copy_to_clipboard = function (text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(function () {
            alert_float("success", "Copied to clipboard");
        }).catch(function (err) {
            console.error('Failed to copy text: ', err);
        });
    } else {
        console.error('Clipboard API not supported!');
    }
};

// Make Call functionality
$(document).ready(function() {
    var currentLeadId = null;
    
    setTimeout(function() {        
        var makeCallButtons = $('.make-call-btn');
        
        if (makeCallButtons.length > 0) {
            makeCallButtons.each(function(index) {
            });
        }
    }, 3000);

    // Handle Make Call button clicks in leads table (using proper event delegation for DataTables)
    $(document).on('click', '.make-call-btn', function(e) {
        e.preventDefault();
        e.stopPropagation(); // Prevent any parent row events
        
        currentLeadId = $(this).data('lead-id');
        
        if (currentLeadId) {
            $('#make_call_modal').modal('show');
            $('#custom_task').val('');
            $('#call_status').hide();
            resetCallButton();
        } else {
            alert_float('danger', 'Unable to identify lead. Please refresh the page and try again.');
        }
    });

    // Handle Make Call button clicks in lead profile
    $(document).on('click', '.make-call-btn-profile', function(e) {
        e.preventDefault();
        currentLeadId = $(this).data('lead-id');
        $('#make_call_modal').modal('show');
        $('#custom_task').val('');
        $('#call_status').hide();
        resetCallButton();
    });

    // Handle confirm make call
    $('#confirm_make_call').on('click', function() {
        if (!currentLeadId) {
            alert_float('danger', 'No lead selected');
            return;
        }

        var customTask = $('#custom_task').val().trim();
        var $button = $(this);
        var originalText = $button.html();

        // Update button to show loading
        $button.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Making Call...');
        $('#call_status').hide();

        // Make AJAX call
        $.ajax({
            url: admin_url + 'ai_lead_manager/make_call',
            type: 'POST',
            data: {
                lead_id: currentLeadId,
                custom_task: customTask
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    $('#call_status').removeClass('alert-danger').addClass('alert-success')
                        .html('<i class="fa fa-check-circle"></i> ' + response.message).show();
                    
                    // Update button to show success
                    $button.html('<i class="fa fa-check"></i> Call Initiated');
                    
                    // Auto close modal after 2 seconds
                    setTimeout(function() {
                        $('#make_call_modal').modal('hide');
                        alert_float('success', 'AI call initiated successfully');
                    }, 2000);
                } else {
                    $('#call_status').removeClass('alert-success').addClass('alert-danger')
                        .html('<i class="fa fa-exclamation-triangle"></i> ' + response.message).show();
                    resetCallButton();
                }
            },
            error: function(xhr, status, error) {
                $('#call_status').removeClass('alert-success').addClass('alert-danger')
                    .html('<i class="fa fa-exclamation-triangle"></i> Error: Failed to initiate call').show();
                resetCallButton();
            }
        });
    });

    function resetCallButton() {
        $('#confirm_make_call').prop('disabled', false).html('<i class="fa fa-phone"></i> Make Call');
    }

    // Reset modal when closed
    $('#make_call_modal').on('hidden.bs.modal', function() {
        currentLeadId = null;
        $('#custom_task').val('');
        $('#call_status').hide();
        resetCallButton();
    });
});

// Knowledge Base File Selection and Edit functionality
$(document).ready(function() {
    // Load available files when knowledge base modal is opened
    $('#vapi_ai_kwnowledgebase_modal').on('show.bs.modal', function() {
        loadAvailableFiles();
    });

    // Handle form submission for both create and update
    $('#knowledgebase_form').on('submit', function(e) {
        e.preventDefault();
        
        var kbId = $('input[name="kb_id"]').val();
        var actionUrl = kbId ? 
            admin_url + 'ai_lead_manager/update_knowledgebase/vapi' : 
            admin_url + 'ai_lead_manager/create_knowledgebase/vapi';
        
        $(this).attr('action', actionUrl);
        this.submit();
    });

    // Reset modal when closed
    $('#vapi_ai_kwnowledgebase_modal').on('hidden.bs.modal', function() {
        resetKnowledgeBaseModal();
    });

    function loadAvailableFiles() {
        $('#available_files_list').html('<p class="text-muted">Loading available files...</p>');
        
        $.ajax({
            url: admin_url + 'ai_lead_manager/get_available_files/vapi',
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success && response.files) {
                    displayAvailableFiles(response.files);
                } else {
                    $('#available_files_list').html('<p class="text-danger">Failed to load files. Please try again.</p>');
                }
            },
            error: function() {
                $('#available_files_list').html('<p class="text-danger">Error loading files. Please try again.</p>');
            }
        });
    }

    function displayAvailableFiles(files) {
        var html = '';
        
        if (files.length === 0) {
            html = '<p class="text-muted">No files available. Please upload files first.</p>';
        } else {
            html = '<div class="row">';
            files.forEach(function(file, index) {
                html += '<div class="col-md-12 mb-2">';
                html += '<label class="checkbox-inline">';
                html += '<input type="checkbox" name="selected_files[]" value="' + file.id + '" id="file_' + index + '">';
                html += ' <strong>' + file.name + '</strong>';
                if (file.size) {
                    html += ' <span class="text-muted">(' + formatFileSize(file.size) + ')</span>';
                }
                html += '</label>';
                html += '</div>';
            });
            html += '</div>';
        }
        
        $('#available_files_list').html(html);
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        var k = 1024;
        var sizes = ['Bytes', 'KB', 'MB', 'GB'];
        var i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    function resetKnowledgeBaseModal() {
        $('#kb_id').val('');
        $('#kb_name').val('');
        $('#kb_description').val('');
        $('#knowledgeBaseModalLabel').text('Create Knowledge Base');
        $('#kb_submit_btn').text('Create Knowledge Base');
        $('input[name="selected_files[]"]').prop('checked', false);
    }

    // Handle edit knowledge base button clicks using event delegation
    $(document).on('click', '.edit-kb-btn', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        var $button = $(this);
        var id = $button.attr('data-kb-id');
        var name = $button.attr('data-kb-name');
        var description = $button.attr('data-kb-description');
        var fileIds = [];
        
        // Parse fileIds safely
        var fileIdsJson = $button.attr('data-kb-fileids');
        if (fileIdsJson) {
            try {
                fileIds = JSON.parse(fileIdsJson);
            } catch (e) {
                console.log('Error parsing fileIds:', e);
                fileIds = [];
            }
        }
        
        // Set modal title and button text
        $('#knowledgeBaseModalLabel').text('Edit Knowledge Base');
        $('#kb_submit_btn').text('Update Knowledge Base');
        
        // Fill form fields with debugging
        if ($('input[name="kb_id"]').length) {
            $('input[name="kb_id"]').val(id || '');
        }
        
        if ($('#kb_name').length) {
            $('#kb_name').val(name || '');
        }
        
        if ($('#kb_description').length) {
            $('#kb_description').val(description || '');
        }
        
        // Show modal
        $('#vapi_ai_kwnowledgebase_modal').modal('show');
        
        // Select files after a delay
        setTimeout(function() {
            if (fileIds && fileIds.length > 0) {
                fileIds.forEach(function(fileId) {
                    if (fileId) {
                        $('input[name="selected_files[]"][value="' + fileId + '"]').prop('checked', true);
                    }
                });
            }
        }, 1500);
        
        return false;
    });
});