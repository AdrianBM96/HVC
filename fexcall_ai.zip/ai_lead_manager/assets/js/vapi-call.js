/**
 * VAPI Web SDK Implementation for Direct Browser Voice Calls
 * 
 * This module provides VAPI Web SDK integration for direct browser-to-assistant
 * voice conversations. Users can speak directly with AI assistants through
 * their microphone/speakers without phone numbers.
 * 
 * @author AI Lead Manager
 * @version 2.0.0
 */

class VapiCall {
    constructor(options = {}) {
        this.options = {
            // UI selectors for voice call interface
            startButtonSelector: '#start-voice-call',
            endButtonSelector: '#end-voice-call',
            muteButtonSelector: '#mute-voice-call',
            statusContainerSelector: '#vapi-call-status',
            timerSelector: '#call-timer',
            timerDisplaySelector: '#timer-display',
            transcriptSelector: '#conversation-transcript',
            transcriptContentSelector: '.transcript-content',

            // Call type: 'inbound', 'outbound', or 'default'
            callType: 'default',

            // API endpoints
            publicKeyEndpoint: 'ai_lead_manager/get_vapi_public_key',

            // Default assistant configuration
            defaultConfig: {
                model: {
                    provider: 'openai',
                    model: 'gpt-3.5-turbo',
                    temperature: 0.7,
                    maxTokens: 250
                },
                voice: {
                    provider: '11labs',
                    voiceId: 'burt'
                },
                firstMessage: 'Hi there! I\'m your AI assistant. How can I help you today?',
                systemPrompt: 'You are a helpful AI assistant conducting a voice conversation. Be friendly, professional, and conversational. Keep responses concise but helpful.',
                maxDurationSeconds: 300 // 5 minutes default
            },

            // Event callbacks
            onCallStart: null,
            onCallEnd: null,
            onCallError: null,
            onMessage: null,
            onStatusUpdate: null,

            ...options
        };

        this.vapi = null;
        this.publicApiKey = null;
        this.isCallActive = false;
        this.isMuted = false;
        this.callStartTime = null;
        this.timerInterval = null;
        this.currentConfig = {};

        this.init();
    }

    /**
     * Initialize the VAPI Web SDK system
     */
    async init() {
        try {
            console.log('Initializing VAPI Web SDK...');
            await this.loadPublicApiKey();
            await this.waitForVapiSDK();
            this.initializeVapi();
            this.setupEventListeners();
            this.updateUI();
            console.log('VAPI Web SDK initialized successfully');
        } catch (error) {
            console.error('Failed to initialize VAPI Web SDK:', error);
            this.showStatus('Failed to initialize VAPI system: ' + error.message, 'error');
        }
    }

    /**
     * Wait for VAPI SDK to be loaded (since it loads asynchronously)
     */
    async waitForVapiSDK() {
        return new Promise((resolve, reject) => {
            const checkSDK = () => {
                if (typeof window.vapiSDK !== 'undefined' && typeof window.vapiSDK.run === 'function') {
                    console.log('VAPI SDK loaded successfully');
                    resolve();
                } else {
                    console.log('Waiting for VAPI SDK to load...');
                    setTimeout(checkSDK, 500);
                }
            };

            // Start checking immediately
            checkSDK();

            // Set a timeout to prevent infinite waiting
            setTimeout(() => {
                if (typeof window.vapiSDK === 'undefined') {
                    reject(new Error('VAPI SDK failed to load within timeout period'));
                }
            }, 10000); // 10 second timeout
        });
    }

    /**
     * Load public API key from server
     */
    async loadPublicApiKey() {
        try {
            const endpoint = (typeof admin_url !== 'undefined' ? admin_url : '/admin/') + this.options.publicKeyEndpoint;
            console.log('Loading VAPI public key from:', endpoint);

            const response = await fetch(endpoint, {
                method: 'GET',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            console.log('API key response:', data);

            if (data.success && data.public_key) {
                this.publicApiKey = data.public_key;

                if (data.warning) {
                    this.showStatus(data.warning, 'warning');
                }

                console.log('VAPI public key loaded successfully');
            } else {
                throw new Error(data.message || 'Failed to retrieve public API key');
            }
        } catch (error) {
            console.error('Error loading VAPI public API key:', error);
            throw new Error('Failed to load VAPI public API key: ' + error.message);
        }
    }

    /**
     * Initialize VAPI Web SDK
     */
    initializeVapi() {
        if (typeof window.vapiSDK === 'undefined' || typeof window.vapiSDK.run === 'undefined') {
            throw new Error('VAPI Web SDK not loaded. Please ensure the VAPI HTML script tag is included.');
        }

        if (!this.publicApiKey) {
            throw new Error('Public API key not available');
        }

        try {
            // Extract assistant configuration
            const assistantConfig = this.extractAssistantConfig();

            // Initialize VAPI with public key using HTML script tag method
            this.vapi = window.vapiSDK.run({
                apiKey: this.publicApiKey,
                assistant: assistantConfig,
                config: {
                    // Completely disable the default floating button
                    show: false,
                    // Additional properties to ensure button stays hidden
                    position: "bottom-right",
                    offset: "40px",
                    width: "0px",     // Set to 0 to make it invisible
                    height: "0px",    // Set to 0 to make it invisible
                    idle: {
                        color: `linear-gradient(to top, #D988B9, #B9A9D9)`,
                        type: "pill", // or "round"
                        title: "Have a quick question?", // title that shows when you hover over the button
                        subtitle: "Talk with our AI assistant", // subtitle that shows when you hover over the button
                        icon: `https://unpkg.com/lucide@latest/dist/esm/icons/phone.js`, // icon to show in the button
                    },
                    loading: {
                        color: `linear-gradient(to top, #D988B9, #B9A9D9)`,
                        type: "pill", // or "round"  
                        title: "Connecting...", // title that shows when you hover over the button in loading state
                        subtitle: "Please wait", // subtitle that shows when you hover over the button in loading state
                        icon: `https://unpkg.com/lucide@latest/dist/esm/icons/loader-2.js`, // icon to show in the button in loading state
                    },
                    active: {
                        color: `linear-gradient(to top, #D988B9, #B9A9D9)`,
                        type: "pill", // or "round"
                        title: "Call is in progress...", // title that shows when you hover over the button when call is active
                        subtitle: "End the call.", // subtitle that shows when you hover over the button when call is active
                        icon: `https://unpkg.com/lucide@latest/dist/esm/icons/phone-off.js`, // icon to show in the button when call is active
                    },
                }
            });

            this.setupVapiEventListeners();
            this.hideVapiFloatingButton(); // Ensure floating button is hidden
            this.showStatus('Voice assistant ready', 'success');
        } catch (error) {
            throw new Error('Failed to initialize VAPI Web SDK: ' + error.message);
        }
    }

    /**
     * Hide VAPI floating button completely using CSS and DOM manipulation
     */
    hideVapiFloatingButton() {
        try {
            // Add CSS to hide any VAPI floating buttons
            const style = document.createElement('style');
            style.textContent = `
                /* Hide all VAPI floating buttons */
                .vapi-support-btn,
                #vapi-support-btn,
                [class*="vapi-btn"],
                [id*="vapi-btn"],
                [class*="vapi-widget"],
                [id*="vapi-widget"],
                [class*="vapi-float"],
                [id*="vapi-float"] {
                    display: none !important;
                    visibility: hidden !important;
                    opacity: 0 !important;
                    pointer-events: none !important;
                    z-index: -9999 !important;
                }
                
                /* Hide any iframe or widget containers */
                iframe[src*="vapi"] {
                    display: none !important;
                }
            `;
            document.head.appendChild(style);

            // Also try to find and hide existing buttons
            setTimeout(() => {
                const selectors = [
                    '.vapi-support-btn', '#vapi-support-btn',
                    '[class*="vapi-btn"]', '[id*="vapi-btn"]',
                    '[class*="vapi-widget"]', '[id*="vapi-widget"]',
                    '[class*="vapi-float"]', '[id*="vapi-float"]'
                ];

                selectors.forEach(selector => {
                    const elements = document.querySelectorAll(selector);
                    elements.forEach(element => {
                        element.style.display = 'none';
                        element.style.visibility = 'hidden';
                        element.style.opacity = '0';
                        element.style.pointerEvents = 'none';
                    });
                });
            }, 1000);

        } catch (error) {
            console.warn('Could not hide VAPI floating button:', error);
        }
    }

    /**
     * Setup VAPI Web SDK event listeners
     */
    setupVapiEventListeners() {
        if (!this.vapi) return;

        try {
            // Call lifecycle events
            this.vapi.on('call-start', (data) => {
                console.log('Voice call started:', data);
                this.isCallActive = true;
                this.callStartTime = Date.now();
                this.startTimer();
                this.showStatus('Voice call connected! Start speaking.', 'success');
                this.updateCallUI(true);

                if (this.options.onCallStart) {
                    this.options.onCallStart(data);
                }
            });

            this.vapi.on('call-end', (data) => {
                console.log('Voice call ended:', data);
                this.isCallActive = false;
                this.stopTimer();
                this.showStatus('Voice call ended.', 'info');
                this.updateCallUI(false);

                if (this.options.onCallEnd) {
                    this.options.onCallEnd(data);
                }
            });

            this.vapi.on('error', (error) => {
                console.error('Voice call error:', error);
                this.isCallActive = false;
                this.stopTimer();
                this.showStatus('Voice call error: ' + (error.message || error), 'error');
                this.updateCallUI(false);

                if (this.options.onCallError) {
                    this.options.onCallError(error);
                }
            });

            // Real-time conversation events
            this.vapi.on('message', (message) => {
                console.log('VAPI message:', message);
                this.handleMessage(message);

                if (this.options.onMessage) {
                    this.options.onMessage(message);
                }
            });

            // Voice activity events (may not be available in HTML script tag version)
            if (typeof this.vapi.on === 'function') {
                this.vapi.on('speech-start', () => {
                    this.showStatus('AI is speaking...', 'info');
                });

                this.vapi.on('speech-end', () => {
                    this.showStatus('Listening...', 'info');
                });

                // Volume level updates (optional)
                this.vapi.on('volume-level', (level) => {
                    // Handle volume level updates if needed
                    // level is a float between 0 and 1
                });
            }
        } catch (error) {
            console.warn('Some event listeners may not be available:', error);
        }
    }

    /**
     * Setup UI event listeners
     */
    setupEventListeners() {
        const startButton = document.querySelector(this.options.startButtonSelector);
        const endButton = document.querySelector(this.options.endButtonSelector);
        const muteButton = document.querySelector(this.options.muteButtonSelector);

        if (startButton) {
            startButton.addEventListener('click', (e) => {
                e.preventDefault();
                this.startVoiceCall();
            });
        }

        if (endButton) {
            endButton.addEventListener('click', (e) => {
                e.preventDefault();
                this.endVoiceCall();
            });
        }

        if (muteButton) {
            muteButton.addEventListener('click', (e) => {
                e.preventDefault();
                this.toggleMute();
            });
        }
    }

    /**
     * Extract assistant configuration from form fields based on call type
     */
    extractAssistantConfig() {
        const config = { ...this.options.defaultConfig };

        try {
            // Extract prompt and opening message based on call type
            let systemPrompt, firstMessage;

            if (this.options.callType === 'inbound') {
                // Extract inbound configuration from general settings
                systemPrompt = this.getFormValue('settings[alm_system_prompt]') ||
                    document.getElementById('alm_system_prompt')?.value ||
                    'You are a helpful customer service representative. Be friendly, professional, and assist customers with their inquiries.';

                firstMessage = this.getFormValue('settings[alm_first_sentence]') ||
                    'Hello! Thank you for calling. How can I assist you today?';

                console.log('Inbound config extracted:', { systemPrompt: systemPrompt.substring(0, 100) + '...', firstMessage });

            } else if (this.options.callType === 'outbound') {
                // Extract outbound configuration from general settings
                systemPrompt = this.getFormValue('settings[alm_system_prompt_outbound]') ||
                    document.getElementById('alm_system_prompt_outbound')?.value ||
                    'You are a professional sales representative. Build rapport, understand needs, and provide value. Be consultative and respectful.';

                firstMessage = this.getFormValue('settings[alm_first_sentence_outbound]') ||
                    'Hi! This is [Your Name] calling from [Company Name]. How are you doing today?';

                console.log('Outbound config extracted:', { systemPrompt: systemPrompt.substring(0, 100) + '...', firstMessage });

            } else if (this.options.callType === 'campaign') {
                // Extract configuration from campaign form
                systemPrompt = document.getElementById('assistant_prompt')?.value ||
                    'You are a professional AI assistant conducting outbound calls. Be friendly, professional, and focused on helping prospects.';

                firstMessage = document.querySelector('[name="first_message"]')?.value ||
                    'Hi [name], this is calling from [company]. How can I help you today?';

                console.log('Campaign config extracted:', { systemPrompt: systemPrompt.substring(0, 100) + '...', firstMessage });

            } else {
                // Default/VAPI settings page configuration
                systemPrompt = config.systemPrompt;
                firstMessage = config.firstMessage;
            }

            // Extract core settings for inline assistant configuration
            const maxDuration = this.getFormValue('settings[vapi_ai_max_duration]') ||
                this.getFormValue('settings[alm_max_call_duration]') || 300;
            const temperature = this.getFormValue('settings[vapi_ai_temperature]') || '0.7';
            const maxTokens = this.getFormValue('settings[vapi_ai_max_tokens]') || '250';

            // Extract voice settings with better defaults
            let voiceProvider = this.getFormValue('settings[vapi_ai_voice_provider]') || '11labs';
            let agentVoice = this.getFormValue('settings[vapi_ai_agent_voice]') || 'burt';
            const customVoiceId = this.getFormValue('settings[vapi_ai_agent_voice_id]');
            const isCustomVoice = this.getCheckboxValue('settings[vapi_ai_is_custom_voice_id]');

            // Fix voice provider/ID mismatch - ensure compatibility
            if (voiceProvider === 'openai' && agentVoice === 'burt') {
                // burt is ElevenLabs voice, use OpenAI voice instead
                agentVoice = 'alloy';  // OpenAI default voice
            } else if (voiceProvider === '11labs' && agentVoice === 'burt') {
                // Keep as is - burt is valid ElevenLabs voice
                voiceProvider = '11labs';
            }

            // Extract feature toggles
            const fillerInjection = this.getCheckboxValue('filler_injection_enabled');
            const backChanneling = this.getCheckboxValue('back_channeling_enabled');
            const emotionDetection = this.getCheckboxValue('vapi_ai_detect_emotions');

            // Extract tools based on call type
            let selectedTools = [];
            let selectedKnowledgeBases = [];

            if (this.options.callType === 'inbound') {
                // Get inbound tools and knowledge bases
                const inboundTools = this.getFormValue('settings[vapi_ai_tools_inbound]');
                const inboundKBs = this.getFormValue('settings[vapi_ai_knowledgebase_inbound]');

                if (inboundTools) {
                    try {
                        selectedTools = JSON.parse(inboundTools);
                    } catch (e) {
                        console.warn('Failed to parse inbound tools:', e);
                    }
                }

                if (inboundKBs) {
                    try {
                        selectedKnowledgeBases = JSON.parse(inboundKBs);
                    } catch (e) {
                        console.warn('Failed to parse inbound knowledge bases:', e);
                    }
                }

            } else if (this.options.callType === 'outbound') {
                // Get outbound tools and knowledge bases
                const outboundTools = this.getFormValue('settings[vapi_ai_tools_outbound]');
                const outboundKBs = this.getFormValue('settings[vapi_ai_knowledgebase_outbound]');

                if (outboundTools) {
                    try {
                        selectedTools = JSON.parse(outboundTools);
                    } catch (e) {
                        console.warn('Failed to parse outbound tools:', e);
                    }
                }

                if (outboundKBs) {
                    try {
                        selectedKnowledgeBases = JSON.parse(outboundKBs);
                    } catch (e) {
                        console.warn('Failed to parse outbound knowledge bases:', e);
                    }
                }

            } else if (this.options.callType === 'campaign') {
                // For campaign calls, check if any knowledge bases are selected in the form
                const selectedKBCheckboxes = document.querySelectorAll('input[name="knowledge_bases[]"]:checked');
                if (selectedKBCheckboxes.length > 0) {
                    selectedKnowledgeBases = Array.from(selectedKBCheckboxes).map(cb => cb.value);
                }

                // Note: Campaign page doesn't currently have tool selection UI, 
                // but we can extend this later if needed
                console.log('Campaign tools/KB extracted:', { selectedKnowledgeBases });
            }

            // Replace template variables in firstMessage
            let processedFirstMessage = firstMessage;

            // Replace {company_name} 
            if (processedFirstMessage.includes('{company_name}')) {
                const companyName = this.getFormValue('settings[company_name]') ||
                    document.querySelector('input[name="settings[company_name]"]')?.value ||
                    'our company';
                processedFirstMessage = processedFirstMessage.replace(/\{company_name\}/g, companyName);
            }

            // Replace [company] (campaign form format)
            if (processedFirstMessage.includes('[company]')) {
                const companyName = this.getFormValue('settings[company_name]') ||
                    document.querySelector('input[name="settings[company_name]"]')?.value ||
                    'our company';
                processedFirstMessage = processedFirstMessage.replace(/\[company\]/g, companyName);
            }

            // Replace [name] with test placeholder for campaign calls
            if (processedFirstMessage.includes('[name]') && this.options.callType === 'campaign') {
                processedFirstMessage = processedFirstMessage.replace(/\[name\]/g, 'there');
            }

            console.log('Voice settings extracted:', {
                voiceProvider, agentVoice, temperature, maxTokens,
                systemPrompt: systemPrompt.substring(0, 100) + '...',
                originalFirstMessage: firstMessage,
                processedFirstMessage: processedFirstMessage,
                selectedTools: selectedTools,
                selectedKnowledgeBases: selectedKnowledgeBases
            });

            // Build inline assistant configuration - VAPI expected format
            const assistantConfig = {
                model: {
                    provider: 'openai',
                    model: 'gpt-3.5-turbo',
                    temperature: parseFloat(temperature),
                    maxTokens: parseInt(maxTokens),
                    messages: [
                        {
                            role: 'system',
                            content: systemPrompt
                        }
                    ]
                },
                voice: {
                    provider: voiceProvider,
                    voiceId: (isCustomVoice && customVoiceId) ? customVoiceId : agentVoice
                },
                firstMessage: processedFirstMessage,
                firstMessageMode: 'assistant-speaks-first',  // Ensure assistant speaks first
                silenceTimeoutSeconds: 30,  // Give more time before timing out
                maxDurationSeconds: parseInt(maxDuration),
                backgroundSound: 'off'  // Disable background sounds for cleaner experience
            };

            // Add tools if any are selected - VAPI expects toolIds in model object
            if (selectedTools && selectedTools.length > 0) {
                if (!assistantConfig.model.toolIds) {
                    assistantConfig.model.toolIds = [];
                }
                assistantConfig.model.toolIds = assistantConfig.model.toolIds.concat(selectedTools);
                console.log('Added tool IDs to model config:', selectedTools);
            }

            // Add knowledge base tools if any are selected
            if (selectedKnowledgeBases && selectedKnowledgeBases.length > 0) {
                // Knowledge bases are also tools in VAPI, so we add them to model.toolIds
                if (!assistantConfig.model.toolIds) {
                    assistantConfig.model.toolIds = [];
                }
                assistantConfig.model.toolIds = assistantConfig.model.toolIds.concat(selectedKnowledgeBases);
                console.log('Added knowledge base tool IDs to model config:', selectedKnowledgeBases);
                console.log('Total tool IDs in model:', assistantConfig.model.toolIds);
            }

            // Add advanced features if enabled
            if (fillerInjection) {
                assistantConfig.fillerInjectionEnabled = true;
            }

            if (backChanneling) {
                assistantConfig.backchannelingEnabled = true;
            }

            if (emotionDetection) {
                assistantConfig.emotionRecognitionEnabled = true;
            }

            // Set max duration if specified
            if (maxDuration) {
                assistantConfig.maxDurationSeconds = parseInt(maxDuration);
            }

            console.log('=== COMPLETE ASSISTANT CONFIG ===');
            console.log('Call Type:', this.options.callType);
            console.log('Full Assistant Config:', JSON.stringify(assistantConfig, null, 2));
            console.log('=== CONFIG DETAILS ===');
            console.log('- System Prompt Length:', systemPrompt.length);
            console.log('- Original First Message:', firstMessage);
            console.log('- Processed First Message:', processedFirstMessage);
            console.log('- Voice Provider:', voiceProvider);
            console.log('- Voice ID:', (isCustomVoice && customVoiceId) ? customVoiceId : agentVoice);
            console.log('- Temperature:', parseFloat(temperature));
            console.log('- Max Tokens:', parseInt(maxTokens));
            console.log('- Max Duration:', parseInt(maxDuration));
            console.log('- Selected Tools:', selectedTools);
            console.log('- Selected Knowledge Bases:', selectedKnowledgeBases);
            console.log('- Total Tool IDs in Model:', assistantConfig.model.toolIds || 'None');
            console.log('===============================');

            this.currentConfig = assistantConfig;
            return assistantConfig;

        } catch (error) {
            console.error('Error extracting assistant configuration:', error);
            this.showStatus('Error reading assistant configuration: ' + error.message, 'error');
            return config;
        }
    }

    /**
     * Get value from form field
     */
    getFormValue(selector) {
        const element = document.querySelector(`[name="${selector}"]`);
        if (element) {
            return element.value.trim();
        }

        // For multi-select fields, try to get selected values
        const multiSelect = document.querySelector(`select[name="${selector}[]"]`);
        if (multiSelect && multiSelect.multiple) {
            const selectedValues = Array.from(multiSelect.selectedOptions).map(option => option.value);
            return JSON.stringify(selectedValues);
        }

        return '';
    }

    /**
     * Get checkbox value
     */
    getCheckboxValue(selector) {
        const element = document.querySelector(`[name="${selector}"]`) ||
            document.querySelector(`#${selector}`);
        return element ? element.checked : false;
    }

    /**
     * Start a voice call with the AI assistant
     */
    async startVoiceCall() {
        if (!this.vapi) {
            this.showStatus('VAPI system not initialized. Please check your configuration.', 'error');
            return;
        }

        if (this.isCallActive) {
            this.showStatus('A voice call is already in progress.', 'warning');
            return;
        }

        try {
            this.showStatus('Starting voice call...', 'info');
            this.updateCallUI(true, 'starting');

            // Extract fresh assistant configuration with current form values
            const assistantConfig = this.extractAssistantConfig();
            console.log('=== STARTING CALL WITH CONFIG ===');
            console.log('VAPI object available:', !!this.vapi);
            console.log('VAPI start method available:', typeof this.vapi.start === 'function');
            console.log('Using assistant config:', assistantConfig);

            // For HTML script tag version, try different methods to start the call
            if (typeof this.vapi.start === 'function') {
                // Standard SDK method
                console.log('Using VAPI.start() method...');
                await this.vapi.start(assistantConfig);
            } else if (typeof this.vapi.click === 'function') {
                // HTML script tag method - simulate button click
                console.log('Using VAPI.click() method...');
                this.vapi.click();
            } else {
                // Try to find and click the hidden VAPI button
                console.log('Attempting to start call through VAPI widget...');
                const vapiButton = document.querySelector('.vapi-support-btn, #vapi-support-btn, [class*="vapi-btn"], [id*="vapi-btn"]');

                if (vapiButton) {
                    console.log('Found VAPI button, clicking it...');
                    // Temporarily show the button for clicking
                    vapiButton.style.display = 'block';
                    vapiButton.style.visibility = 'visible';
                    vapiButton.style.opacity = '1';

                    // Click the button
                    vapiButton.click();

                    // Hide it again immediately
                    setTimeout(() => {
                        vapiButton.style.display = 'none';
                        vapiButton.style.visibility = 'hidden';
                        vapiButton.style.opacity = '0';
                    }, 100);
                } else {
                    console.log('No VAPI button found, trying alternative method...');
                    this.showStatus('Initializing voice call...', 'info');

                    // Set a timeout to check if call started
                    setTimeout(() => {
                        if (!this.isCallActive) {
                            this.showStatus('Unable to start call automatically. Please ensure VAPI is properly configured.', 'error');
                            this.updateCallUI(false);
                        }
                    }, 3000);
                }
            }

        } catch (error) {
            console.error('Voice call failed:', error);
            this.showStatus('Failed to start voice call: ' + error.message, 'error');
            this.updateCallUI(false);
        }
    }

    /**
     * End active voice call
     */
    endVoiceCall() {
        if (!this.vapi) {
            this.showStatus('No active voice call to end.', 'warning');
            return;
        }

        try {
            // Try different methods to end the call
            if (typeof this.vapi.stop === 'function') {
                this.vapi.stop();
            } else if (typeof this.vapi.end === 'function') {
                this.vapi.end();
            } else if (typeof this.vapi.hangup === 'function') {
                this.vapi.hangup();
            } else {
                console.warn('No known method to end call found');
                this.showStatus('Please end call using VAPI widget or wait for natural end.', 'warning');
            }

            // The call-end event will handle cleanup
        } catch (error) {
            console.error('Failed to end voice call:', error);
            this.showStatus('Failed to end voice call: ' + error.message, 'error');
        }
    }

    /**
     * Toggle mute/unmute
     */
    toggleMute() {
        if (!this.vapi || !this.isCallActive) {
            return;
        }

        try {
            this.isMuted = !this.isMuted;

            // Try different mute methods
            if (typeof this.vapi.setMuted === 'function') {
                this.vapi.setMuted(this.isMuted);
            } else if (typeof this.vapi.mute === 'function') {
                if (this.isMuted) {
                    this.vapi.mute();
                } else {
                    this.vapi.unmute();
                }
            } else {
                console.warn('Mute functionality not available in this VAPI version');
                this.showStatus('Mute functionality not available', 'warning');
                return;
            }

            const muteButton = document.querySelector(this.options.muteButtonSelector);
            if (muteButton) {
                if (this.isMuted) {
                    muteButton.innerHTML = '<i class="fa fa-microphone fa-lg"></i> Unmute';
                    muteButton.classList.remove('btn-warning');
                    muteButton.classList.add('btn-info');
                } else {
                    muteButton.innerHTML = '<i class="fa fa-microphone-slash fa-lg"></i> Mute';
                    muteButton.classList.remove('btn-info');
                    muteButton.classList.add('btn-warning');
                }
            }

            this.showStatus(this.isMuted ? 'Microphone muted' : 'Microphone unmuted', 'info');
        } catch (error) {
            console.error('Failed to toggle mute:', error);
            this.showStatus('Failed to toggle mute: ' + error.message, 'error');
        }
    }

    /**
     * Handle real-time messages from VAPI
     */
    handleMessage(message) {
        if (message.type === 'transcript') {
            this.addTranscriptMessage(message.role, message.transcript);
        } else if (message.type === 'function-call') {
            console.log('Function call:', message);
        } else if (message.type === 'hang') {
            this.showStatus('Call ended by assistant', 'info');
        }
    }

    /**
     * Add message to conversation transcript
     */
    addTranscriptMessage(role, text) {
        const transcriptContainer = document.querySelector(this.options.transcriptSelector);
        const transcriptContent = document.querySelector(this.options.transcriptContentSelector);

        if (!transcriptContent) return;

        // Show transcript container if hidden
        if (transcriptContainer) {
            transcriptContainer.style.display = 'block';
        }

        // Create message element
        const messageDiv = document.createElement('div');
        messageDiv.style.marginBottom = '10px';
        messageDiv.innerHTML = `
            <strong>${role === 'user' ? 'You' : 'Assistant'}:</strong> 
            <span style="margin-left: 10px;">${text}</span>
        `;

        if (role === 'user') {
            messageDiv.style.color = '#007bff';
        } else {
            messageDiv.style.color = '#28a745';
        }

        transcriptContent.appendChild(messageDiv);

        // Auto-scroll to bottom
        transcriptContent.scrollTop = transcriptContent.scrollHeight;
    }

    /**
     * Start call timer
     */
    startTimer() {
        const timerElement = document.querySelector(this.options.timerSelector);
        const displayElement = document.querySelector(this.options.timerDisplaySelector);

        if (timerElement) {
            timerElement.style.display = 'block';
        }

        this.timerInterval = setInterval(() => {
            if (this.callStartTime && displayElement) {
                const elapsed = Math.floor((Date.now() - this.callStartTime) / 1000);
                const minutes = Math.floor(elapsed / 60);
                const seconds = elapsed % 60;
                displayElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }
        }, 1000);
    }

    /**
     * Stop call timer
     */
    stopTimer() {
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
            this.timerInterval = null;
        }

        const timerElement = document.querySelector(this.options.timerSelector);
        if (timerElement) {
            timerElement.style.display = 'none';
        }
    }

    /**
     * Update UI based on call state
     */
    updateUI() {
        const startButton = document.querySelector(this.options.startButtonSelector);

        if (!startButton) return;

        const hasVapi = this.vapi !== null;
        const hasApiKey = this.publicApiKey && this.publicApiKey.length > 0;

        startButton.disabled = !(hasVapi && hasApiKey) || this.isCallActive;

        // Update button text based on state
        if (!hasApiKey) {
            startButton.innerHTML = '<i class="fa fa-key"></i> API Key Required';
        } else if (!hasVapi) {
            startButton.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Initializing...';
        } else if (this.isCallActive) {
            startButton.innerHTML = '<i class="fa fa-microphone"></i> Call Active';
        } else {
            startButton.innerHTML = '<i class="fa fa-microphone fa-lg"></i> Start Voice Call';
        }
    }

    /**
     * Update call-specific UI elements
     */
    updateCallUI(isActive, state = null) {
        const startButton = document.querySelector(this.options.startButtonSelector);
        const endButton = document.querySelector(this.options.endButtonSelector);
        const muteButton = document.querySelector(this.options.muteButtonSelector);

        if (startButton) {
            if (state === 'starting') {
                startButton.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Connecting...';
                startButton.disabled = true;
            } else if (isActive) {
                startButton.innerHTML = '<i class="fa fa-microphone"></i> Call Active';
                startButton.disabled = true;
            } else {
                this.updateUI(); // Reset to normal state
            }
        }

        if (endButton) {
            endButton.style.display = isActive ? 'inline-block' : 'none';
        }

        if (muteButton) {
            muteButton.style.display = isActive ? 'inline-block' : 'none';
            if (!isActive) {
                // Reset mute button state
                this.isMuted = false;
                muteButton.innerHTML = '<i class="fa fa-microphone-slash fa-lg"></i> Mute';
                muteButton.classList.remove('btn-info');
                muteButton.classList.add('btn-warning');
            }
        }
    }

    /**
     * Show status message
     */
    showStatus(message, type = 'info') {
        const statusContainer = document.querySelector(this.options.statusContainerSelector);

        if (!statusContainer) {
            console.log(`[VAPI Status - ${type.toUpperCase()}]:`, message);
            return;
        }

        // Clear existing classes
        statusContainer.className = statusContainer.className.replace(/alert-\w+/g, '');

        // Add appropriate alert class
        const alertClass = {
            'success': 'alert-success',
            'info': 'alert-info',
            'warning': 'alert-warning',
            'error': 'alert-danger'
        }[type] || 'alert-info';

        statusContainer.classList.add('alert', alertClass);

        // Add icon based on type
        const icon = {
            'success': 'fa-check-circle',
            'info': 'fa-info-circle',
            'warning': 'fa-exclamation-triangle',
            'error': 'fa-times-circle'
        }[type] || 'fa-info-circle';

        statusContainer.innerHTML = `<i class="fa ${icon}"></i> ${message}`;
        statusContainer.style.display = 'block';

        // Auto-hide info messages after 5 seconds
        if (type === 'info') {
            setTimeout(() => {
                statusContainer.style.display = 'none';
            }, 5000);
        }

        // Trigger callback if provided
        if (this.options.onStatusUpdate) {
            this.options.onStatusUpdate(message, type);
        }
    }

    /**
     * Get current call status
     */
    getCallStatus() {
        return {
            isActive: this.isCallActive,
            isMuted: this.isMuted,
            hasVapi: this.vapi !== null,
            hasApiKey: this.publicApiKey !== null,
            callDuration: this.callStartTime ? Math.floor((Date.now() - this.callStartTime) / 1000) : 0,
            config: this.currentConfig
        };
    }

    /**
     * Update configuration dynamically
     */
    updateConfig(newConfig) {
        this.options.defaultConfig = {
            ...this.options.defaultConfig,
            ...newConfig
        };
    }

    /**
     * Destroy the VAPI call instance
     */
    destroy() {
        if (this.isCallActive) {
            this.endVoiceCall();
        }

        this.stopTimer();

        // Remove event listeners
        const startButton = document.querySelector(this.options.startButtonSelector);
        const endButton = document.querySelector(this.options.endButtonSelector);
        const muteButton = document.querySelector(this.options.muteButtonSelector);

        [startButton, endButton, muteButton].forEach(button => {
            if (button) {
                button.removeEventListener('click', () => { });
            }
        });

        this.vapi = null;
        this.publicApiKey = null;
        this.isCallActive = false;
    }
}

// Global instance for easy access
window.VapiCall = VapiCall;

// Auto-initialize if default elements are present
document.addEventListener('DOMContentLoaded', function () {
    // Check if we're on the general settings page with test call buttons
    if (document.querySelector('#start-inbound-test-call') || document.querySelector('#start-outbound-test-call')) {

        // Initialize Inbound Test Call Instance
        if (document.querySelector('#start-inbound-test-call')) {
            window.vapiInboundInstance = new VapiCall({
                startButtonSelector: '#start-inbound-test-call',
                endButtonSelector: '#end-inbound-test-call',
                muteButtonSelector: '#mute-inbound-test-call',
                statusContainerSelector: '#inbound-call-status',
                timerSelector: '#inbound-call-timer',
                timerDisplaySelector: '#inbound-timer-display',
                transcriptSelector: '#inbound-conversation-transcript',
                transcriptContentSelector: '.inbound-transcript-content',
                callType: 'inbound'
            });

            console.log('VAPI Inbound Test Call system initialized');
        }

        // Initialize Outbound Test Call Instance
        if (document.querySelector('#start-outbound-test-call')) {
            window.vapiOutboundInstance = new VapiCall({
                startButtonSelector: '#start-outbound-test-call',
                endButtonSelector: '#end-outbound-test-call',
                muteButtonSelector: '#mute-outbound-test-call',
                statusContainerSelector: '#outbound-call-status',
                timerSelector: '#outbound-call-timer',
                timerDisplaySelector: '#outbound-timer-display',
                transcriptSelector: '#outbound-conversation-transcript',
                transcriptContentSelector: '.outbound-transcript-content',
                callType: 'outbound'
            });

            console.log('VAPI Outbound Test Call system initialized');
        }

    } else if (document.querySelector('#start-campaign-test-call')) {

        // Initialize Campaign Test Call Instance
        window.vapiCampaignInstance = new VapiCall({
            startButtonSelector: '#start-campaign-test-call',
            endButtonSelector: '#end-campaign-test-call',
            muteButtonSelector: '#mute-campaign-test-call', // Optional, not in current UI
            statusContainerSelector: '#campaign-call-status', // Optional, can be added if needed
            callType: 'campaign' // New call type for campaigns
        });

        console.log('VAPI Campaign Test Call system initialized');

    } else if (document.querySelector('#start-voice-call') ||
        document.querySelector('[name="settings[vapi_ai_api_key]"]')) {

        // Initialize with default options for VAPI settings page
        window.vapiCallInstance = new VapiCall();

        console.log('VAPI Web SDK voice call system initialized');
    }
});

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = VapiCall;
}