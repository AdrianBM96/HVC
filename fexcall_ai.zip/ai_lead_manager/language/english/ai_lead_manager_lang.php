<?php
defined('BASEPATH') or exit('No direct script access allowed');

// Call logs
$lang['alm_call_log'] = 'Call log';
$lang['alm_call_logs'] = 'AI Call logs';
$lang['alm_call_log_call_id'] = 'Call ID';
$lang['alm_call_log_created_at'] = 'Created at';
$lang['alm_call_log_direction'] = 'Direction';
$lang['alm_call_log_to_number'] = 'To';
$lang['alm_call_log_from_number'] = 'From';
$lang['alm_call_log_recording'] = 'Recording';
$lang['alm_call_log_status'] = 'Status';
$lang['alm_call_log_duration'] = 'Duration';
$lang['alm_call_log_ended_reason'] = 'Ended Reason';
$lang['leads_dt_last_call_ended_reason'] = 'Last Call Ended Reason';
$lang['alm_call_log_price'] = 'Price';
$lang['alm_call_started_at'] = 'Started at';
$lang['alm_call_log_details'] = 'Call Details';
$lang['alm_call_log_summary'] = 'Summary';
$lang['alm_call_log_transcripts'] = 'Transcripts';
$lang['alm_call_log_lead'] = 'Lead';
$lang['alm_call_log_inbound'] = 'Inbound';
$lang['alm_call_log_outbound'] = 'Outbound';
$lang['alm_call_log_total_calls_today'] = 'Total Calls Today';
$lang['alm_call_log_total_calls_yesterday'] = 'Total Calls Yesterday';

// AI Settings
$lang['vapi_ai_detect_emotions'] = 'Detect Emotions';
$lang['filler_injection_enabled'] = 'Filler Injection Enabled';
$lang['back_channeling_enabled'] = 'Back Channeling Enabled';
$lang['end_call_function_enabled'] = 'Enable End Call Function';
$lang['dial_keypad_function_enabled'] = 'Dial Keypad';

// Campaign language strings
$lang['alm_campaigns'] = 'AI Campaigns';
$lang['alm_campaign'] = 'Campaign';
$lang['alm_new_campaign'] = 'New Campaign';
$lang['alm_campaign_name'] = 'Campaign Name';
$lang['alm_ai_provider'] = 'AI Provider';
$lang['alm_status'] = 'Status';
$lang['alm_progress'] = 'Progress';
$lang['alm_total_numbers'] = 'Total Numbers';
$lang['alm_completed_calls'] = 'Completed';
$lang['alm_failed_calls'] = 'Failed';
$lang['alm_created_at'] = 'Created At';

// Campaign Creation
$lang['create_new_campaign'] = 'Create New Campaign';
$lang['campaign_setup'] = 'Campaign Setup';
$lang['campaign_name'] = 'Campaign Name';
$lang['description'] = 'Description';
$lang['max_call_attempts'] = 'Max Call Attempts';
$lang['ai_provider_configured'] = 'AI provider configured in settings';
$lang['upload_csv_file'] = 'Upload CSV File';
$lang['browse_files'] = 'Browse Files';
$lang['csv_preview'] = 'CSV Preview';
$lang['choose_file'] = 'Choose File';
$lang['upload_csv_info'] = 'Upload a CSV file with phone numbers. The file should have a "phone" column.';

// Launch Schedule
$lang['launch_schedule'] = 'Launch Schedule';
$lang['how_ai_calling_works'] = 'How AI Calling Works:';
$lang['ai_calling_sequential'] = 'The AI assistant will call each contact <strong>sequentially</strong> (one by one), not in bulk. This ensures each conversation gets proper attention and allows for real-time call quality monitoring.';
$lang['launch_now'] = 'Launch Now';
$lang['launch_now_desc'] = 'Start calling contacts immediately';
$lang['schedule_later'] = 'Schedule Later';
$lang['schedule_later_desc'] = 'Choose specific date and time';
$lang['launch_date'] = 'Launch Date';
$lang['launch_time'] = 'Launch Time';

// AI Configuration
$lang['ai_configuration'] = 'AI Configuration';
$lang['assistant_instructions'] = 'Assistant Instructions';
$lang['assistant_instructions_tooltip'] = 'Define how your AI should behave during calls. Be specific about tone, goals, and conversation flow.';
$lang['quick_start_templates'] = 'Quick Start Templates';
$lang['system_prompt_templates'] = 'System Prompt Templates';
$lang['template_loaded_success'] = 'template loaded successfully! You can now customize it for your needs.';
$lang['custom_ai_behavior'] = 'Custom AI behavior instructions. Leave empty for system defaults.';

// Templates
$lang['customer_support_specialist'] = 'Customer Support Specialist';
$lang['lead_qualification_specialist'] = 'Lead Qualification Specialist';
$lang['appointment_scheduler'] = 'Appointment Scheduler';
$lang['info_collector'] = 'Info Collector';
$lang['care_coordinator'] = 'Care Coordinator';
$lang['feedback_gatherer'] = 'Feedback Gatherer';

// Lead Qualification
$lang['lead_qualification'] = 'Lead Qualification';
$lang['enable_smart_qualification'] = 'Enable Smart Qualification';
$lang['smart_qualification_desc'] = 'Use AI analysis to automatically evaluate call quality and create leads only for qualified prospects';
$lang['qualification_criteria'] = 'Qualification Criteria';
$lang['qualification_criteria_placeholder'] = 'Create leads for prospects who show interest, ask questions, mention budget, or want to schedule meetings';
$lang['qualification_criteria_help'] = 'Define what makes a prospect qualified for lead creation.';

// Campaign Stats
$lang['campaign_statistics'] = 'Campaign Statistics';
$lang['contacts'] = 'Contacts';
$lang['max_calls'] = 'Max Calls';
$lang['attempts'] = 'Attempts';

// Actions
$lang['create_campaign'] = 'Create Campaign';
$lang['cancel'] = 'Cancel';
$lang['save'] = 'Save';
$lang['edit'] = 'Edit';
$lang['delete'] = 'Delete';
$lang['view'] = 'View';
$lang['download'] = 'Download';
$lang['play'] = 'Play';
$lang['pause'] = 'Pause';
$lang['stop'] = 'Stop';

// General Settings
$lang['general_settings'] = 'General Settings';
$lang['inbound_call_assistant'] = 'Inbound Call Assistant Settings';
$lang['inbound_assistant_desc'] = 'Configure how your AI assistant behaves when customers call your business. These settings apply to all incoming calls handled by the AI assistant.';
$lang['opening_greeting_message'] = 'Opening Greeting Message';
$lang['opening_greeting_tooltip'] = 'The first thing your AI assistant will say when answering an inbound call. Make it welcoming and professional. Example: \'Hello! Thank you for calling [Company Name]. How can I assist you today?\'';
$lang['assistant_personality'] = 'Assistant Instructions & Personality';
$lang['assistant_personality_tooltip'] = 'Define your AI assistant\'s role, personality, and behavior guidelines. Include information about your company, services, how to handle different situations, and the tone of voice to use. This is the core instruction set that guides all assistant responses.';

$lang['outbound_call_assistant'] = 'Outbound Call Assistant Settings';
$lang['outbound_assistant_desc'] = 'Configure how your AI assistant behaves when making outbound calls to leads and prospects. These settings apply to all outgoing calls initiated by the AI assistant or manually triggered.';
$lang['opening_introduction_message'] = 'Opening Introduction Message';
$lang['opening_introduction_tooltip'] = 'The first thing your AI assistant will say when making an outbound call. Should introduce your company and the purpose of the call. Example: \'Hi [Customer Name], this is [Assistant Name] calling from [Company Name]. I\'m reaching out regarding...\'';
$lang['sales_assistant_instructions'] = 'Sales Assistant Instructions & Approach';
$lang['sales_assistant_tooltip'] = 'Define your AI assistant\'s sales approach, goals, and conversation guidelines for outbound calls. Include qualification questions, value propositions, objection handling, and follow-up procedures. Focus on being helpful rather than pushy.';

$lang['post_call_processing'] = 'Post-Call Processing';
$lang['post_call_desc'] = 'Configure what happens after your AI assistant completes a call. These automation settings help maintain your lead pipeline and ensure proper follow-up.';
$lang['post_call_lead_source'] = 'Post-Call Lead Source';
$lang['post_call_source_tooltip'] = 'When your AI assistant completes a call and creates or updates a lead record, this source will be assigned to track that the lead came from an AI-assisted call. This helps with reporting and lead attribution.';
$lang['post_call_lead_status'] = 'Post-Call Lead Status';
$lang['post_call_status_tooltip'] = 'After your AI assistant successfully completes a call with a lead, the lead\'s status will be automatically updated to this selection. Choose a status that indicates the lead has been contacted and engaged.';

// Opening Message Templates
$lang['opening_message_templates'] = 'Opening Message Templates';
$lang['customer_support_opening'] = 'Customer Support Opening';
$lang['lead_qualification_opening'] = 'Lead Qualification Opening';
$lang['appointment_scheduler_opening'] = 'Appointment Scheduler Opening';
$lang['info_collector_opening'] = 'Info Collector Opening';
$lang['care_coordinator_opening'] = 'Care Coordinator Opening';
$lang['feedback_gatherer_opening'] = 'Feedback Gatherer Opening';

// Call Attempts
$lang['one_attempt'] = '1 Attempt';
$lang['two_attempts'] = '2 Attempts';
$lang['three_attempts'] = '3 Attempts';
$lang['four_attempts'] = '4 Attempts';
$lang['five_attempts'] = '5 Attempts';

// Errors and Messages
$lang['error_occurred'] = 'An error occurred';
$lang['success'] = 'Success';
$lang['please_try_again'] = 'Please try again';
$lang['file_uploaded_successfully'] = 'File uploaded successfully';
$lang['invalid_file_format'] = 'Invalid file format';
$lang['no_phone_column_found'] = 'No phone column found in CSV';
$lang['campaign_created_successfully'] = 'Campaign created successfully';
$lang['campaign_updated_successfully'] = 'Campaign updated successfully';
$lang['campaign_deleted_successfully'] = 'Campaign deleted successfully';
$lang['confirm_delete_campaign'] = 'Are you sure you want to delete this campaign?';
$lang['replace_current_content'] = 'This will replace the current content. Are you sure?';

// AI Provider Names
$lang['bland_ai'] = 'Bland AI';
$lang['vapi_ai'] = 'Vapi AI';

// Call Status
$lang['call_status_completed'] = 'Completed';
$lang['call_status_failed'] = 'Failed';
$lang['call_status_in_progress'] = 'In Progress';
$lang['call_status_queued'] = 'Queued';
$lang['call_status_canceled'] = 'Canceled';

// Form Placeholders
$lang['enter_campaign_name'] = 'Enter campaign name';
$lang['campaign_description_placeholder'] = 'Describe the purpose and goals of this campaign (optional)';
$lang['assistant_prompt_placeholder'] = 'Define how your AI should behave during calls. Be specific about tone, goals, and conversation flow.';
$lang['opening_greeting_placeholder'] = 'Hello! Thank you for calling. How can I assist you today?';
$lang['opening_introduction_placeholder'] = 'Hi there! This is calling from [Company Name]. I\'m reaching out to...';

// Help Text
$lang['help_csv_format'] = 'CSV file should contain a "phone" column with phone numbers.';
$lang['help_max_attempts'] = 'Maximum number of times to attempt calling each contact.';
$lang['help_ai_configuration'] = 'Customize how your AI assistant will behave during calls.';
$lang['help_qualification'] = 'AI will analyze conversations and create leads only for qualified prospects.';

// Navigation
$lang['back_to_campaigns'] = 'Back to Campaigns';
$lang['campaign_management'] = 'Campaign Management';
$lang['call_logs'] = 'Call Logs';
$lang['settings'] = 'Settings';

// Time and Date
$lang['today'] = 'Today';
$lang['yesterday'] = 'Yesterday';
$lang['this_week'] = 'This Week';
$lang['this_month'] = 'This Month';
$lang['last_month'] = 'Last Month';

// Statistics
$lang['total_campaigns'] = 'Total Campaigns';
$lang['active_campaigns'] = 'Active Campaigns';
$lang['total_calls_made'] = 'Total Calls Made';
$lang['success_rate'] = 'Success Rate';
$lang['average_call_duration'] = 'Average Call Duration';

// Module Name
$lang['ai_lead_manager'] = 'AI Lead Manager';
$lang['ai_lead_manager_menu'] = 'AI Lead Manager';

// Additional missing labels
$lang['alm_ai_provider'] = 'AI Provider';
$lang['contact_list'] = 'Contact List';
$lang['csv_requirements'] = 'CSV Requirements';
$lang['csv_requirements_desc'] = 'Must contain <code>phone_number</code> and <code>customer_name</code> columns.';
$lang['contact_list_csv_file'] = 'Contact List CSV File';
$lang['download_csv_template'] = 'Download CSV Template';
$lang['knowledge_bases'] = 'Knowledge Bases';
$lang['knowledge_bases_desc'] = 'Select knowledge bases for your AI assistant to query during calls.';
$lang['manage_knowledge_bases'] = 'Manage Knowledge Bases';
$lang['no_knowledge_bases_available'] = 'No knowledge bases available.';
$lang['create_knowledge_bases'] = 'Create knowledge bases';
$lang['enhance_ai_capabilities'] = 'to enhance AI capabilities.';

// Missing language keys from create.php
$lang['vapi_ai'] = 'Vapi AI';
$lang['bland_ai'] = 'Bland AI';
$lang['opening_message'] = 'Opening Message';
$lang['custom_ai_behavior_help'] = 'Custom AI behavior instructions. Leave empty for system defaults.';
$lang['placeholders_help'] = 'Use placeholders: [name], [company]. Leave empty for system default.';
$lang['lead_qualification'] = 'Lead Qualification';
$lang['campaign_preview'] = 'Campaign Preview';

// Test Call Feature
$lang['test_call'] = 'Test Call';
$lang['test_call_desc'] = 'Test your AI assistant configuration with a live call before launching the campaign.';
$lang['enter_phone_test'] = 'Enter phone number for testing';
$lang['test_phone_help'] = 'Enter a valid phone number (including country code) to receive the test call.';
$lang['start_test_call'] = 'Start Test Call';
$lang['end_call'] = 'End Call';
$lang['test_call_in_progress'] = 'Test call in progress...';
$lang['test_call_ended'] = 'Test call ended';
$lang['test_call_failed'] = 'Test call failed';

// Web-based Test Assistant
$lang['test_assistant_web'] = 'Test Assistant (Web)';
$lang['test_assistant_web_desc'] = 'Have a conversation with your AI assistant directly in your browser - no phone number needed!';
$lang['start_conversation'] = 'Start Conversation';
$lang['end_conversation'] = 'End Conversation';
$lang['conversation_active'] = 'Conversation Active';
$lang['web_call_connecting'] = 'Connecting...';
$lang['web_call_connected'] = 'Connected';
$lang['web_call_listening'] = 'Listening...';
$lang['web_call_speaking'] = 'AI Speaking...';
$lang['conversation_ended'] = 'Conversation Ended';