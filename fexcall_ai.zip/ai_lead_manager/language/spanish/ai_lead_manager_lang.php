<?php
defined('BASEPATH') or exit('No direct script access allowed');

// Call logs
$lang['alm_call_log'] = 'Registro de llamada';
$lang['alm_call_logs'] = 'Registros de llamadas AI';
$lang['alm_call_log_call_id'] = 'ID de llamada';
$lang['alm_call_log_created_at'] = 'Creado en';
$lang['alm_call_log_direction'] = 'Dirección';
$lang['alm_call_log_to_number'] = 'Para';
$lang['alm_call_log_from_number'] = 'De';
$lang['alm_call_log_recording'] = 'Grabación';
$lang['alm_call_log_status'] = 'Estado';
$lang['alm_call_log_duration'] = 'Duración';
$lang['alm_call_log_ended_reason'] = 'Razón de finalización';
$lang['leads_dt_last_call_ended_reason'] = 'Última razón de finalización de llamada';
$lang['alm_call_log_price'] = 'Precio';
$lang['alm_call_started_at'] = 'Iniciado en';
$lang['alm_call_log_details'] = 'Detalles de la llamada';
$lang['alm_call_log_summary'] = 'Resumen';
$lang['alm_call_log_transcripts'] = 'Transcripciones';
$lang['alm_call_log_lead'] = 'Prospecto';
$lang['alm_call_log_inbound'] = 'Entrante';
$lang['alm_call_log_outbound'] = 'Saliente';
$lang['alm_call_log_total_calls_today'] = 'Total de llamadas hoy';
$lang['alm_call_log_total_calls_yesterday'] = 'Total de llamadas ayer';

// AI Settings
$lang['vapi_ai_detect_emotions'] = 'Detectar emociones';
$lang['filler_injection_enabled'] = 'Inyección de relleno habilitada';
$lang['back_channeling_enabled'] = 'Canal de retorno habilitado';
$lang['end_call_function_enabled'] = 'Habilitar función de finalizar llamada';
$lang['dial_keypad_function_enabled'] = 'Teclado de marcado';

// Campaign language strings
$lang['alm_campaigns'] = 'Campañas AI';
$lang['alm_campaign'] = 'Campaña';
$lang['alm_new_campaign'] = 'Nueva campaña';
$lang['alm_campaign_name'] = 'Nombre de campaña';
$lang['alm_ai_provider'] = 'Proveedor AI';
$lang['alm_status'] = 'Estado';
$lang['alm_progress'] = 'Progreso';
$lang['alm_total_numbers'] = 'Total de números';
$lang['alm_completed_calls'] = 'Completadas';
$lang['alm_failed_calls'] = 'Fallidas';
$lang['alm_created_at'] = 'Creado en';

// Campaign Creation
$lang['create_new_campaign'] = 'Crear nueva campaña';
$lang['campaign_setup'] = 'Configuración de campaña';
$lang['campaign_name'] = 'Nombre de campaña';
$lang['description'] = 'Descripción';
$lang['max_call_attempts'] = 'Máximo intentos de llamada';
$lang['ai_provider_configured'] = 'Proveedor AI configurado en ajustes';
$lang['upload_csv_file'] = 'Subir archivo CSV';
$lang['browse_files'] = 'Buscar archivos';
$lang['csv_preview'] = 'Vista previa CSV';
$lang['choose_file'] = 'Elegir archivo';
$lang['upload_csv_info'] = 'Sube un archivo CSV con números de teléfono. El archivo debe tener una columna "phone".';

// Launch Schedule
$lang['launch_schedule'] = 'Programación de lanzamiento';
$lang['how_ai_calling_works'] = 'Cómo funciona la llamada AI:';
$lang['ai_calling_sequential'] = 'El asistente AI llamará a cada contacto <strong>secuencialmente</strong> (uno por uno), no en masa. Esto asegura que cada conversación reciba la atención adecuada y permite el monitoreo de calidad en tiempo real.';
$lang['launch_now'] = 'Lanzar ahora';
$lang['launch_now_desc'] = 'Comenzar a llamar contactos inmediatamente';
$lang['schedule_later'] = 'Programar después';
$lang['schedule_later_desc'] = 'Elegir fecha y hora específica';
$lang['launch_date'] = 'Fecha de lanzamiento';
$lang['launch_time'] = 'Hora de lanzamiento';

// AI Configuration
$lang['ai_configuration'] = 'Configuración AI';
$lang['assistant_instructions'] = 'Instrucciones del asistente';
$lang['assistant_instructions_tooltip'] = 'Define cómo debe comportarse tu AI durante las llamadas. Sé específico sobre el tono, objetivos y flujo de conversación.';
$lang['quick_start_templates'] = 'Plantillas de inicio rápido';
$lang['system_prompt_templates'] = 'Plantillas de comandos del sistema';
$lang['template_loaded_success'] = 'plantilla cargada exitosamente! Ahora puedes personalizarla según tus necesidades.';
$lang['custom_ai_behavior'] = 'Instrucciones de comportamiento AI personalizado. Dejar vacío para usar valores predeterminados del sistema.';

// Templates
$lang['customer_support_specialist'] = 'Especialista en atención al cliente';
$lang['lead_qualification_specialist'] = 'Especialista en calificación de prospectos';
$lang['appointment_scheduler'] = 'Programador de citas';
$lang['info_collector'] = 'Recolector de información';
$lang['care_coordinator'] = 'Coordinador de atención';
$lang['feedback_gatherer'] = 'Recolector de comentarios';

// Lead Qualification
$lang['lead_qualification'] = 'Calificación de prospectos';
$lang['enable_smart_qualification'] = 'Habilitar calificación inteligente';
$lang['smart_qualification_desc'] = 'Usar análisis AI para evaluar automáticamente la calidad de la llamada y crear prospectos solo para candidatos calificados';
$lang['qualification_criteria'] = 'Criterios de calificación';
$lang['qualification_criteria_placeholder'] = 'Crear prospectos para candidatos que muestren interés, hagan preguntas, mencionen presupuesto o quieran programar reuniones';
$lang['qualification_criteria_help'] = 'Define qué hace que un prospecto esté calificado para la creación de leads.';

// Campaign Stats
$lang['campaign_statistics'] = 'Estadísticas de campaña';
$lang['contacts'] = 'Contactos';
$lang['max_calls'] = 'Máximo llamadas';
$lang['attempts'] = 'Intentos';

// Actions
$lang['create_campaign'] = 'Crear campaña';
$lang['cancel'] = 'Cancelar';
$lang['save'] = 'Guardar';
$lang['edit'] = 'Editar';
$lang['delete'] = 'Eliminar';
$lang['view'] = 'Ver';
$lang['download'] = 'Descargar';
$lang['play'] = 'Reproducir';
$lang['pause'] = 'Pausar';
$lang['stop'] = 'Detener';

// General Settings
$lang['general_settings'] = 'Configuración general';
$lang['inbound_call_assistant'] = 'Configuración del asistente de llamadas entrantes';
$lang['inbound_assistant_desc'] = 'Configura cómo se comporta tu asistente AI cuando los clientes llaman a tu negocio. Estos ajustes se aplican a todas las llamadas entrantes manejadas por el asistente AI.';
$lang['opening_greeting_message'] = 'Mensaje de saludo de apertura';
$lang['opening_greeting_tooltip'] = 'Lo primero que dirá tu asistente AI al contestar una llamada entrante. Hazlo acogedor y profesional. Ejemplo: \'¡Hola! Gracias por llamar a [Nombre de la empresa]. ¿Cómo puedo ayudarte hoy?\'';
$lang['assistant_personality'] = 'Instrucciones y personalidad del asistente';
$lang['assistant_personality_tooltip'] = 'Define el rol, personalidad y pautas de comportamiento de tu asistente AI. Incluye información sobre tu empresa, servicios, cómo manejar diferentes situaciones y el tono de voz a usar. Este es el conjunto de instrucciones principal que guía todas las respuestas del asistente.';

$lang['outbound_call_assistant'] = 'Configuración del asistente de llamadas salientes';
$lang['outbound_assistant_desc'] = 'Configura cómo se comporta tu asistente AI al hacer llamadas salientes a prospectos y clientes potenciales. Estos ajustes se aplican a todas las llamadas salientes iniciadas por el asistente AI o activadas manualmente.';
$lang['opening_introduction_message'] = 'Mensaje de introducción de apertura';
$lang['opening_introduction_tooltip'] = 'Lo primero que dirá tu asistente AI al hacer una llamada saliente. Debe presentar tu empresa y el propósito de la llamada. Ejemplo: \'Hola [Nombre del cliente], soy [Nombre del asistente] llamando de [Nombre de la empresa]. Te contacto en relación a...\'';
$lang['sales_assistant_instructions'] = 'Instrucciones y enfoque del asistente de ventas';
$lang['sales_assistant_tooltip'] = 'Define el enfoque de ventas, objetivos y pautas de conversación de tu asistente AI para llamadas salientes. Incluye preguntas de calificación, propuestas de valor, manejo de objeciones y procedimientos de seguimiento. Enfócate en ser útil en lugar de agresivo.';

$lang['post_call_processing'] = 'Procesamiento post-llamada';
$lang['post_call_desc'] = 'Configura qué sucede después de que tu asistente AI complete una llamada. Estos ajustes de automatización ayudan a mantener tu pipeline de prospectos y asegurar un seguimiento adecuado.';
$lang['post_call_lead_source'] = 'Fuente de prospecto post-llamada';
$lang['post_call_source_tooltip'] = 'Cuando tu asistente AI complete una llamada y cree o actualice un registro de prospecto, esta fuente se asignará para rastrear que el prospecto provino de una llamada asistida por AI. Esto ayuda con los reportes y la atribución de prospectos.';
$lang['post_call_lead_status'] = 'Estado de prospecto post-llamada';
$lang['post_call_status_tooltip'] = 'Después de que tu asistente AI complete exitosamente una llamada con un prospecto, el estado del prospecto se actualizará automáticamente a esta selección. Elige un estado que indique que el prospecto ha sido contactado y comprometido.';

// Opening Message Templates
$lang['opening_message_templates'] = 'Plantillas de mensajes de apertura';
$lang['customer_support_opening'] = 'Apertura de atención al cliente';
$lang['lead_qualification_opening'] = 'Apertura de calificación de prospectos';
$lang['appointment_scheduler_opening'] = 'Apertura de programador de citas';
$lang['info_collector_opening'] = 'Apertura de recolector de información';
$lang['care_coordinator_opening'] = 'Apertura de coordinador de atención';
$lang['feedback_gatherer_opening'] = 'Apertura de recolector de comentarios';

// Call Attempts
$lang['one_attempt'] = '1 intento';
$lang['two_attempts'] = '2 intentos';
$lang['three_attempts'] = '3 intentos';
$lang['four_attempts'] = '4 intentos';
$lang['five_attempts'] = '5 intentos';

// Errors and Messages
$lang['error_occurred'] = 'Ocurrió un error';
$lang['success'] = 'Éxito';
$lang['please_try_again'] = 'Por favor intenta de nuevo';
$lang['file_uploaded_successfully'] = 'Archivo subido exitosamente';
$lang['invalid_file_format'] = 'Formato de archivo inválido';
$lang['no_phone_column_found'] = 'No se encontró columna de teléfono en CSV';
$lang['campaign_created_successfully'] = 'Campaña creada exitosamente';
$lang['campaign_updated_successfully'] = 'Campaña actualizada exitosamente';
$lang['campaign_deleted_successfully'] = 'Campaña eliminada exitosamente';
$lang['confirm_delete_campaign'] = '¿Estás seguro de que quieres eliminar esta campaña?';
$lang['replace_current_content'] = 'Esto reemplazará el contenido actual. ¿Estás seguro?';

// AI Provider Names
$lang['bland_ai'] = 'Bland AI';
$lang['vapi_ai'] = 'Vapi AI';

// Call Status
$lang['call_status_completed'] = 'Completada';
$lang['call_status_failed'] = 'Fallida';
$lang['call_status_in_progress'] = 'En progreso';
$lang['call_status_queued'] = 'En cola';
$lang['call_status_canceled'] = 'Cancelada';

// Form Placeholders
$lang['enter_campaign_name'] = 'Ingresa nombre de campaña';
$lang['campaign_description_placeholder'] = 'Describe el propósito y objetivos de esta campaña (opcional)';
$lang['assistant_prompt_placeholder'] = 'Define cómo debe comportarse tu AI durante las llamadas. Sé específico sobre el tono, objetivos y flujo de conversación.';
$lang['opening_greeting_placeholder'] = '¡Hola! Gracias por llamar. ¿Cómo puedo ayudarte hoy?';
$lang['opening_introduction_placeholder'] = '¡Hola! Soy de [Nombre de la empresa]. Te contacto para...';

// Help Text
$lang['help_csv_format'] = 'El archivo CSV debe contener una columna "phone" con números de teléfono.';
$lang['help_max_attempts'] = 'Número máximo de veces para intentar llamar a cada contacto.';
$lang['help_ai_configuration'] = 'Personaliza cómo se comportará tu asistente AI durante las llamadas.';
$lang['help_qualification'] = 'AI analizará las conversaciones y creará prospectos solo para candidatos calificados.';

// Navigation
$lang['back_to_campaigns'] = 'Volver a campañas';
$lang['campaign_management'] = 'Gestión de campañas';
$lang['call_logs'] = 'Registros de llamadas';
$lang['settings'] = 'Configuración';

// Time and Date
$lang['today'] = 'Hoy';
$lang['yesterday'] = 'Ayer';
$lang['this_week'] = 'Esta semana';
$lang['this_month'] = 'Este mes';
$lang['last_month'] = 'Mes pasado';

// Statistics
$lang['total_campaigns'] = 'Total de campañas';
$lang['active_campaigns'] = 'Campañas activas';
$lang['total_calls_made'] = 'Total de llamadas realizadas';
$lang['success_rate'] = 'Tasa de éxito';
$lang['average_call_duration'] = 'Duración promedio de llamada';

// Module Name
$lang['ai_lead_manager'] = 'Gestor de prospectos AI';
$lang['ai_lead_manager_menu'] = 'Gestor de prospectos AI';

// Additional missing labels
$lang['contact_list'] = 'Lista de contactos';
$lang['csv_requirements'] = 'Requisitos del CSV';
$lang['csv_requirements_desc'] = 'Debe contener las columnas <code>phone_number</code> y <code>customer_name</code>.';
$lang['contact_list_csv_file'] = 'Archivo CSV de lista de contactos';
$lang['download_csv_template'] = 'Descargar plantilla CSV';
$lang['knowledge_bases'] = 'Bases de conocimiento';
$lang['knowledge_bases_desc'] = 'Selecciona bases de conocimiento para que tu asistente AI las consulte durante las llamadas.';
$lang['manage_knowledge_bases'] = 'Gestionar bases de conocimiento';
$lang['no_knowledge_bases_available'] = 'No hay bases de conocimiento disponibles.';
$lang['create_knowledge_bases'] = 'Crear bases de conocimiento';
$lang['enhance_ai_capabilities'] = 'para mejorar las capacidades de AI.';
$lang['opening_message'] = 'Mensaje de apertura';
$lang['custom_ai_behavior_help'] = 'Instrucciones de comportamiento AI personalizado. Dejar vacío para usar valores predeterminados del sistema.';
$lang['placeholders_help'] = 'Usar marcadores de posición: [name], [company]. Dejar vacío para usar valores predeterminados del sistema.';
$lang['lead_qualification'] = 'Calificación de prospectos';
$lang['campaign_preview'] = 'Vista previa de campaña';

// Test Call Feature
$lang['test_call'] = 'Llamada de prueba';
$lang['test_call_desc'] = 'Prueba la configuración de tu asistente AI con una llamada en vivo antes de lanzar la campaña.';
$lang['enter_phone_test'] = 'Ingresa número de teléfono para prueba';
$lang['test_phone_help'] = 'Ingresa un número de teléfono válido (incluyendo código de país) para recibir la llamada de prueba.';
$lang['start_test_call'] = 'Iniciar llamada de prueba';
$lang['end_call'] = 'Finalizar llamada';
$lang['test_call_in_progress'] = 'Llamada de prueba en progreso...';
$lang['test_call_ended'] = 'Llamada de prueba finalizada';
$lang['test_call_failed'] = 'Llamada de prueba falló';

// Web-based Test Assistant
$lang['test_assistant_web'] = 'Probar Asistente (Web)';
$lang['test_assistant_web_desc'] = '¡Ten una conversación con tu asistente AI directamente en tu navegador - no necesitas número de teléfono!';
$lang['start_conversation'] = 'Iniciar Conversación';
$lang['end_conversation'] = 'Finalizar Conversación';
$lang['conversation_active'] = 'Conversación Activa';
$lang['web_call_connecting'] = 'Conectando...';
$lang['web_call_connected'] = 'Conectado';
$lang['web_call_listening'] = 'Escuchando...';
$lang['web_call_speaking'] = 'AI Hablando...';
$lang['conversation_ended'] = 'Conversación Finalizada';