<div role="tabpanel" class="tab-pane" id="tab_ai_call_logs_leads">
    <?php
    $CI = &get_instance();
    $alm_voice_assistant = get_option('alm_voice_assistant');
    
    // Get lead data for make call button
    $lead_id = null;
    if (isset($lead)) {
        $lead_id = $lead->id;
        $has_phone = !empty($lead->phonenumber);
    } else {
        // Try to get lead ID from URL or other sources
        $lead_id = $CI->input->get('id');
        if ($lead_id) {
            $CI->load->model('leads_model');
            $lead_data = $CI->leads_model->get($lead_id);
            $has_phone = $lead_data && !empty($lead_data->phonenumber);
        } else {
            $has_phone = false;
        }
    }
    
    // Display Make Call button before the table if lead has phone number
    if ($lead_id && $has_phone) {
        echo '<div class="mtop15 mbot15">
            <button type="button" class="btn btn-primary make-call-btn-profile" data-lead-id="' . $lead_id . '">
                <i class="fa fa-phone"></i> Make AI Call
            </button>
        </div>';
    }
    
    $table_data = [
        '#',
        _l('alm_call_log_call_id'),
        _l('alm_call_log_created_at'),
        _l('alm_call_log_direction'),
        _l('alm_call_log_to_number'),
        _l('alm_call_log_from_number'),
        _l('alm_call_log_recording'),
        ($alm_voice_assistant == 'vapi_ai' ? _l('alm_call_log_ended_reason') : _l('alm_call_log_status')),
        _l('alm_call_log_duration'),
        _l('alm_call_log_price')
    ];

    $table_data = hooks()->apply_filters('alm_call_logs_relation_table_columns', $table_data);
    render_datatable($table_data, 'alm_call_logs-lead', [], [
        'data-last-order-identifier' => 'alm_call_logs-relation',
        'data-default-order'         => get_table_last_order('alm_call_logs-relation'),
    ]);
    ?>
</div>