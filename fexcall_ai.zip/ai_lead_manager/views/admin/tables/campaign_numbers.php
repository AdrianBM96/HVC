<?php

defined('BASEPATH') or exit('No direct script access allowed');

// $campaign_id is passed from the controller via get_table_data parameters

$aColumns = [
    db_prefix() . 'alm_campaign_numbers.phone_number as phone_number',
    db_prefix() . 'alm_campaign_numbers.customer_name as customer_name',
    db_prefix() . 'alm_campaign_numbers.customer_email as customer_email',
    db_prefix() . 'alm_campaign_numbers.extra_data as extra_data',
    db_prefix() . 'alm_campaign_numbers.extra_data as extra_data_location',
    db_prefix() . 'alm_campaign_numbers.status as status',
    db_prefix() . 'alm_campaign_numbers.attempts as attempts',
    db_prefix() . 'alm_campaign_numbers.last_attempt_at as last_attempt_at',
    db_prefix() . 'alm_campaign_numbers.lead_id as lead_id',
    db_prefix() . 'alm_campaign_numbers.id as id',
];

$sIndexColumn = 'id';
$sTable       = db_prefix() . 'alm_campaign_numbers';
$where        = [];
$join         = [];

// Filter by campaign ID
if ($campaign_id) {
    array_push($where, 'AND campaign_id=' . (int) $campaign_id);
}

$result = data_tables_init($aColumns, $sIndexColumn, $sTable, $join, $where, [
    'campaign_id',
    'call_id',
    'call_log_id',
    'completed_at',
    'error_message',
    'created_at',
    'updated_at'
]);

$output  = $result['output'];
$rResult = $result['rResult'];

foreach ($rResult as $aRow) {
    $row = [];
    
    // Parse extra_data once
    $extra_data = [];
    if (!empty($aRow['extra_data'])) {
        $extra_data = json_decode($aRow['extra_data'], true) ?: [];
    }
    
    // 1. Phone Number
    $phone_number = $aRow['phone_number'] ?: '';
    $row[] = '<strong>' . htmlspecialchars($phone_number) . '</strong>';
    
    // 2. Customer Name with Address
    $customer_name = $aRow['customer_name'] ?: '';
    $customerName = '<strong>' . htmlspecialchars($customer_name) . '</strong>';
    if (!empty($extra_data['address'])) {
        $customerName .= '<br><small class="text-muted">' . htmlspecialchars($extra_data['address']) . '</small>';
    }
    $row[] = $customerName;
    
    // 3. Email
    $customer_email = $aRow['customer_email'] ?: '';
    $row[] = $customer_email ? '<a href="mailto:' . htmlspecialchars($customer_email) . '">' . htmlspecialchars($customer_email) . '</a>' : '-';
    
    // 4. Company
    $company = isset($extra_data['company']) ? $extra_data['company'] : '';
    $row[] = $company ? htmlspecialchars($company) : '-';
    
    // 5. Location
    $location_parts = [];
    if (!empty($extra_data['city'])) $location_parts[] = htmlspecialchars($extra_data['city']);
    if (!empty($extra_data['state'])) $location_parts[] = htmlspecialchars($extra_data['state']);
    if (!empty($extra_data['country'])) $location_parts[] = htmlspecialchars($extra_data['country']);
    $location = !empty($location_parts) ? implode(', ', $location_parts) : '-';
    if (!empty($extra_data['zip_code'])) {
        $location .= '<br><small class="text-muted">' . htmlspecialchars($extra_data['zip_code']) . '</small>';
    }
    $row[] = $location;
    
    // 6. Description
    $description = isset($extra_data['description']) ? $extra_data['description'] : '';
    if ($description) {
        $description_display = htmlspecialchars($description);
        if (strlen($description_display) > 50) {
            $description_display = substr($description_display, 0, 47) . '...';
        }
        $row[] = '<span title="' . htmlspecialchars($description) . '">' . $description_display . '</span>';
    } else {
        $row[] = '-';
    }
    
    // 7. Status
    $status_colors = [
        'pending' => 'warning',
        'calling' => 'info',
        'completed' => 'success', 
        'failed' => 'danger',
        'skipped' => 'default'
    ];
    
    $current_status = $aRow['status'] ?: 'pending';
    $status_color = isset($status_colors[$current_status]) ? $status_colors[$current_status] : 'default';
    $status = '<span class="label label-' . $status_color . '">' . ucfirst($current_status) . '</span>';
    
    if ($current_status === 'completed' && !empty($aRow['completed_at'])) {
        $status .= '<br><small class="text-muted">' . _dt($aRow['completed_at']) . '</small>';
    }
    $row[] = $status;
    
    // 8. Attempts
    $attempts = (int) ($aRow['attempts'] ?: 0);
    $row[] = '<span class="badge badge-' . ($attempts > 1 ? 'warning' : 'default') . '">' . $attempts . '</span>';
    
    // 9. Last Attempt
    $last_attempt = $aRow['last_attempt_at'] ?: '';
    $row[] = $last_attempt ? _dt($last_attempt) : '-';
    
    // 10. Lead Created
    $lead_id = $aRow['lead_id'] ?: '';
    $row[] = $lead_id ? '<a href="' . admin_url('leads/index/' . $lead_id) . '" class="text-info" target="_blank"><i class="fa fa-user"></i></a>' : '<span class="text-muted">-</span>';
    
    // 11. Actions
    $actions = '<div class="row-options">';
    $call_log_id = $aRow['call_log_id'] ?: '';
    if ($call_log_id) {
        $actions .= '<a href="#" onclick="init_alm_call_log_modal(' . $call_log_id . ');" class="text-success campaign-action-btn" title="View Call Log"><i class="fa fa-phone fa-lg"></i></a>';
    }
    if (!empty($extra_data)) {
        $customer_name_escaped = htmlspecialchars($customer_name, ENT_QUOTES);
        $extra_data_json = htmlspecialchars(json_encode($extra_data), ENT_QUOTES);
        $actions .= ' <a href="#" onclick="showCustomerDetails(' . $extra_data_json . ', \'' . $customer_name_escaped . '\');" class="text-info campaign-action-btn" title="View Details"><i class="fa fa-info-circle fa-lg"></i></a>';
    }
    $error_message = $aRow['error_message'] ?: '';
    if ($error_message) {
        $error_base64 = base64_encode($error_message);
        $actions .= ' <a href="#" onclick="showErrorDetails(\'' . $error_base64 . '\', true);" class="text-danger campaign-action-btn" title="View Error"><i class="fa fa-exclamation-triangle fa-lg"></i></a>';
    }
    
    // Add edit button for all numbers
    $campaign_number_id = $aRow['id'];
    $phone_escaped = htmlspecialchars($phone_number, ENT_QUOTES);
    $customer_name_escaped = htmlspecialchars($customer_name, ENT_QUOTES);
    $customer_email_escaped = htmlspecialchars($customer_email, ENT_QUOTES);
    $status = $aRow['status'];
    $attempts = (int)$aRow['attempts'];
    
    // Prepare extra data for edit modal
    $edit_data = [
        'id' => $campaign_number_id,
        'phone_number' => $phone_number,
        'customer_name' => $customer_name,
        'customer_email' => $customer_email,
        'status' => $status,
        'attempts' => $attempts,
        'city' => $extra_data['city'] ?? '',
        'state' => $extra_data['state'] ?? '',
        'country' => $extra_data['country'] ?? '',
        'zip_code' => $extra_data['zip_code'] ?? '',
        'company' => $extra_data['company'] ?? '',
        'address' => $extra_data['address'] ?? '',
        'description' => $extra_data['description'] ?? ''
    ];
    $edit_data_base64 = base64_encode(json_encode($edit_data));
    
    $actions .= ' <a href="#" onclick="editCampaignNumber(\'' . $edit_data_base64 . '\');" class="text-primary campaign-action-btn" title="Edit Number"><i class="fa fa-edit fa-lg"></i></a>';
    
    // Add retry button for failed, pending, or calling numbers (but not completed ones)
    if (in_array($current_status, ['failed', 'pending', 'calling']) && $current_status !== 'completed') {
        $actions .= ' <a href="#" onclick="retryCampaignNumber(' . $campaign_number_id . ', \'' . $phone_escaped . '\');" class="text-warning campaign-action-btn" title="Retry Call"><i class="fa fa-refresh fa-lg"></i></a>';
    }
    
    $actions .= '</div>';
    $row[] = $actions;
    
    $row['DT_RowClass'] = 'has-row-options';
    
    $output['aaData'][] = $row;
}

echo json_encode($output);
die;