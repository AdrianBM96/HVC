<?php
defined('BASEPATH') or exit('No direct script access allowed');

// $campaign_id is passed from the controller via get_table_data parameters
$aColumns = [
    db_prefix() . 'alm_call_logs.id as id',
    'call_id',
    'created_at',
    'direction',
    'to_number',
    'from_number',
    'recording_url',
    'call_ended_by',
    'call_length',
    'price',
    'summary',
    'started_at',
    'ended_at',
    'ai_provider'
];

$sIndexColumn = 'id';
$sTable = db_prefix() . 'alm_call_logs';

$join = [];
$where = [];

// Filter by campaign using the new campaign_id column
if ($campaign_id) {
    $where[] = "AND campaign_id = " . (int) $campaign_id;
}

$result = data_tables_init($aColumns, $sIndexColumn, $sTable, $join, $where, [
    'status',
    'transcripts',
    'extra_information'
]);

$output = $result['output'];
$rResult = $result['rResult'];

$alm_voice_assistant = get_option('alm_voice_assistant');

foreach ($rResult as $aRow) {
    $row = [];
    
    // 1. Row number/ID
    $row[] = '<a href="' . admin_url('ai_lead_manager/call_logs/call_log/' . $aRow['id']) . '" onclick="init_alm_call_log_modal(' . $aRow['id'] . '); return false;">' . $aRow['id'] . '</a>';
    
    // 2. Call ID
    $row[] = !empty($aRow['call_id']) ? $aRow['call_id'] : '-';
    
    // 3. Created At
    $row[] = _d($aRow['created_at']) . '<br><a href="' . admin_url('ai_lead_manager/call_logs/call_log/' . $aRow['id']) . '"  onclick="init_alm_call_log_modal(' . $aRow['id'] . '); return false;">view</a>';
    
    // 4. Direction
    $direction = (int) $aRow['direction'];
    if ($direction == 0) {
        $row[] = '<i class="fa fa-arrow-down text-danger" title="Inbound"></i> Inbound';
    } else {
        $row[] = '<i class="fa fa-arrow-up text-success" title="Outbound"></i> Outbound';
    }
    
    // 5. To Number
    $row[] = $aRow['to_number'] ?: '-';
    
    // 6. From Number
    $row[] = $aRow['from_number'] ?: '-';
    
    // 7. Recording
    if (!empty($aRow['recording_url'])) {
        $row[] = '<audio controls style="width: 210px; height: 30px"><source src="' . $aRow['recording_url'] . '" type="audio/wav">Your browser does not support the audio element.</audio>';
    } else {
        $row[] = '<span class="text-muted">No recording</span>';
    }
    
    // 8. Status/Ended Reason
    $row[] = ($alm_voice_assistant == 'vapi_ai' ? alm_format_call_log_status($aRow['call_ended_by']) : $aRow['status']);
    
    // 9. Duration
    $row[] = convert_duration($aRow['call_length']);
    
    // 10. Price
    $row[] = $aRow['price'];
    
    // 11. Lead/Customer Info
    if (!empty($aRow['summary'])) {
        $summary_preview = strlen($aRow['summary']) > 50 ? substr($aRow['summary'], 0, 50) . '...' : $aRow['summary'];
        $row[] = '<span title="' . htmlspecialchars($aRow['summary']) . '">' . $summary_preview . '</span>';
    } else {
        $row[] = '-';
    }
    
    // 12. Started At
    $row[] = $aRow['started_at'] ? _dt($aRow['started_at']) : '-';
    
    // 13. Ended At  
    $row[] = $aRow['ended_at'] ? _dt($aRow['ended_at']) : '-';
    
    // 14. AI Provider
    $provider_badge = $aRow['ai_provider'] === 'vapi_ai' ? 'info' : 'success';
    $row[] = '<span class="badge badge-' . $provider_badge . '">' . ucfirst(str_replace('_', ' ', $aRow['ai_provider'])) . '</span>';

    $output['aaData'][] = $row;
}