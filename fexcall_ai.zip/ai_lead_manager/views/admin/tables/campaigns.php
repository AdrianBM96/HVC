<?php

defined('BASEPATH') or exit('No direct script access allowed');

$aColumns = [
    db_prefix() . 'alm_campaigns.name as name',
    db_prefix() . 'alm_campaigns.status as status',
    db_prefix() . 'alm_campaigns.id as success_rate_id',
    db_prefix() . 'alm_campaigns.id as total_contacts_id',
    db_prefix() . 'alm_campaigns.id as answered_calls_id',
    db_prefix() . 'alm_campaigns.id as unanswered_rescheduled_id',
    db_prefix() . 'alm_campaigns.created_at as created_at',
    db_prefix() . 'alm_campaigns.id as id',
];

$sIndexColumn = 'id';
$sTable       = db_prefix() . 'alm_campaigns';
$where        = [];
$join         = [];

$result = data_tables_init($aColumns, $sIndexColumn, $sTable, $join, $where, [
    'schedule_type',
    'scheduled_at',
    'started_at',
    'completed_at',
    'created_by',
    'updated_at'
]);

$output  = $result['output'];
$rResult = $result['rResult'];

foreach ($rResult as $aRow) {
    $row = [];
    
    // 1. Campaign Name
    $campaign_name = $aRow['name'] ?: '';
    $campaign_link = '<a href="' . admin_url('ai_lead_manager/campaigns/view/' . $aRow['id']) . '"><strong>' . htmlspecialchars($campaign_name) . '</strong></a>';
    $row[] = $campaign_link;
    
    // 2. Status
    $status_colors = [
        'draft' => 'default',
        'scheduled' => 'warning',
        'running' => 'info',
        'paused' => 'warning', 
        'completed' => 'success',
        'cancelled' => 'danger'
    ];
    
    $current_status = $aRow['status'] ?: 'draft';
    $status_color = isset($status_colors[$current_status]) ? $status_colors[$current_status] : 'default';
    $status = '<span class="label label-' . $status_color . '">' . ucfirst($current_status) . '</span>';
    $row[] = $status;
    
    // Get campaign statistics
    $CI = &get_instance();
    $CI->load->model(AI_LEAD_MANAGER_MODULE_NAME . '/campaigns_model', 'campaigns');
    $stats = $CI->campaigns->get_campaign_stats($aRow['id']);
    
    // 3. Success Rate with visual indicator
    $success_rate = isset($stats['success_rate']) && is_numeric($stats['success_rate']) ? $stats['success_rate'] : 0;
    $completion_rate = isset($stats['completion_rate']) && is_numeric($stats['completion_rate']) ? $stats['completion_rate'] : 0;
    
    $success_html = '<div class="progress tw-h-2" style="margin-bottom: 4px;">';
    $success_html .= '<div class="progress-bar progress-bar-success" style="width: ' . $success_rate . '%"></div>';
    $success_html .= '</div>';
    $success_html .= '<small><strong>' . $success_rate . '%</strong> Success</small><br>';
    $success_html .= '<small>' . $completion_rate . '% Complete</small>';
    $row[] = $success_html;
    
    // 4. Total Contacts
    $total_contacts = $stats['total_contacts'];
    $row[] = '<span class="text-info"><strong>' . $total_contacts . '</strong></span>';
    
    // 5. Answered Calls  
    $answered = $stats['answered_calls'];
    $row[] = '<span class="text-success"><strong>' . $answered . '</strong></span>';
    
    // 6. Un-Answered + Rescheduled
    $unanswered = $stats['unanswered_calls'];
    $rescheduled = $stats['rescheduled_attempts'];
    $unanswered_html = '<span class="text-danger"><strong>' . $unanswered . '</strong></span>';
    if ($rescheduled > 0) {
        $unanswered_html .= '<br><small class="text-warning">+' . $rescheduled . ' rescheduled</small>';
    }
    $row[] = $unanswered_html;
    
    // 7. Created At
    $row[] = _dt($aRow['created_at']);
    
    // 8. Actions
    $actions = '<div class="row-options">';
    $actions .= '<a href="' . admin_url('ai_lead_manager/campaigns/view/' . $aRow['id']) . '" class="text-info" title="View"><i class="fa fa-eye"></i></a>';
    
    // Start/Resume action
    if (in_array($current_status, ['paused', 'draft'])) {
        $actions .= ' <a href="' . admin_url('ai_lead_manager/campaigns/start/' . $aRow['id']) . '" class="text-success" title="Start/Resume"><i class="fa fa-play"></i></a>';
    }
    
    // Pause action
    if ($current_status === 'running') {
        $actions .= ' <a href="' . admin_url('ai_lead_manager/campaigns/pause/' . $aRow['id']) . '" class="text-warning" title="Pause"><i class="fa fa-pause"></i></a>';
    }
    
    // Cancel action
    if (in_array($current_status, ['running', 'paused', 'scheduled'])) {
        $actions .= ' <a href="' . admin_url('ai_lead_manager/campaigns/cancel/' . $aRow['id']) . '" class="text-danger" title="Cancel" onclick="return confirm(\'Are you sure you want to cancel this campaign?\');"><i class="fa fa-stop"></i></a>';
    }
    
    // Delete action
    if (in_array($current_status, ['completed', 'cancelled'])) {
        $actions .= ' <a href="' . admin_url('ai_lead_manager/campaigns/delete/' . $aRow['id']) . '" class="text-danger" title="Delete" onclick="return confirm(\'Are you sure you want to delete this campaign? This action cannot be undone.\');"><i class="fa fa-trash"></i></a>';
    }
    
    $actions .= '</div>';
    $row[] = $actions;
    
    $row['DT_RowClass'] = 'has-row-options';
    
    $output['aaData'][] = $row;
}

echo json_encode($output);
die;