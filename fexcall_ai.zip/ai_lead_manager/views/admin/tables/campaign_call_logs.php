<?php

defined('BASEPATH') or exit('No direct script access allowed');

// $campaign_id is passed from the controller via get_table_data parameters

$aColumns = [
    db_prefix() . 'alm_call_logs.to_number as to_number',
    db_prefix() . 'alm_campaign_numbers.customer_name as customer_name',
    db_prefix() . 'alm_call_logs.status as call_status',
    db_prefix() . 'alm_call_logs.call_length as call_length',
    db_prefix() . 'alm_call_logs.started_at as started_at',
    db_prefix() . 'alm_call_logs.ended_at as ended_at',
    db_prefix() . 'alm_call_logs.recording_url as recording_url',
    db_prefix() . 'alm_campaign_numbers.lead_id as lead_id',
    db_prefix() . 'alm_call_logs.id as id',
];

$sIndexColumn = 'id';
$sTable       = db_prefix() . 'alm_call_logs';
$where        = [];
$join         = [
    'LEFT JOIN ' . db_prefix() . 'alm_campaign_numbers ON ' . db_prefix() . 'alm_campaign_numbers.call_log_id = ' . db_prefix() . 'alm_call_logs.id',
];

// Filter by campaign ID through campaign_numbers table
if ($campaign_id) {
    array_push($where, 'AND ' . db_prefix() . 'alm_campaign_numbers.campaign_id=' . (int) $campaign_id);
}

$result = data_tables_init($aColumns, $sIndexColumn, $sTable, $join, $where, [
    db_prefix() . 'alm_call_logs.call_id',
    db_prefix() . 'alm_call_logs.from_number',
    db_prefix() . 'alm_call_logs.summary',
    db_prefix() . 'alm_call_logs.transcripts',
    db_prefix() . 'alm_call_logs.price',
    db_prefix() . 'alm_call_logs.ai_provider',
    db_prefix() . 'alm_campaign_numbers.phone_number',
    db_prefix() . 'alm_campaign_numbers.customer_email'
]);

$output  = $result['output'];
$rResult = $result['rResult'];

foreach ($rResult as $aRow) {
    $row = [];
    
    // 1. Phone Number
    $phone_number = $aRow['to_number'] ?: '';
    $row[] = '<strong>' . htmlspecialchars($phone_number) . '</strong>';
    
    // 2. Customer Name
    $customer_name = $aRow['customer_name'] ?: 'Unknown';
    $row[] = '<strong>' . htmlspecialchars($customer_name) . '</strong>';
    
    // 3. Call Status
    $call_status = $aRow['call_status'] ?: 'unknown';
    $status_colors = [
        'completed' => 'success',
        'busy' => 'warning',
        'no-answer' => 'warning',
        'failed' => 'danger',
        'cancelled' => 'default',
        'in-progress' => 'info'
    ];
    
    $status_color = isset($status_colors[$call_status]) ? $status_colors[$call_status] : 'default';
    $status_display = '<span class="label label-' . $status_color . '">' . ucfirst(str_replace('-', ' ', $call_status)) . '</span>';
    $row[] = $status_display;
    
    // 4. Duration
    $call_length = (float) ($aRow['call_length'] ?: 0);
    if ($call_length > 0) {
        // Convert seconds to minutes for the helper function, or use it directly if already in minutes
        // Based on VAPI webhook data, call_length appears to be in minutes (e.g., 1.6848 minutes)
        $duration_display = convert_duration($call_length);
        $row[] = '<span class="badge badge-info">' . $duration_display . '</span>';
    } else {
        $row[] = '<span class="text-muted">-</span>';
    }
    
    // 5. Started At
    $started_at = $aRow['started_at'] ?: '';
    $row[] = $started_at ? _dt($started_at) : '-';
    
    // 6. Ended At
    $ended_at = $aRow['ended_at'] ?: '';
    $row[] = $ended_at ? _dt($ended_at) : '-';
    
    // 7. Recording
    $recording_url = $aRow['recording_url'] ?: '';
    if ($recording_url) {
        $row[] = '<a href="' . htmlspecialchars($recording_url) . '" target="_blank" class="text-success" title="Play Recording">
                    <i class="fa fa-play-circle"></i> Play
                  </a>';
    } else {
        $row[] = '<span class="text-muted">No Recording</span>';
    }
    
    // 8. Lead Created
    $lead_id = $aRow['lead_id'] ?: '';
    if ($lead_id) {
        $row[] = '<a href="' . admin_url('leads/index/' . $lead_id) . '" class="text-success" target="_blank" title="View Lead">
                    <i class="fa fa-user"></i> View Lead
                  </a>';
    } else {
        $row[] = '<span class="text-muted">No Lead</span>';
    }
    
    // 9. Actions
    $actions = '<div class="row-options">';
    $call_log_id = $aRow['id'] ?: '';
    
    // View call log details
    $actions .= '<a href="#" onclick="init_alm_call_log_modal(' . $call_log_id . ');" class="text-info" title="View Call Details">
                   <i class="fa fa-eye"></i>
                 </a>';
    
    // Summary/Transcripts if available
    if (!empty($aRow['summary']) || !empty($aRow['transcripts'])) {
        $actions .= ' <a href="#" onclick="init_alm_call_log_modal(' . $call_log_id . ');" class="text-primary" title="View Summary & Transcripts">
                       <i class="fa fa-file-text"></i>
                     </a>';
    }
    
    $actions .= '</div>';
    $row[] = $actions;
    
    $row['DT_RowClass'] = 'has-row-options';
    
    $output['aaData'][] = $row;
}

echo json_encode($output);
die;