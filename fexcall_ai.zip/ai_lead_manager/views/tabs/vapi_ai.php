<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="row">
    <input type="hidden" id="user_id" value="<?php echo get_staff_user_id() ?>">
    <div class="col-md-12">
        <p class="text-info"><i class="fa fa-info-circle"></i> Configure your VAPI.ai integration settings. Manage API keys, voice settings, knowledge bases, and phone numbers from the organized tabs below.</p>

        <!-- VAPI Sub-tabs Navigation -->
        <div class="vapi-sub-tabs">
            <ul class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active">
                    <a href="#vapi-basic-config" aria-controls="vapi-basic-config" role="tab" data-toggle="tab">
                        <i class="fa fa-cog"></i> Basic Configuration
                    </a>
                </li>
                <li role="presentation">
                    <a href="#vapi-knowledge-base" aria-controls="vapi-knowledge-base" role="tab" data-toggle="tab">
                        <i class="fa fa-database"></i> Knowledge Base
                    </a>
                </li>
                <li role="presentation">
                    <a href="#vapi-phone-numbers" aria-controls="vapi-phone-numbers" role="tab" data-toggle="tab">
                        <i class="fa fa-phone"></i> Phone Numbers
                    </a>
                </li>
            </ul>
        </div>

        <!-- VAPI Sub-tabs Content -->
        <div class="tab-content vapi-tab-content">

            <!-- Basic Configuration Tab -->
            <div role="tabpanel" class="tab-pane active" id="vapi-basic-config">
                <div class="row" style="margin-top: 20px;">
                    <div class="col-md-12">
                        <h4 class="tw-font-semibold"><i class="fa fa-key text-primary"></i> API Configuration</h4>
                        <p class="text-info"><i class="fa fa-info-circle"></i> Enter your API Keys from <a href="https://dashboard.vapi.ai/org/api-keys" target="_blank">Vapi.ai Dashboard Settings</a> to enable seamless AI-powered voice assistant features.</p>
                    </div>
                    <div class="col-md-6">
                        <?php echo render_input('settings[vapi_ai_api_key]', 'Vapi.ai Private API Key <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Your private Vapi.ai API key is required for server-side operations like making outbound calls and managing assistants. You can find this in your Vapi.ai dashboard under API Keys section."></i>', get_option('vapi_ai_api_key'), 'text', ['placeholder' => 'Enter your Vapi AI Private API Key']); ?>
                    </div>
                    <div class="col-md-6">
                        <?php echo render_input('settings[vapi_ai_public_key]', 'Vapi.ai Public Key (for Web Calls) <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Your public Vapi.ai key is required for browser-based voice calls and web SDK operations. This key is safe to use in client-side code. You can find this in your Vapi.ai dashboard under API Keys section."></i>', get_option('vapi_ai_public_key'), 'text', ['placeholder' => 'Enter your Vapi AI Public Key']); ?>
                    </div>
                    <?php
                    // Get assistant information with status
                    $assistant_info = alm_vapi_ai_get_assistant_info();

                    // Show for all cases except when no API key is provided
                    if ($assistant_info['status'] !== 'no_assistant' || get_option('vapi_ai_api_key')): ?>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>
                                AI Assistant Status
                                <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Shows the current status of your AI assistant configuration and connection to VAPI."></i>
                            </label>
                            <div class="assistant-status-display">
                                <?php if ($assistant_info['status'] === 'found'): ?>
                                    <div class="alert alert-success" style="margin-bottom: 5px; padding: 10px;">
                                        <i class="fa fa-check-circle"></i> <strong><?= htmlspecialchars($assistant_info['name']) ?></strong>
                                        <br><small class="text-muted">
                                            ID: <?= htmlspecialchars($assistant_info['id']) ?> •
                                            Model: <?= htmlspecialchars($assistant_info['model']) ?>
                                            <?php if ($assistant_info['createdAt']): ?>
                                                • Created: <?= date('M j, Y', strtotime($assistant_info['createdAt'])) ?>
                                            <?php endif; ?>
                                        </small>
                                    </div>

                                <?php elseif ($assistant_info['status'] === 'not_found'): ?>
                                    <div class="alert alert-warning" style="margin-bottom: 5px; padding: 10px;">
                                        <i class="fa fa-refresh"></i> <strong>Assistant Missing</strong>
                                        <br><small class="text-muted">
                                            <?= htmlspecialchars($assistant_info['message']) ?>
                                        </small>
                                    </div>

                                <?php elseif ($assistant_info['status'] === 'no_assistant'): ?>
                                    <div class="alert alert-info" style="margin-bottom: 5px; padding: 10px;">
                                        <i class="fa fa-magic"></i> <strong>Ready to Create Assistant</strong>
                                        <br><small class="text-muted">
                                            <?= htmlspecialchars($assistant_info['message']) ?>
                                        </small>
                                    </div>

                                <?php elseif ($assistant_info['status'] === 'error'): ?>
                                    <div class="alert alert-danger" style="margin-bottom: 5px; padding: 10px;">
                                        <i class="fa fa-times-circle"></i> <strong>Connection Error</strong>
                                        <br><small class="text-muted">
                                            ID: <?= htmlspecialchars($assistant_info['id']) ?> •
                                            <?= htmlspecialchars($assistant_info['message']) ?>
                                        </small>
                                    </div>

                                <?php elseif ($assistant_info['status'] === 'no_api_key'): ?>
                                    <div class="alert alert-info" style="margin-bottom: 5px; padding: 10px;">
                                        <i class="fa fa-key"></i> <strong>Cannot Verify Assistant</strong>
                                        <br><small class="text-muted">
                                            ID: <?= htmlspecialchars($assistant_info['id']) ?> •
                                            <?= htmlspecialchars($assistant_info['message']) ?>
                                        </small>
                                    </div>

                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <?php if (get_option('vapi_ai_api_key') != ''): ?>
                <div class="row">
                    <div class="col-md-12">
                        <hr>
                        <h4 class="tw-font-semibold"><i class="fa fa-phone text-primary"></i> Phone Number Assignment</h4>
                        <p class="text-info"><i class="fa fa-info-circle"></i> Select which phone number to use for both inbound and outbound calls. Choose from your existing phone numbers across all providers (VAPI, Twilio, BYO SIP Trunk).</p>
                    </div>
                    <div class="col-md-10">
                        <?php
                        // Get all available phone numbers for selection
                        $phone_numbers = alm_vapi_ai_get_phone_numbers();
                        $phone_number_options = [];

                        if (!empty($phone_numbers)) {
                            foreach ($phone_numbers as $phone) {
                                if (isset($phone['id'])) {
                                    $display_number = $phone['number'] ?? $phone['sipUri'] ?? 'Unknown';
                                    $provider_label = '';

                                    // Add provider badge to display
                                    switch (strtolower($phone['provider'] ?? '')) {
                                        case 'vapi':
                                            $provider_label = '[VAPI] ';
                                            break;
                                        case 'twilio':
                                            $provider_label = '[Twilio] ';
                                            break;
                                        case 'byo-phone-number':
                                            $provider_label = '[BYO SIP] ';
                                            break;
                                        case 'byo-sip':
                                            $provider_label = '[SIP] ';
                                            break;
                                        default:
                                            $provider_label = '[' . ucfirst($phone['provider'] ?? 'Unknown') . '] ';
                                    }

                                    $name = !empty($phone['name']) ? ' - ' . $phone['name'] : '';
                                    $display_text = $provider_label . $display_number . $name;

                                    $phone_number_options[] = [
                                        'id' => $phone['id'],
                                        'name' => $display_text
                                    ];
                                }
                            }
                        }

                        echo render_select(
                            'settings[vapi_ai_selected_phone_number_id]',
                            $phone_number_options,
                            ['id', 'name'],
                            'Active Phone Number <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Select the phone number that will be used for both inbound and outbound calls. This number will be assigned to your AI assistant."></i>',
                            get_option('vapi_ai_selected_phone_number_id'),
                            [],
                            [],
                            '',
                            '',
                            false
                        );
                        ?>
                    </div>
                    <div class="col-md-2">
                        <div style="padding-top: 25px;">
                            <a href="#vapi-phone-numbers" class="btn btn-success btn-sm" onclick="$('a[href=\'#vapi-phone-numbers\']').tab('show')">
                                <i class="fa fa-plus"></i> Add New Number
                            </a>
                        </div>
                    </div>

                    <?php if (empty($phone_numbers)): ?>
                    <div class="col-md-12">
                        <div class="alert alert-warning">
                            <i class="fa fa-warning"></i> <strong>No Phone Numbers Found!</strong>
                            You need to add at least one phone number before you can use the AI assistant.
                            <a href="#vapi-phone-numbers" onclick="$('a[href=\'#vapi-phone-numbers\']').tab('show')" class="alert-link">
                                Click here to add a phone number.
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>


                <?php if (get_option('vapi_ai_api_key') != ''): ?>
                <div class="row">
                    <div class="col-md-12">
                        <hr>
                        <h4 class="tw-font-semibold"><i class="fa fa-microphone text-success"></i> Voice & AI Settings</h4>
                    </div>

        <div class="col-md-4">
            <?php echo render_input('settings[vapi_ai_max_duration]', 'Max Call Duration (secs) <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="This is the maximum number of seconds that the call will last. When the call reaches this duration, it will be ended."></i>', get_option('vapi_ai_max_duration'), "number", ['min' => 10, 'max' => 43200]); ?>
        </div>

        <div class="col-md-4">
            <?php echo render_select('settings[vapi_ai_voice_provider]', alm_vapi_ai_get_voice_providers(), ['id', 'name'], 'Voice Provider <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Choose the voice provider for your AI assistant. Different providers offer various voice qualities and languages. Popular options include OpenAI, ElevenLabs, and Azure."></i>', get_option('vapi_ai_voice_provider')); ?>
        </div>

        <div class="col-md-4" id="vapi_agent_voice_select" <?= (get_option('vapi_ai_is_custom_voice_id') != 0 ? 'style="display: none;"' : '') ?>>
            <?php
            echo render_select_with_input_group('settings[vapi_ai_agent_voice]', alm_vapi_ai_get_voices(get_option('vapi_ai_voice_provider')), ['providerId', 'name', 'provider'], 'AI Assistant Voice <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Select the specific voice your AI assistant will use. Click the play button to preview the voice. Choose a voice that matches your brand personality and target audience."></i>', get_option('vapi_ai_agent_voice'), '<div class="input-group-btn"><a href="#" class="btn btn-default" onclick="play_selected_voice_vapi();return false;" class="inline-field-new" title="Preview Voice"><i class="fa fa-volume-high"></i></a></div>');
            ?>
        </div>

        <div class="col-md-4" id="vapi_custom_id_input" <?= (get_option('vapi_ai_is_custom_voice_id') == 0 ? 'style="display: none;"' : '') ?>>
            <?= render_input('settings[vapi_ai_agent_voice_id]', 'Custom Voice ID <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Enter a custom voice ID if you have a specific voice clone or custom voice not available in the dropdown list. This is usually provided by your voice provider."></i>', get_option('vapi_ai_agent_voice_id'), 'text', ['placeholder' => 'Enter custom voice ID']) ?>
        </div>

        <div class="col-md-4">
            <?= form_hidden('settings[vapi_ai_is_custom_voice_id]', 0) ?>
            <div class="checkbox checkbox-primary tw-pt-2">
                <input type="checkbox" id="vapi_ai_is_custom_voice_id" name="settings[vapi_ai_is_custom_voice_id]" value="1" <?= (get_option('vapi_ai_is_custom_voice_id') == 1 ? 'checked' : '') ?>>
                <label for="vapi_ai_custom_voice_id" data-toggle="tooltip" data-title="Enable this option if you want to manually enter a custom voice ID instead of selecting from the available voices.">Use Custom Voice ID</label>
            </div>
        </div>

        <div class="col-md-4">
            <div class="form-group">
                <?php echo render_yes_no_option(
                    'filler_injection_enabled',
                    'Natural Speech Filler Injection',
                    'When enabled, the AI will add natural speech fillers (like \'um\', \'uh\') to make conversations sound more human and natural. This can improve the conversational flow.'
                ); ?>
            </div>
        </div>

        <div class="col-md-4">
            <div class="form-group">
                <?php echo render_yes_no_option(
                    'back_channeling_enabled',
                    'Back-Channeling Responses',
                    'When enabled, the AI will provide verbal feedback (like \'mhmm\', \'I see\', \'yes\') while listening to the caller, making conversations feel more natural and engaging.'
                ); ?>
            </div>
        </div>
        <div class="col-md-12">
            <hr>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <?php echo render_yes_no_option(
                    'end_call_function_enabled',
                    'Assistant Call Termination',
                    'When enabled, the AI assistant can intelligently end calls when the conversation is complete or when appropriate. Recommended for advanced models like GPT-4 for better decision-making.'
                ); ?>
            </div>
        </div>

        <div class="col-md-4">
            <div class="form-group">
                <?php echo render_yes_no_option(
                    'dial_keypad_function_enabled',
                    'Keypad Dialing Function',
                    'When enabled, the AI assistant can dial numbers on the phone keypad during calls. This is useful for navigating phone menus or entering codes during conversations.'
                ); ?>
            </div>
        </div>


        <div class="col-md-12">
            <hr>
        </div>

        <div class="col-md-4">
            <?php
            echo render_input('settings[vapi_ai_temperature]', 'Temperature <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="The temperature is used to control the randomness of the output. When you set it higher, you\'ll get more random outputs. When you set it lower, towards 0, the values are more deterministic."></i>', get_option('vapi_ai_temperature'), "number", ['min' => 0.0, 'max' => 2.0, 'step' => 0.1]);
            ?>
            <input type="range" id="vapi_ai_temperature" min="0.0" max="2.0" step="0.1" value="<?= get_option('vapi_ai_temperature'); ?>" style="width: 100%; margin-top: 10px;" />
        </div>

        <div class="col-md-4">
            <?php echo render_input('settings[vapi_ai_max_tokens]', 'Max Tokens <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="This is the max number of tokens that the assistant will be allowed to generate in each turn of the conversation."></i>', get_option('vapi_ai_max_tokens'), "number", ['min' => 10, 'max' => 43200]); ?>
        </div>

        <div class="col-md-4">
            <div class="form-group">
                <?php echo render_yes_no_option(
                    'vapi_ai_detect_emotions',
                    'Emotion Detection',
                    'When enabled, the AI will analyze and detect the caller\'s emotions (like happiness, frustration, anger) during conversations. This emotional context helps the assistant respond more appropriately and empathetically.'
                ); ?>
            </div>
        </div>
                    <div class="col-md-12">
                        <hr>
                        <h4 class="tw-font-semibold"><i class="fa fa-wrench text-warning"></i> Assistant Tools & Integration</h4>
                    </div>

                    <div class="col-md-6">
                        <?php 
                            $label = 'Inbound Assistant Tools <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Select tools that will be available to the AI assistant during inbound calls. These tools help the assistant perform specific functions like booking appointments, checking availability, or accessing external data."></i>';
                            echo render_select('settings[vapi_ai_tools_inbound][]', alm_vapi_ai_get_tools(), ['id', 'name', 'id'], $label, json_decode(get_option('vapi_ai_tools_inbound')), ['multiple' => true]); 
                        ?>
                    </div>
                    <div class="col-md-6">
                        <?php 
                            $label = 'Outbound Assistant Tools <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Select tools that will be available to the AI assistant during outbound calls. These tools enable the assistant to perform actions like updating lead information, scheduling follow-ups, or accessing customer data."></i>';
                            echo render_select('settings[vapi_ai_tools_outbound][]', alm_vapi_ai_get_tools(), ['id', 'name','id'], $label, json_decode(get_option('vapi_ai_tools_outbound')), ['multiple' => true]); ?>
                    </div>

                    <div class="col-md-6">
                        <?php echo render_select('settings[vapi_ai_knowledgebase_inbound][]', alm_vapi_ai_get_knowledge_base_tools(), ['id', 'name'], 'Inbound Assistant Knowledge Base <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Select knowledge bases that the AI assistant can query during inbound calls. These contain information about your products, services, policies, or procedures that the assistant can reference to answer customer questions."></i>', array_filter(json_decode(get_option('vapi_ai_knowledgebase_inbound'))), ['multiple' => true]); ?>
                    </div>
                    <div class="col-md-6">
                        <?php echo render_select('settings[vapi_ai_knowledgebase_outbound][]', alm_vapi_ai_get_knowledge_base_tools(), ['id', 'name'], 'Outbound Assistant Knowledge Base <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Select knowledge bases that the AI assistant can query during outbound calls. These help the assistant provide accurate information about your offerings, handle objections, and answer prospect questions during sales or follow-up calls."></i>', array_filter(json_decode(get_option('vapi_ai_knowledgebase_outbound'))), ['multiple' => true]); ?>
                    </div>

                    <div class="col-md-12">
                        <hr>
                        <h4 class="tw-font-semibold"><i class="fa fa-phone-square text-info"></i> Call Forwarding Configuration</h4>
                        <p class="text-info"><i class="fa fa-info-circle"></i> Configure call forwarding to redirect calls to specific phone numbers when needed. The AI assistant can transfer calls to human agents or departments during conversations.</p>
                    </div>

                    <div class="col-md-6">
                        <?php echo render_input('settings[vapi_ai_forwarding_number]', 'Forwarding Phone Number <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Enter the phone number to forward calls to in E.164 format (e.g., +1234567890). This number will be used when the AI assistant needs to transfer calls to a human agent."></i>', get_option('vapi_ai_forwarding_number'), 'text', ['placeholder' => '+1234567890']); ?>
                    </div>
                    <div class="col-md-6">
                        <?php echo render_input('settings[vapi_ai_forwarding_message]', 'Transfer Message <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Message the AI assistant will say before transferring the call. Keep it brief and professional."></i>', get_option('vapi_ai_forwarding_message'), 'text', ['placeholder' => 'Let me transfer you to our specialist who can better assist you.']); ?>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <?php echo render_yes_no_option(
                                'vapi_ai_enable_call_forwarding',
                                'Enable Call Forwarding',
                                'When enabled, the AI assistant will have the ability to transfer calls to the configured forwarding number. This adds a transfer tool to the assistant\'s capabilities.'
                            ); ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Knowledge Base Tab -->
            <div role="tabpanel" class="tab-pane" id="vapi-knowledge-base">
                <div class="row" style="margin-top: 20px;">
                    <div class="col-md-12">
                        <!-- File Management Section -->
                        <div class="row">
                            <div class="col-md-10">
                                <h4 class="tw-font-semibold"><i class="fa fa-files-o"></i> Assistant Knowledge Files</h4>
                                <p class="tw-mb-3 text-info">Upload documents, PDFs, manuals, and other files that your AI assistant can reference. These files will be processed and made available for creating knowledge bases that enhance your assistant's ability to provide accurate, informed responses.</p>
                            </div>
                            <div class="col-md-2">
                                <div class="btn btn-info" data-toggle="modal" data-target="#file_upload_modal"><i class="fa fa-upload"></i> Upload File</div>
                            </div>
                        </div>
        
        <!-- Uploaded Files Table -->
        <div class="row">
            <div class="col-md-12">
                <h5>Uploaded Files</h5>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Size</th>
                            <th>Uploaded</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (alm_vapi_ai_get_raw_files() as $file): ?>
                            <tr>
                                <td><?= htmlspecialchars($file['name']); ?></td>
                                <td><?= alm_format_bytes($file['bytes'] ?? $file['size'] ?? $file['sizeBytes'] ?? 0); ?></td>
                                <td><?= _dt($file['createdAt'] ?? ''); ?></td>
                                <td>
                                    <a href="<?= admin_url('ai_lead_manager/delete_file/vapi/' . $file['id']); ?>" 
                                       class="btn btn-danger btn-sm" 
                                       onclick="return confirm('Are you sure? This will delete the file.')">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="col-md-12"><hr></div>

        <!-- Knowledge Base Management Section -->
        <div class="row">
            <div class="col-md-10">
                <h4 class="tw-font-semibold"><i class="fa fa-database"></i> AI Assistant Knowledge Bases</h4>
                <p class="tw-mb-3 text-info">Create knowledge bases by grouping related files together. Each knowledge base becomes a specialized information source that your AI assistant can query to provide accurate, context-aware responses during conversations. Examples: Product Catalog, Company Policies, FAQ Documents, Technical Manuals.</p>
            </div>
            <div class="col-md-2">
                <div class="btn btn-primary" data-toggle="modal" data-target="#vapi_ai_kwnowledgebase_modal"><i class="fa fa-plus"></i> Create Knowledge Base</div>
            </div>
        </div>
        
        <!-- Knowledge Bases Table -->
        <div class="row">
            <div class="col-md-12">
                <h5>Knowledge Bases</h5>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Provider</th>
                            <th>Files</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (alm_vapi_ai_get_knowledge_base_tools() as $kb): ?>
                            <tr>
                                <td><?= htmlspecialchars($kb['name']); ?></td>
                                <td><?= ucfirst($kb['knowledgeBases'][0]['provider'] ?? 'google'); ?></td>
                                <td>
                                    <span class="badge badge-info">
                                        <?= count($kb['knowledgeBases'][0]['fileIds'] ?? []); ?> files
                                    </span>
                                </td>
                                <td><?= _dt($kb['createdAt'] ?? ''); ?></td>
                                <td>
                                    <button class="btn btn-primary btn-sm edit-kb-btn" 
                                            data-kb-id="<?= $kb['id']; ?>"
                                            data-kb-name="<?= htmlspecialchars($kb['name']); ?>"
                                            data-kb-description="<?= htmlspecialchars($kb['knowledgeBases'][0]['description'] ?? ''); ?>"
                                            data-kb-fileids='<?= json_encode($kb['knowledgeBases'][0]['fileIds'] ?? []); ?>'>
                                        <i class="fa fa-edit"></i>
                                    </button>
                                    <a href="<?= admin_url('ai_lead_manager/delete_knowledgebase/vapi_ai/' . $kb['id']); ?>" 
                                       class="btn btn-danger btn-sm" 
                                       onclick="return confirm('Are you sure? This will delete the knowledge base and all associated files.')">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                    <button class="btn btn-info btn-sm" 
                                            onclick="viewKnowledgebaseFiles('<?= $kb['id']; ?>')">
                                        <i class="fa fa-eye"></i> View Files
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
                    </div>
                </div>
            </div>

            <!-- Phone Numbers Tab -->
            <div role="tabpanel" class="tab-pane" id="vapi-phone-numbers">
                <div class="row" style="margin-top: 20px;">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-10">
                                <h4 class="tw-font-semibold"><i class="fa fa-phone"></i> Phone Number Management</h4>
                                <p class="tw-mb-3 text-info">Manage your VAPI phone numbers. You can create free US numbers, configure SIP integration, or import existing Twilio numbers.</p>
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#create_phone_number_modal">
                                    <i class="fa fa-plus"></i> Add Phone Number
                                </button>
                            </div>
                        </div>

                        <!-- Existing Phone Numbers Table -->
                        <div class="row">
                            <div class="col-md-12">
                                <table class="table table-striped" id="vapi-phone-numbers-table">
                                    <thead>
                                        <tr>
                                            <th>Number</th>
                                            <th>Provider</th>
                                            <th>Name</th>
                                            <th>Assistant</th>
                                            <th>Created</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="phone-numbers-list">
                                        <?php
                                        $phone_numbers = alm_vapi_ai_get_phone_numbers();

                                        if (empty($phone_numbers)): ?>
                                            <tr>
                                                <td colspan="6" class="text-center text-muted">
                                                    <?php if (empty(get_option('vapi_ai_api_key'))): ?>
                                                        <i class="fa fa-key text-warning"></i> Please configure your VAPI API key in the Basic Configuration tab first.
                                                    <?php else: ?>
                                                        <i class="fa fa-info-circle"></i> No phone numbers found. Click "Add Phone Number" to create one.
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php else: ?>
                                            <?php foreach ($phone_numbers as $phone): ?>
                                                <tr>
                                                    <td>
                                                        <?php
                                                        $display_number = $phone['number'] ?? $phone['sipUri'] ?? 'N/A';
                                                        $is_sip = !empty($phone['sipUri']);
                                                        ?>
                                                        <strong><?= htmlspecialchars($display_number) ?></strong>
                                                        <?php if ($is_sip): ?>
                                                            <br><small class="text-muted"><i class="fa fa-network-wired"></i> SIP Endpoint</small>
                                                        <?php elseif (!empty($phone['twilioPhoneNumber'])): ?>
                                                            <br><small class="text-muted"><?= htmlspecialchars($phone['twilioPhoneNumber']) ?></small>
                                                        <?php endif; ?>
                                                        <?php if ($phone['id'] == get_option('vapi_ai_selected_phone_number_id')): ?>
                                                            <br><small class="text-primary"><i class="fa fa-star"></i> <strong>Active Number</strong></small>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $provider = ucfirst($phone['provider'] ?? 'Unknown');
                                                        $badge_class = '';
                                                        switch (strtolower($phone['provider'] ?? '')) {
                                                            case 'vapi':
                                                                $badge_class = 'badge-success';
                                                                break;
                                                            case 'twilio':
                                                                $badge_class = 'badge-warning';
                                                                break;
                                                            case 'byo-sip':
                                                                $badge_class = 'badge-info';
                                                                $provider = 'SIP';
                                                                break;
                                                            case 'byo-phone-number':
                                                                $badge_class = 'badge-primary';
                                                                $provider = 'BYO SIP Trunk';
                                                                break;
                                                            default:
                                                                $badge_class = 'badge-secondary';
                                                        }
                                                        ?>
                                                        <span class="badge <?= $badge_class ?>"><?= $provider ?></span>
                                                    </td>
                                                    <td><?= htmlspecialchars($phone['name'] ?? 'Unnamed') ?></td>
                                                    <td>
                                                        <?php if (!empty($phone['assistantId'])): ?>
                                                            <span class="badge badge-success">
                                                                <i class="fa fa-link"></i> Connected
                                                            </span>
                                                            <br><small class="text-muted"><?= htmlspecialchars(substr($phone['assistantId'], 0, 8)) ?>...</small>
                                                        <?php else: ?>
                                                            <span class="badge badge-warning">
                                                                <i class="fa fa-unlink"></i> No Assistant
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $created_at = $phone['createdAt'] ?? '';
                                                        if (!empty($created_at)) {
                                                            echo _dt($created_at);
                                                        } else {
                                                            echo '<span class="text-muted">-</span>';
                                                        }
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <div class="btn-group">
                                                            <button type="button" class="btn btn-primary btn-sm"
                                                                    onclick="editPhoneNumber(<?= htmlspecialchars(json_encode($phone), ENT_QUOTES, 'UTF-8') ?>)"
                                                                    data-toggle="tooltip" title="Edit phone number">
                                                                <i class="fa fa-edit"></i>
                                                            </button>
                                                            <button type="button" class="btn btn-danger btn-sm"
                                                                    onclick="deletePhoneNumber('<?= htmlspecialchars($phone['id'] ?? '') ?>', '<?= htmlspecialchars($phone['number'] ?? '') ?>')"
                                                                    data-toggle="tooltip" title="Delete phone number">
                                                                <i class="fa fa-trash"></i>
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>


    <style>
    /* Assistant Status Display Styling */
    .assistant-status-display .alert {
        border-radius: 6px;
        border-left: 4px solid;
        font-size: 13px;
        line-height: 1.4;
    }

    .assistant-status-display .alert-success {
        border-left-color: #5cb85c;
        background-color: #f4fdf4;
        border-color: #d6e9c6;
        color: #3c763d;
    }

    .assistant-status-display .alert-warning {
        border-left-color: #f0ad4e;
        background-color: #fcf8e3;
        border-color: #faebcc;
        color: #8a6d3b;
    }

    .assistant-status-display .alert-danger {
        border-left-color: #d9534f;
        background-color: #fdf2f2;
        border-color: #ebccd1;
        color: #a94442;
    }

    .assistant-status-display .alert-info {
        border-left-color: #5bc0de;
        background-color: #f0f9ff;
        border-color: #bce8f1;
        color: #31708f;
    }

    .assistant-status-display .alert i {
        margin-right: 8px;
        font-size: 14px;
    }

    .assistant-status-display .btn {
        margin-right: 8px;
        font-size: 11px;
        padding: 4px 8px;
    }

    /* Hide VAPI default floating button since we have custom interface */
    .vapi-support-btn,
    #vapi-support-btn,
    [class*="vapi-btn"],
    [id*="vapi-btn"],
    [class*="vapi-widget"],
    [id*="vapi-widget"] {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
    }

    /* Style our custom voice call interface */
    .voice-call-controls {
        text-align: center;
        padding: 20px;
        background: #f8f9fa;
        border-radius: 8px;
        margin: 10px 0;
    }

    .call-timer {
        font-weight: bold;
        color: #28a745;
    }

    .transcript-content {
        font-family: monospace;
        line-height: 1.6;
    }

    /* VAPI Sub-tabs Styling */
    .vapi-sub-tabs {
        margin: 15px 0;
    }

    .vapi-sub-tabs .nav-tabs > li > a {
        border-radius: 4px 4px 0 0;
        color: #5a5c69;
        font-weight: 500;
        transition: all 0.3s ease;
    }

    .vapi-sub-tabs .nav-tabs > li > a:hover {
        background-color: #f8f9fc;
        color: #4e73df;
    }

    .vapi-sub-tabs .nav-tabs > li.active > a,
    .vapi-sub-tabs .nav-tabs > li.active > a:hover,
    .vapi-sub-tabs .nav-tabs > li.active > a:focus {
        border-radius: 4px 4px 0 0;
        background-color: #4e73df;
        color: white;
    }

    /* Phone Configuration Sections in Modal */
    #create_phone_number_modal .phone-config-section {
        border: 1px solid #e3e6f0;
        border-radius: 8px;
        padding: 15px;
        margin: 10px 0;
        background-color: #f8f9fc;
    }

    #create_phone_number_modal .radio input[type="radio"] {
        margin-right: 10px;
    }

    #create_phone_number_modal .radio label {
        font-weight: 500;
        color: #5a5c69;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    #create_phone_number_modal .radio label i {
        font-size: 16px;
    }

    #create_phone_number_modal .radio input[type="radio"]:checked + label {
        color: #4e73df;
        font-weight: 600;
    }
    </style>

    <script>
    function viewKnowledgebaseFiles(kbId) {
        // You can implement a modal to show files in this knowledge base
        alert('Knowledge Base ID: ' + kbId + '\n\nThis feature can be enhanced to show detailed file information.');
    }
    
    // Phone Number Modal functionality
    document.addEventListener('DOMContentLoaded', function() {
        // Debug: Check if modal and form exist on page load
        console.log('DOM loaded - checking for modal elements');
        console.log('Modal exists:', !!document.getElementById('create_phone_number_modal'));
        console.log('Form exists:', !!document.getElementById('phone_number_form'));
        console.log('Button exists:', !!document.getElementById('create_phone_number_btn'));
        // Modal phone number type switching
        function toggleModalPhoneNumberSections() {
            const sections = document.querySelectorAll('#create_phone_number_modal .phone-config-section');
            sections.forEach(section => section.style.display = 'none');

            // Remove required attribute from all hidden fields to prevent HTML5 validation errors
            const allRequiredFields = document.querySelectorAll('#create_phone_number_modal [required]');
            allRequiredFields.forEach(field => field.removeAttribute('required'));

            const selectedType = document.querySelector('#create_phone_number_modal input[name="phone_number_type"]:checked');
            if (selectedType) {
                const targetSection = 'modal_' + selectedType.value + '_section';
                const section = document.getElementById(targetSection);
                if (section) {
                    section.style.display = 'block';

                    // Add required attribute back to visible required fields
                    if (selectedType.value === 'vapi_sip') {
                        const sipIdentifier = document.getElementById('modal_sip_identifier');
                        if (sipIdentifier) {
                            sipIdentifier.setAttribute('required', 'required');
                        }
                    } else if (selectedType.value === 'byo_sip_trunk') {
                        const byoNumberField = document.getElementById('modal_byo_number');
                        if (byoNumberField) {
                            byoNumberField.setAttribute('required', 'required');
                        }
                    } else if (selectedType.value === 'twilio') {
                        const twilioFields = ['modal_twilio_account_sid', 'modal_twilio_auth_token', 'modal_twilio_account_number'];
                        twilioFields.forEach(fieldId => {
                            const field = document.getElementById(fieldId);
                            if (field) {
                                field.setAttribute('required', 'required');
                            }
                        });
                    }
                }
            }
        }

        // Initialize modal sections
        toggleModalPhoneNumberSections();

        // Add event listeners to modal radio buttons
        const modalPhoneTypeRadios = document.querySelectorAll('#create_phone_number_modal input[name="phone_number_type"]');
        modalPhoneTypeRadios.forEach(radio => {
            radio.addEventListener('change', toggleModalPhoneNumberSections);
        });

        // Phone numbers are now loaded via PHP on page load
        // No need for separate loading function since data is already rendered

        // Handle phone number form submission with AJAX
        $(document).on('submit', '#phone_number_form', function(e) {
            e.preventDefault(); // Always prevent default form submission for AJAX

            console.log('Phone number form submitted via AJAX');

            const form = this;
            const $form = $(form);
            const $submitBtn = $('#create_phone_number_btn');
            const $modal = $('#create_phone_number_modal');
            const formData = new FormData(form);
            const phoneType = formData.get('phone_number_type');

            // Client-side validation
            let isValid = true;
            let errorMessage = '';

            if (phoneType === 'vapi_free') {
                // No validation needed for free VAPI numbers - VAPI auto-assigns
                // isValid remains true
            } else if (phoneType === 'vapi_sip') {
                const sipIdentifier = formData.get('sip_identifier');
                if (!sipIdentifier || sipIdentifier.trim() === '') {
                    isValid = false;
                    errorMessage = 'Please enter a SIP identifier.';
                }
            } else if (phoneType === 'byo_sip_trunk') {
                const byoNumber = formData.get('byo_number');
                if (!byoNumber || byoNumber.trim() === '') {
                    isValid = false;
                    errorMessage = 'Please enter a phone number for your SIP trunk.';
                }
            } else if (phoneType === 'twilio') {
                const sid = formData.get('twilio_account_sid');
                const token = formData.get('twilio_auth_token');
                const number = formData.get('twilio_account_number');
                if (!sid || !token || !number) {
                    isValid = false;
                    errorMessage = 'Please fill in all Twilio credentials (Account SID, Auth Token, and Phone Number).';
                }
            }

            if (!isValid) {
                alert_float('danger', errorMessage);
                return false;
            }

            // Show loading state
            $submitBtn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Creating...');

            // Submit form via AJAX
            $.ajax({
                url: $form.attr('action'),
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(response) {
                    console.log('AJAX Success:', response);

                    if (response.success) {
                        // Show success message
                        alert_float('success', response.message);

                        // Close modal
                        $modal.modal('hide');

                        // Reset form
                        form.reset();
                        toggleModalPhoneNumberSections();

                        // Refresh phone numbers list
                        refreshPhoneNumbersList();
                    } else {
                        // Show error message
                        alert_float('danger', response.message || 'Failed to create phone number.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', xhr.responseText);

                    let errorMessage = 'An error occurred while creating the phone number.';

                    try {
                        const response = JSON.parse(xhr.responseText);
                        if (response.message) {
                            errorMessage = response.message;
                        }
                    } catch (e) {
                        // If not JSON, use default error message
                        if (xhr.responseText) {
                            errorMessage += ' Please check the console for details.';
                        }
                    }

                    alert_float('danger', errorMessage);
                },
                complete: function() {
                    // Reset button state
                    $submitBtn.prop('disabled', false).html('<i class="fa fa-plus"></i> Create Phone Number');
                }
            });
        });

        // Helper function to show alerts (using PerfexCRM's alert system)
        function showAlert(type, message) {
            // Remove any existing alerts
            $('.alert').remove();

            // Create new alert
            const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
            const iconClass = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle';

            const alertHtml = `
                <div class="alert ${alertClass} alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <i class="fa ${iconClass}"></i> ${message}
                </div>
            `;

            // Add alert to the page
            $('.vapi-tab-content').prepend(alertHtml);

            // Auto-hide after 5 seconds
            setTimeout(function() {
                $('.alert').fadeOut();
            }, 5000);
        }

        // Helper function to refresh phone numbers list
        function refreshPhoneNumbersList() {
            // For now, we'll reload the page to refresh the list
            // In a more advanced implementation, you could make an AJAX call to get updated list
            setTimeout(function() {
                window.location.reload();
            }, 1500); // Wait 1.5 seconds to let user see the success message
        }

        // Additional script to hide VAPI default button after page load
        // Hide any VAPI default buttons that might appear
        setTimeout(function() {
            const vapiButtons = document.querySelectorAll('[class*="vapi"], [id*="vapi"]');
            vapiButtons.forEach(function(button) {
                if (button.classList.contains('vapi-support-btn') || 
                    button.id === 'vapi-support-btn' ||
                    button.classList.contains('vapi-btn') ||
                    button.classList.contains('vapi-widget')) {
                    button.style.display = 'none';
                    button.style.visibility = 'hidden';
                    button.style.opacity = '0';
                    button.style.pointerEvents = 'none';
                }
            });
        }, 2000); // Wait 2 seconds for VAPI to fully load
        
        // Periodic check to ensure button stays hidden
        setInterval(function() {
            const vapiButton = document.querySelector('.vapi-support-btn, #vapi-support-btn');
            if (vapiButton) {
                vapiButton.style.display = 'none';
            }
        }, 5000); // Check every 5 seconds
    });

    // Phone number management functions
    function editPhoneNumber(phoneData) {
        console.log('Edit phone data:', phoneData);

        // Populate the edit modal with phone data
        $('#edit_phone_id').val(phoneData.id);

        // Set phone display info
        var displayNumber = phoneData.number || phoneData.sipUri || 'N/A';
        $('#edit_phone_display').val(displayNumber);

        // Set phone type info
        var typeInfo = '';
        var providerBadge = '';

        if (phoneData.provider === 'vapi' && phoneData.sipUri) {
            typeInfo = 'Free VAPI SIP Endpoint';
            providerBadge = '<span class="badge badge-success">VAPI SIP</span>';
        } else if (phoneData.provider === 'vapi') {
            typeInfo = 'Free VAPI Phone Number';
            providerBadge = '<span class="badge badge-success">VAPI</span>';
        } else if (phoneData.provider === 'byo-phone-number') {
            typeInfo = 'BYO SIP Trunk Number';
            providerBadge = '<span class="badge badge-primary">BYO SIP Trunk</span>';
        } else if (phoneData.provider === 'twilio') {
            typeInfo = 'Twilio Phone Number';
            providerBadge = '<span class="badge badge-warning">Twilio</span>';
        } else {
            typeInfo = 'Phone Number';
            providerBadge = '<span class="badge badge-secondary">Unknown</span>';
        }

        $('#edit_phone_type_info').html(providerBadge + ' ' + typeInfo + ' - ' + displayNumber);

        // Set current assistant selection
        $('#edit_assistant_id').selectpicker('val', phoneData.assistantId || '');

        // Show the modal
        $('#edit_phone_number_modal').modal('show');
    }

    // Edit phone number form submission
    $('#edit_phone_number_form').on('submit', function(e) {
        e.preventDefault();

        var $form = $(this);
        var $submitBtn = $('#update_phone_number_btn');
        var originalHtml = $submitBtn.html();

        // Show loading state
        $submitBtn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Updating...');

        $.ajax({
            url: $form.attr('action'),
            type: 'POST',
            dataType: 'json',
            data: $form.serialize(),
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
            success: function(response) {
                if (response.success) {
                    // Show success message
                    alert_float('success', response.message);

                    // Close modal
                    $('#edit_phone_number_modal').modal('hide');

                    // Refresh page to show updated data
                    setTimeout(function() {
                        window.location.reload();
                    }, 1500);
                } else {
                    // Show error message
                    alert_float('danger', response.message || 'Failed to update phone number.');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', xhr.responseText);
                alert_float('danger', 'An error occurred while updating the phone number.');
            },
            complete: function() {
                // Reset button state
                $submitBtn.prop('disabled', false).html(originalHtml);
            }
        });
    });

    function deletePhoneNumber(phoneId, phoneNumber) {
        if (confirm('Are you sure you want to delete phone number ' + phoneNumber + '?\n\nThis action cannot be undone.')) {
            // Show loading state
            var deleteBtn = event.target.closest('button');
            var originalHtml = deleteBtn.innerHTML;
            deleteBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i>';
            deleteBtn.disabled = true;

            $.ajax({
                url: '<?= admin_url('ai_lead_manager/delete_phone_number/'); ?>' + phoneId,
                type: 'POST',
                dataType: 'json',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                success: function(response) {
                    if (response.success) {
                        // Show success message
                        alert_float('success', response.message || 'Phone number deleted successfully.');

                        // Remove the row from table
                        $(deleteBtn).closest('tr').fadeOut(300, function() {
                            $(this).remove();

                            // Check if table is empty and show no data message
                            var tbody = $('#phone-numbers-list');
                            if (tbody.find('tr').length === 0) {
                                tbody.html('<tr><td colspan="6" class="text-center text-muted"><i class="fa fa-info-circle"></i> No phone numbers found. Click "Add Phone Number" to create one.</td></tr>');
                            }
                        });
                    } else {
                        // Show error message
                        alert_float('danger', response.message || 'Failed to delete phone number.');

                        // Restore button
                        deleteBtn.innerHTML = originalHtml;
                        deleteBtn.disabled = false;
                    }
                },
                error: function(xhr, status, error) {
                    // Show error message
                    alert_float('danger', 'An error occurred while deleting the phone number.');

                    // Restore button
                    deleteBtn.innerHTML = originalHtml;
                    deleteBtn.disabled = false;
                }
            });
        }
    }

    </script>
</div>