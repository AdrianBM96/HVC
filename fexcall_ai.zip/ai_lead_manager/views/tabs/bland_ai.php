<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="row">
    <input type="hidden" id="user_id" value="<?php echo get_staff_user_id() ?>">
    <div class="col-md-12">
        <p class="text-info"><i class="fa fa-info-circle"></i> Configure your Bland.ai integration settings. Manage API keys, voice settings, knowledge bases, and phone numbers from the organized tabs below.</p>

        <!-- Bland.ai Sub-tabs Navigation -->
        <div class="bland-sub-tabs">
            <ul class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active">
                    <a href="#bland-basic-config" aria-controls="bland-basic-config" role="tab" data-toggle="tab">
                        <i class="fa fa-cog"></i> Basic Configuration
                    </a>
                </li>
                <li role="presentation">
                    <a href="#bland-knowledge-base" aria-controls="bland-knowledge-base" role="tab" data-toggle="tab">
                        <i class="fa fa-database"></i> Knowledge Base
                    </a>
                </li>
                <li role="presentation">
                    <a href="#bland-phone-numbers" aria-controls="bland-phone-numbers" role="tab" data-toggle="tab">
                        <i class="fa fa-phone"></i> Phone Numbers
                    </a>
                </li>
            </ul>
        </div>

        <!-- Bland.ai Sub-tabs Content -->
        <div class="tab-content bland-tab-content">

            <!-- Basic Configuration Tab -->
            <div role="tabpanel" class="tab-pane active" id="bland-basic-config">
                <div class="row" style="margin-top: 20px;">
                    <div class="col-md-12">
                        <h4 class="tw-font-semibold"><i class="fa fa-key text-primary"></i> API Configuration</h4>
                        <p class="text-info"><i class="fa fa-info-circle"></i> Enter your API Key from <a href="https://app.bland.ai/dashboard/settings" target="_blank">Bland.ai Dashboard Settings</a> to enable seamless AI-powered voice assistant features.</p>
                    </div>
                    <div class="col-md-12">
                        <?php echo render_input('settings[bland_ai_api_key]', 'Bland.ai API Key <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Your Bland.ai API key is required to authenticate and enable all AI voice assistant features. You can find this in your Bland.ai dashboard under Settings > API Keys section."></i>', get_option('bland_ai_api_key'), 'text', ['placeholder' => 'Enter your Bland AI API Key']); ?>
                    </div>
                </div>

                <?php if (get_option('bland_ai_api_key') != ''): ?>
                <div class="row">
                    <div class="col-md-12">
                        <hr>
                        <h4 class="tw-font-semibold"><i class="fa fa-phone text-primary"></i> Phone Number Assignment</h4>
                        <p class="text-info"><i class="fa fa-info-circle"></i> Select which phone number to use for both inbound and outbound calls. Choose from your existing phone numbers.</p>
                    </div>
                    <div class="col-md-10">
                        <?php
                        // Get all available phone numbers for selection
                        $phone_numbers = alm_bland_ai_get_phone_numbers();
                        $phone_number_options = [];

                        if (!empty($phone_numbers)) {
                            foreach ($phone_numbers as $phone) {
                                // For Bland.ai, use phone_number as the identifier
                                $phone_id = $phone['phone_number'] ?? '';
                                $display_number = $phone['phone_number'] ?? 'Unknown';
                                $name = !empty($phone['name']) ? ' - ' . $phone['name'] : '';
                                $display_text = $display_number . $name;

                                if (!empty($phone_id)) {
                                    $phone_number_options[] = [
                                        'id' => $phone_id,
                                        'name' => $display_text
                                    ];
                                }
                            }
                        }

                        echo render_select(
                            'settings[bland_ai_selected_phone_number_id]',
                            $phone_number_options,
                            ['id', 'name'],
                            'Active Phone Number <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Select the phone number that will be used for both inbound and outbound calls. This number will be assigned to your AI assistant."></i>',
                            get_option('bland_ai_selected_phone_number_id'),
                            [],
                            [],
                            '',
                            '',
                            false
                        );
                        ?>
                    </div>
                    <div class="col-md-2">
                        <div style="padding-top: 25px;">
                            <a href="#bland-phone-numbers" class="btn btn-success btn-sm" onclick="$('a[href=\'#bland-phone-numbers\']').tab('show')">
                                <i class="fa fa-plus"></i> Add New Number
                            </a>
                        </div>
                    </div>

                    <?php if (empty($phone_numbers)): ?>
                    <div class="col-md-12">
                        <div class="alert alert-warning">
                            <i class="fa fa-warning"></i> <strong>No Phone Numbers Found!</strong>
                            You need to add at least one phone number before you can use the AI assistant.
                            <a href="#bland-phone-numbers" onclick="$('a[href=\'#bland-phone-numbers\']').tab('show')" class="alert-link">
                                Click here to add a phone number.
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- BYOT Encrypted Key Verification Section -->
                <?php
                $selected_phone_id = get_option('bland_ai_selected_phone_number_id');
                $current_encrypted_key = get_option('bland_ai_encrypted_key');
                $show_byot_info = false;
                $selected_phone_info = null;

                // Check if selected phone is a BYOT number
                if (!empty($selected_phone_id) && !empty($phone_numbers)) {
                    foreach ($phone_numbers as $phone) {
                        $phone_id = $phone['phone_number'] ?? '';
                        if ($phone_id === $selected_phone_id && ($phone['type'] ?? '') === 'byot') {
                            $show_byot_info = true;
                            $selected_phone_info = $phone;
                            break;
                        }
                    }
                }
                ?>

                <?php if ($show_byot_info): ?>
                <div class="row" id="byot-verification-section" style="margin-top: 20px;">
                    <div class="col-md-12">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h4 class="panel-title">
                                    <i class="fa fa-key text-info"></i> BYOT Number Configuration
                                </h4>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <strong>Selected BYOT Number:</strong>
                                        <br>
                                        <span class="label label-info"><?= htmlspecialchars($selected_phone_id) ?></span>
                                    </div>
                                    <div class="col-md-4">
                                        <strong>Encrypted Key:</strong>
                                        <br>
                                        <?php if (!empty($current_encrypted_key)): ?>
                                            <span class="label label-success">
                                                <i class="fa fa-check"></i> Connected
                                            </span>
                                            <br><small class="text-muted">Key: <?= substr($current_encrypted_key, 0, 8) ?>...</small>
                                        <?php else: ?>
                                            <span class="label label-warning">
                                                <i class="fa fa-warning"></i> Not Set
                                            </span>
                                            <br><small class="text-muted">Will be auto-detected on save</small>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-4">
                                        <strong>Twilio Status:</strong>
                                        <br>
                                        <?php
                                        $exists_in_twilio = $selected_phone_info['exists_in_twilio'] ?? false;
                                        $status_error = $selected_phone_info['status_error'] ?? null;
                                        ?>

                                        <?php if ($exists_in_twilio): ?>
                                            <span class="label label-success">
                                                <i class="fa fa-check-circle"></i> Available
                                            </span>
                                            <br><small class="text-success">Ready for calls</small>
                                        <?php elseif ($status_error): ?>
                                            <span class="label label-danger">
                                                <i class="fa fa-exclamation-triangle"></i> Error
                                            </span>
                                            <br><small class="text-danger"><?= htmlspecialchars($status_error) ?></small>
                                        <?php else: ?>
                                            <span class="label label-default">
                                                <i class="fa fa-question"></i> Unknown
                                            </span>
                                            <br><small class="text-muted">Status not checked</small>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <?php if (!$exists_in_twilio && $status_error): ?>
                                <div class="row" style="margin-top: 15px;">
                                    <div class="col-md-12">
                                        <div class="alert alert-warning" style="margin-bottom: 0;">
                                            <i class="fa fa-info-circle"></i>
                                            <strong>BYOT Setup Required:</strong>
                                            This number appears to have issues with your Twilio account.
                                            Please verify that the number exists in your Twilio account and the encrypted key is correct.
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-12">
                        <hr>
                        <h4 class="tw-font-semibold"><i class="fa fa-microphone text-success"></i> Voice & AI Settings</h4>
                    </div>

                    <div class="col-md-4">
                        <?php echo render_input('settings[bland_ai_max_duration]', 'Max Call Duration (mins) <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="When the call starts, a timer is set for the max_duration minutes. At the end of that timer, if the call is still active it will be automatically ended."></i>', get_option('bland_ai_max_duration'), "number"); ?>
                    </div>

                    <div class="col-md-4">
                        <?php
                        echo render_select_with_input_group(
                            'settings[bland_ai_agent_voice]',
                            alm_bland_ai_get_voices(),
                            ['id', 'name', 'description'],
                            'AI Assistant Voice <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Choose the voice your AI assistant will use during calls. Bland.ai offers various voice options including natural-sounding voices and custom voice clones. Click the play button to preview the selected voice."></i>',
                            get_option('bland_ai_agent_voice'),
                            '<div class="input-group-btn">
                                <a href="#" class="btn btn-default" onclick="play_selected_voice_bland();return false;" class="inline-field-new" title="Preview Voice">
                                    <i class="fa fa-volume-high"></i>
                                </a>
                            </div>'
                        );
                        ?>
                    </div>

                    <div class="col-md-4">
                        <?php
                        echo render_input('settings[bland_ai_temperature]', 'Temperature <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="A value between 0 and 1 that controls the randomness of the LLM. 0 will cause more deterministic outputs while 1 will cause more random."></i>', get_option('bland_ai_temperature'), "number", ['min' => 0.0, 'max' => 1.0, 'step' => 0.1]);
                        ?>
                        <input type="range" id="bland_ai_temperature" min="0.0" max="1.0" step="0.1" value="<?= get_option('bland_ai_temperature'); ?>" style="width: 100%; margin-top: 10px;" />
                    </div>

                    <div class="col-md-12">
                        <hr>
                        <h4 class="tw-font-semibold"><i class="fa fa-wrench text-warning"></i> Assistant Knowledge Integration</h4>
                    </div>

                    <div class="col-md-6">
                        <?php echo render_select('settings[bland_ai_knowledgebase_inbound][]', alm_bland_ai_get_knowledgebase(), ['vector_id', 'name'], 'Inbound Assistant Knowledge Base <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Select knowledge bases that the AI assistant can query during inbound calls. These contain information about your products, services, policies, or procedures that the assistant can reference to answer customer questions accurately."></i>', json_decode(get_option('bland_ai_knowledgebase_inbound')), ['multiple' => true], [], '', '', false); ?>
                    </div>

                    <div class="col-md-6">
                        <?php echo render_select('settings[bland_ai_knowledgebase_outbound][]', alm_bland_ai_get_knowledgebase(), ['vector_id', 'name'], 'Outbound Assistant Knowledge Base <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Select knowledge bases that the AI assistant can query during outbound calls. These help the assistant provide accurate information about your offerings, handle objections, and answer prospect questions during sales or follow-up calls."></i>', json_decode(get_option('bland_ai_knowledgebase_outbound')), ['multiple' => true], [], '', '', false); ?>
                    </div>
                </div>

            </div>

            <!-- Knowledge Base Tab -->
            <div role="tabpanel" class="tab-pane" id="bland-knowledge-base">
                <div class="row" style="margin-top: 20px;">
                    <div class="col-md-12">
                        <!-- Knowledge Base Management Section -->
                        <div class="row">
                            <div class="col-md-10">
                                <h4 class="tw-font-semibold"><i class="fa fa-database"></i> AI Assistant Knowledge Bases</h4>
                                <p class="tw-mb-3 text-info">Create and manage knowledge bases that contain information your AI assistant can reference during calls. Upload documents, manuals, FAQs, or other content to help your assistant provide accurate, informed responses to customer inquiries.</p>
                            </div>
                            <div class="col-md-2">
                                <div class="btn btn-primary" data-toggle="modal" data-target="#bland_ai_kwnowledgebase_modal"><i class="fa fa-plus"></i> Create Knowledge Base</div>
                            </div>
                        </div>

                        <!-- Knowledge Bases Table -->
                        <div class="row">
                            <div class="col-md-12">
                                <h5>Knowledge Bases</h5>
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Description</th>
                                            <th>Created</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach (alm_bland_ai_get_knowledgebase() as $kb): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($kb['vector_id']); ?></td>
                                                <td><?= htmlspecialchars($kb['name']); ?></td>
                                                <td><?= htmlspecialchars($kb['description']); ?></td>
                                                <td><?= _dt($kb['created_at']); ?></td>
                                                <td>
                                                    <button class="btn btn-primary btn-sm edit-bland-kb-btn"
                                                            data-kb-id="<?= $kb['vector_id']; ?>"
                                                            data-kb-name="<?= htmlspecialchars($kb['name']); ?>"
                                                            data-kb-description="<?= htmlspecialchars($kb['description'] ?? ''); ?>">
                                                        <i class="fa fa-edit"></i>
                                                    </button>
                                                    <a href="<?= admin_url('ai_lead_manager/delete_knowledgebase/bland_ai/' . $kb['vector_id']); ?>"
                                                       class="btn btn-danger btn-sm"
                                                       onclick="return confirm('Are you sure? This will delete the knowledge base.')">
                                                        <i class="fa fa-trash"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Phone Numbers Tab -->
            <div role="tabpanel" class="tab-pane" id="bland-phone-numbers">
                <div class="row" style="margin-top: 20px;">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-10">
                                <h4 class="tw-font-semibold"><i class="fa fa-phone"></i> Phone Number Management</h4>
                                <p class="tw-mb-3 text-info">Manage your Bland.ai phone numbers. Configure phone numbers for use with your AI assistant.</p>
                            </div>
                            <!-- <div class="col-md-2">
                                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#create_bland_phone_number_modal">
                                    <i class="fa fa-plus"></i> Add Phone Number
                                </button>
                            </div> -->
                        </div>

                        <!-- Existing Phone Numbers Table -->
                        <div class="row">
                            <div class="col-md-12">
                                <table class="table table-striped" id="bland-phone-numbers-table">
                                    <thead>
                                        <tr>
                                            <th>Number</th>
                                            <th>Name</th>
                                            <th>Status</th>
                                            <th>Created</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="bland-phone-numbers-list">
                                        <?php
                                        $phone_numbers = alm_bland_ai_get_phone_numbers();

                                        if (empty($phone_numbers)): ?>
                                            <tr>
                                                <td colspan="5" class="text-center text-muted">
                                                    <?php if (empty(get_option('bland_ai_api_key'))): ?>
                                                        <i class="fa fa-key text-warning"></i> Please configure your Bland.ai API key in the Basic Configuration tab first.
                                                    <?php else: ?>
                                                        <i class="fa fa-info-circle"></i> No phone numbers found. Click "Add Phone Number" to create one.
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php else: ?>
                                            <?php foreach ($phone_numbers as $phone): ?>
                                                <?php
                                                $phone_id = $phone['phone_number'] ?? '';
                                                $phone_number = $phone['phone_number'] ?? 'N/A';
                                                $selected_phone_id = get_option('bland_ai_selected_phone_number_id');
                                                ?>
                                                <tr>
                                                    <td>
                                                        <strong><?= htmlspecialchars($phone_number) ?></strong>
                                                        <?php if ($phone_id == $selected_phone_id): ?>
                                                            <br><small class="text-primary"><i class="fa fa-star"></i> <strong>Active Number</strong></small>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        // Show phone type based on the source
                                                        $type = $phone['type'] ?? 'bland_ai';

                                                        if ($type === 'byot') {
                                                            $name = $phone['label'] ?? 'BYOT Number';
                                                        } else {
                                                            // For Bland.ai numbers, show a descriptive name
                                                            $name = 'Bland.ai Number';
                                                        }

                                                        echo htmlspecialchars($name);
                                                        ?>
                                                        <br><small class="text-muted">
                                                            <?php if ($type === 'byot'): ?>
                                                                <span class="badge badge-info">BYOT</span>
                                                            <?php else: ?>
                                                                <span class="badge badge-primary">Bland.ai</span>
                                                            <?php endif; ?>
                                                        </small>
                                                    </td>
                                                    <td>
                                                        <?php if ($type === 'byot'): ?>
                                                            <?php
                                                            // Check if status was already checked
                                                            $exists_in_twilio = $phone['exists_in_twilio'] ?? false;
                                                            $status_error = $phone['status_error'] ?? null;
                                                            $status_message = $phone['status_message'] ?? null;

                                                            if ($exists_in_twilio) {
                                                                $badge_class = 'badge-success';
                                                                $status_text = 'Available';
                                                                $tooltip = 'Number exists in your Twilio account';
                                                            } elseif ($status_error) {
                                                                $badge_class = 'badge-danger';
                                                                $status_text = 'Error';
                                                                $tooltip = $status_error . ($status_message ? ': ' . $status_message : '');
                                                            } else {
                                                                $badge_class = 'badge-warning';
                                                                $status_text = 'Unknown';
                                                                $tooltip = 'Status could not be determined';
                                                            }
                                                            ?>
                                                            <span class="badge <?= $badge_class ?>" title="<?= htmlspecialchars($tooltip) ?>">
                                                                <?= $status_text ?>
                                                            </span>
                                                            <br><small class="text-muted">
                                                                BYOT - <?= $exists_in_twilio ? 'Ready to use' : 'Check Twilio account' ?>
                                                            </small>
                                                        <?php else: ?>
                                                            <span class="badge badge-success">Active</span>
                                                            <br><small class="text-muted">Bland.ai managed</small>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $created_at = $phone['created_at'] ?? '';
                                                        if (!empty($created_at)) {
                                                            echo _dt($created_at);
                                                        } else {
                                                            echo '<span class="text-muted">-</span>';
                                                        }
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <button type="button" class="btn btn-danger btn-sm"
                                                                onclick="deleteBlandPhoneNumber('<?= htmlspecialchars($phone_id) ?>', '<?= htmlspecialchars($phone_number) ?>')"
                                                                data-toggle="tooltip" title="Delete phone number">
                                                            <i class="fa fa-trash"></i>
                                                        </button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<style>
/* Bland.ai Sub-tabs Styling */
.bland-sub-tabs {
    margin: 15px 0;
}

.bland-sub-tabs .nav-tabs > li > a {
    border-radius: 4px 4px 0 0;
    color: #5a5c69;
    font-weight: 500;
    transition: all 0.3s ease;
}

.bland-sub-tabs .nav-tabs > li > a:hover {
    background-color: #f8f9fc;
    color: #4e73df;
}

.bland-sub-tabs .nav-tabs > li.active > a,
.bland-sub-tabs .nav-tabs > li.active > a:hover,
.bland-sub-tabs .nav-tabs > li.active > a:focus {
    border-radius: 4px 4px 0 0;
    background-color: #4e73df;
    color: white;
}

/* Assistant Status Display Styling for Bland.ai */
.assistant-status-display .alert {
    border-radius: 6px;
    border-left: 4px solid;
    font-size: 13px;
    line-height: 1.4;
}

.assistant-status-display .alert-success {
    border-left-color: #5cb85c;
    background-color: #f4fdf4;
    border-color: #d6e9c6;
    color: #3c763d;
}

.assistant-status-display .alert-info {
    border-left-color: #5bc0de;
    background-color: #f0f9ff;
    border-color: #bce8f1;
    color: #31708f;
}

.assistant-status-display .alert i {
    margin-right: 8px;
    font-size: 14px;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Bland.ai specific JavaScript functions
    console.log('Bland.ai tab loaded');

    // Function to edit Bland.ai knowledge base
    $(document).on('click', '.edit-bland-kb-btn', function() {
        var kbId = $(this).data('kb-id');
        var kbName = $(this).data('kb-name');
        var kbDescription = $(this).data('kb-description');

        console.log('Edit Bland.ai KB:', kbId, kbName, kbDescription);

        // TODO: Implement edit modal for Bland.ai knowledge base
        alert('Edit Bland.ai Knowledge Base: ' + kbName + '\n\nThis feature will be implemented to allow editing knowledge base details.');
    });

    // Temperature slider synchronization for Bland.ai
    $('#bland_ai_temperature').on('input', function() {
        var value = $(this).val();
        $('input[name="settings[bland_ai_temperature]"]').val(value);
    });

    // Sync temperature input with slider
    $('input[name="settings[bland_ai_temperature]"]').on('input', function() {
        var value = $(this).val();
        $('#bland_ai_temperature').val(value);
    });
});

// Bland.ai phone number management functions
function deleteBlandPhoneNumber(phoneId, phoneNumber) {
    if (confirm('Are you sure you want to delete phone number ' + phoneNumber + '?\n\nThis action cannot be undone.')) {
        // TODO: Implement delete functionality for Bland.ai phone numbers
        console.log('Delete Bland.ai phone:', phoneId, phoneNumber);
        alert('Delete Phone Number: ' + phoneNumber + '\n\nThis feature will be implemented to delete phone numbers via API.');
    }
}

// Check BYOT number status
function checkByotStatus(phoneNumber, buttonElement) {
    var $button = $(buttonElement);
    var originalHtml = $button.html();

    // Show loading state
    $button.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Checking...');

    // Make AJAX request to check status
    $.ajax({
        url: admin_url + 'ai_lead_manager/check_byot_status',
        type: 'POST',
        dataType: 'json',
        data: {
            phone_numbers: [phoneNumber]
        },
        success: function(response) {
            if (response.success && response.data && response.data.results) {
                var result = response.data.results[0];
                var statusBadge = $button.closest('td').find('.badge');

                if (result.exists === true) {
                    statusBadge.removeClass('badge-info badge-danger')
                             .addClass('badge-success')
                             .text('Available')
                             .attr('title', 'Number exists in Twilio account');
                } else {
                    statusBadge.removeClass('badge-info badge-success')
                             .addClass('badge-danger')
                             .text('Error')
                             .attr('title', result.error || 'Number not found in Twilio');
                }
            } else {
                alert('Failed to check number status: ' + (response.message || 'Unknown error'));
            }
        },
        error: function(xhr, status, error) {
            console.error('BYOT status check failed:', error);
            alert('Error checking number status. Please try again.');
        },
        complete: function() {
            // Reset button state
            $button.prop('disabled', false).html(originalHtml);
        }
    });
}
</script>
<?php endif; ?>