<?php
defined('BASEPATH') or exit('No direct script access allowed');

// Load leads data for dropdowns
$this->load->model('leads_model');
$leads_sources = $this->leads_model->get_source();
$leads_statuses = $this->leads_model->get_status();
?>
<div class="row">
    <div class="col-md-12">
        <?php
        $options = [
            [
                'id' => 'bland_ai',
                'name' => 'Bland AI'
            ],
            [
                'id' => 'vapi_ai',
                'name' => 'Vapi AI'
            ]
        ];
        echo render_select('settings[alm_voice_assistant]', $options, ['id', 'name'], 'AI Voice Assistant Provider <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Choose your preferred AI voice assistant provider. Bland AI and Vapi AI offer different features and voice qualities. Configure the selected provider in its respective tab."></i>', get_option('alm_voice_assistant'), [], [], '', '', false);

        echo '<hr>';
        echo '<h4 class="tw-font-semibold"><i class="fa fa-phone text-success"></i> ' . _l('inbound_call_assistant') . '</h4>';
        echo '<p class="text-info"><i class="fa fa-info-circle"></i> ' . _l('inbound_assistant_desc') . '</p>';
        echo render_input('settings[alm_first_sentence]', _l('opening_greeting_message') . ' <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="' . _l('opening_greeting_tooltip') . '"></i>', get_option('alm_first_sentence'), 'text', ['placeholder' => _l('opening_greeting_placeholder')]);
        ?>
        <div class="form-group">
            <label for="alm_system_prompt"><?php echo _l('assistant_personality'); ?> <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="<?php echo _l('assistant_personality_tooltip'); ?>"></i></label>
            <div class="row">
                <div class="col-md-12">
                    <div class="template-selector-container" style="margin-bottom: 10px;">
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fa fa-magic"></i> <?php echo _l('quick_start_templates'); ?> <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu template-dropdown">
                                <li class="dropdown-header"><?php echo _l('system_prompt_templates'); ?></li>
                                <li><a href="#" class="template-option" data-prompt-target="alm_system_prompt" data-opening-target="settings_alm_first_sentence" data-template="inbound_customer_support"><?php echo _l('customer_support_specialist'); ?></a></li>
                                <li><a href="#" class="template-option" data-prompt-target="alm_system_prompt" data-opening-target="settings_alm_first_sentence" data-template="inbound_lead_qualification"><?php echo _l('lead_qualification_specialist'); ?></a></li>
                                <li><a href="#" class="template-option" data-prompt-target="alm_system_prompt" data-opening-target="settings_alm_first_sentence" data-template="inbound_appointment_scheduler"><?php echo _l('appointment_scheduler'); ?></a></li>
                                <li><a href="#" class="template-option" data-prompt-target="alm_system_prompt" data-opening-target="settings_alm_first_sentence" data-template="inbound_info_collector"><?php echo _l('info_collector'); ?></a></li>
                                <li><a href="#" class="template-option" data-prompt-target="alm_system_prompt" data-opening-target="settings_alm_first_sentence" data-template="inbound_care_coordinator"><?php echo _l('care_coordinator'); ?></a></li>
                                <li><a href="#" class="template-option" data-prompt-target="alm_system_prompt" data-opening-target="settings_alm_first_sentence" data-template="inbound_feedback_gatherer"><?php echo _l('feedback_gatherer'); ?></a></li>
                            </ul>
                        </div>
                        <button type="button" id="start-inbound-test-call" class="btn btn-success btn-sm pull-right" style="margin-left: 10px;">
                            <i class="fa fa-microphone"></i> Test Call
                        </button>
                        <button type="button" id="end-inbound-test-call" class="btn btn-danger btn-sm pull-right" style="display: none; margin-left: 5px;">
                            <i class="fa fa-phone-slash"></i> End Call
                        </button>
                    </div>
                </div>
            </div>
            <textarea name="settings[alm_system_prompt]" id="alm_system_prompt" class="form-control" rows="6" placeholder="You are a helpful customer service representative for [Company Name]. Be friendly, professional, and knowledgeable about our products and services. Always aim to provide accurate information and assist customers with their inquiries..."><?php echo get_option('alm_system_prompt'); ?></textarea>
        </div>
        
        <?php
        ?>
        <!-- <p>
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt">{company_name}</a>,
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt">{address}</a>,
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt">{city}</a>,
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt">{state}</a>,
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt">{zip_code}</a>,
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt">{country_code}</a>,
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt">{phone}</a>,
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt">{vat_number}</a>,
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt">{vat_number_with_label}</a>
        </p> -->
        <hr>
        <h4 class="tw-font-semibold"><i class="fa fa-phone-square text-primary"></i> <?php echo _l('outbound_call_assistant'); ?></h4>
        <p class="text-info"><i class="fa fa-info-circle"></i> <?php echo _l('outbound_assistant_desc'); ?></p>
        <?php
        echo render_input('settings[alm_first_sentence_outbound]', _l('opening_introduction_message') . ' <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="' . _l('opening_introduction_tooltip') . '"></i>', get_option('alm_first_sentence_outbound'), 'text', ['placeholder' => _l('opening_introduction_placeholder')]);
        ?>
        <div class="form-group">
            <label for="alm_system_prompt_outbound"><?php echo _l('sales_assistant_instructions'); ?> <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="<?php echo _l('sales_assistant_tooltip'); ?>"></i></label>
            <div class="row">
                <div class="col-md-12">
                    <div class="template-selector-container" style="margin-bottom: 10px;">
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fa fa-magic"></i> <?php echo _l('quick_start_templates'); ?> <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu template-dropdown">
                                <li class="dropdown-header"><?php echo _l('system_prompt_templates'); ?></li>
                                <li><a href="#" class="template-option" data-prompt-target="alm_system_prompt_outbound" data-opening-target="settings_alm_first_sentence_outbound" data-template="outbound_lead_qualification"><?php echo _l('lead_qualification_specialist'); ?></a></li>
                                <li><a href="#" class="template-option" data-prompt-target="alm_system_prompt_outbound" data-opening-target="settings_alm_first_sentence_outbound" data-template="outbound_appointment_setter"><?php echo _l('appointment_scheduler'); ?></a></li>
                                <li><a href="#" class="template-option" data-prompt-target="alm_system_prompt_outbound" data-opening-target="settings_alm_first_sentence_outbound" data-template="outbound_follow_up">Follow-up Specialist</a></li>
                                <li><a href="#" class="template-option" data-prompt-target="alm_system_prompt_outbound" data-opening-target="settings_alm_first_sentence_outbound" data-template="outbound_survey_collector">Survey Collector</a></li>
                                <li><a href="#" class="template-option" data-prompt-target="alm_system_prompt_outbound" data-opening-target="settings_alm_first_sentence_outbound" data-template="outbound_renewal_specialist">Renewal Specialist</a></li>
                                <li><a href="#" class="template-option" data-prompt-target="alm_system_prompt_outbound" data-opening-target="settings_alm_first_sentence_outbound" data-template="outbound_customer_success">Customer Success Specialist</a></li>
                            </ul>
                        </div>
                        <button type="button" id="start-outbound-test-call" class="btn btn-primary btn-sm pull-right" style="margin-left: 10px;">
                            <i class="fa fa-phone"></i> Test Call
                        </button>
                        <button type="button" id="end-outbound-test-call" class="btn btn-danger btn-sm pull-right" style="display: none; margin-left: 5px;">
                            <i class="fa fa-phone-slash"></i> End Call
                        </button>
                    </div>
                </div>
            </div>
            <textarea name="settings[alm_system_prompt_outbound]" id="alm_system_prompt_outbound" class="form-control" rows="6" placeholder="You are a professional sales representative for [Company Name]. Your goal is to build rapport, understand the prospect's needs, and present relevant solutions. Be consultative, listen actively, and focus on providing value. Handle objections with empathy and always respect the prospect's time..."><?php echo get_option('alm_system_prompt_outbound'); ?></textarea>
        </div>
        
        <?php
        ?>
        <!-- <p>
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt_outbound">{company_name}</a>,
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt_outbound">{address}</a>,
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt_outbound">{city}</a>,
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt_outbound">{state}</a>,
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt_outbound">{zip_code}</a>,
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt_outbound">{country_code}</a>,
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt_outbound">{phone}</a>,
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt_outbound">{vat_number}</a>,
            <a href="#" class="settings-textarea-merge-field" data-to="alm_system_prompt_outbound">{vat_number_with_label}</a>
        </p> -->
    </div>


    <div class="col-md-12">
        <hr>
        <h4 class="tw-font-semibold"><i class="fa fa-cogs text-warning"></i> <?php echo _l('post_call_processing'); ?></h4>
        <p class="text-info"><i class="fa fa-info-circle"></i> <?php echo _l('post_call_desc'); ?></p>
    </div>
    <div class="col-md-4">
        <?php echo render_select('settings[alm_lead_source]', $leads_sources, ['id', 'name'], _l('post_call_lead_source') . ' <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="' . _l('post_call_source_tooltip') . '"></i>', get_option('alm_lead_source'), []); ?>
    </div>
    <div class="col-md-4">
        <?php echo render_select('settings[alm_call_completed_status]', $leads_statuses, ['id', 'name'], _l('post_call_lead_status') . ' <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="' . _l('post_call_status_tooltip') . '"></i>', get_option('alm_call_completed_status'), []); ?>
    </div>
</div>

<!-- Include centralized templates -->
<script src="<?php echo module_dir_url('ai_lead_manager', 'assets/js/templates.js'); ?>"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Use centralized templates from AITemplates.systemPrompts and AITemplates.openingMessages
    const templates = AITemplates.systemPrompts;
    const openingMessages = AITemplates.openingMessages;

    // Handle template selection for both system prompts and opening messages
    $(document).on('click', '.template-option', function(e) {
        e.preventDefault();
        
        const promptTarget = $(this).attr('data-prompt-target');
        const openingTarget = $(this).attr('data-opening-target');
        const templateKey = $(this).attr('data-template');
        const template = templates[templateKey];
        const openingTemplate = openingMessages[templateKey];
        
        if (template && promptTarget && openingTarget) {
            const textarea = $('#' + promptTarget);
            
            // Find opening input using multiple selectors
            let input = $('#' + openingTarget);
            if (input.length === 0) {
                input = $('input[name="settings[' + openingTarget.replace('settings_', '') + ']"]');
            }
            if (input.length === 0) {
                input = $('#' + openingTarget.replace('settings_', ''));
            }
            
            // Check if either field has content and show confirmation
            const hasPromptContent = textarea.length && textarea.val().trim();
            const hasOpeningContent = input.length && input.val().trim();
            
            if ((hasPromptContent || hasOpeningContent) && !confirm('<?php echo _l('replace_current_content'); ?>')) {
                return;
            }
            
            // Update system prompt
            if (textarea.length && template) {
                textarea.val(template.content);
            }
            
            console.log('Opening target:', openingTarget);
            console.log('Found input:', input.length);
            
            // Update opening message
            if (input.length && openingTemplate) {
                input.val(openingTemplate.content);
            }
            
            // Show success message on the system prompt field
            if (textarea.length) {
                const container = textarea.closest('.form-group');
                const existingAlert = container.find('.template-success-alert');
                if (existingAlert.length) {
                    existingAlert.remove();
                }
                
                const alert = $('<div class="alert alert-success template-success-alert" style="margin-top: 10px;"><i class="fa fa-check"></i> <strong>' + template.title + '</strong> <?php echo _l('template_loaded_success'); ?></div>');
                
                textarea.after(alert);
                
                // Remove success message after 5 seconds
                setTimeout(function() {
                    alert.remove();
                }, 5000);
                
                // Focus on textarea
                textarea.focus();
            }
        }
    });
});
</script>

<style>
.template-selector-container .dropdown-menu {
    max-height: 300px;
    overflow-y: auto;
}

.template-success-alert {
    border-left: 4px solid #5cb85c;
}

.template-dropdown {
    min-width: 250px;
}

.dropdown-header {
    font-weight: 600;
    color: #495057;
}

</style>