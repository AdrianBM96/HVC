<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
    <div class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="panel_s">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-8">
                                <h4 class="tw-font-semibold tw-text-neutral-800">
                                    <i class="fa fa-bullhorn tw-mr-2"></i>
                                    <?php echo htmlspecialchars($campaign['name']); ?>
                                </h4>
                                <div class="tw-mt-2">
                                    <?php
                                    $status_colors = [
                                        'draft' => 'default',
                                        'scheduled' => 'warning',
                                        'running' => 'info',
                                        'paused' => 'warning',
                                        'completed' => 'success',
                                        'cancelled' => 'danger'
                                    ];
                                    ?>
                                    <span class="label label-<?php echo $status_colors[$campaign['status']]; ?> label-lg">
                                        <?php echo ucfirst($campaign['status']); ?>
                                    </span>
                                    <?php $current_ai_provider = get_option('alm_voice_assistant'); ?>
                                    <span class="badge badge-<?php echo $current_ai_provider === 'vapi_ai' ? 'info' : 'success'; ?> tw-ml-2">
                                        <?php echo ucfirst(str_replace('_', ' ', $current_ai_provider)); ?> (Current)
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-4 text-right">
                                <!-- Edit Campaign Button -->
                                <button type="button" class="btn btn-primary" onclick="editCampaign()">
                                    <i class="fa fa-edit"></i> Edit Campaign
                                </button>

                                <?php if ($campaign['status'] === 'paused' || $campaign['status'] === 'draft'): ?>
                                    <a href="<?php echo admin_url('ai_lead_manager/campaigns/start/' . $campaign['id']); ?>"
                                        class="btn btn-success">
                                        <i class="fa fa-play"></i> Start Campaign
                                    </a>
                                <?php endif; ?>

                                <?php if ($campaign['status'] === 'running'): ?>
                                    <a href="<?php echo admin_url('ai_lead_manager/campaigns/pause/' . $campaign['id']); ?>"
                                        class="btn btn-warning">
                                        <i class="fa fa-pause"></i> Pause Campaign
                                    </a>
                                <?php endif; ?>

                                <?php if (in_array($campaign['status'], ['running', 'paused', 'scheduled'])): ?>
                                    <a href="<?php echo admin_url('ai_lead_manager/campaigns/cancel/' . $campaign['id']); ?>"
                                        class="btn btn-danger"
                                        onclick="return confirm('Are you sure you want to cancel this campaign?');">
                                        <i class="fa fa-stop"></i> Cancel Campaign
                                    </a>
                                <?php endif; ?>

                                <a href="<?php echo admin_url('ai_lead_manager/campaigns'); ?>" class="btn btn-default">
                                    <i class="fa fa-arrow-left"></i> Back to Campaigns
                                </a>
                            </div>
                        </div>
                        <hr class="hr-panel-heading" />

                        <!-- Campaign Statistics -->
                        <div class="row tw-mb-6">
                            <div class="col-md-2 col-sm-6 col-xs-6">
                                <div class="tw-bg-neutral-50 tw-rounded-lg tw-p-4 tw-text-center">
                                    <div class="tw-text-2xl tw-font-bold tw-text-neutral-700">
                                        <?php echo (isset($campaign['stats']) && is_array($campaign['stats']) && isset($campaign['stats']['total_contacts'])) ? (int)$campaign['stats']['total_contacts'] : 0; ?>
                                    </div>
                                    <div class="tw-text-sm tw-text-neutral-500">Total Contacts</div>
                                </div>
                            </div>
                            <div class="col-md-2 col-sm-6 col-xs-6">
                                <div class="tw-bg-green-50 tw-rounded-lg tw-p-4 tw-text-center">
                                    <div class="tw-text-2xl tw-font-bold tw-text-green-600">
                                        <?php echo (isset($campaign['stats']) && is_array($campaign['stats']) && isset($campaign['stats']['answered_calls'])) ? (int)$campaign['stats']['answered_calls'] : 0; ?>
                                    </div>
                                    <div class="tw-text-sm tw-text-green-600">Answered Calls</div>
                                </div>
                            </div>
                            <div class="col-md-2 col-sm-6 col-xs-6">
                                <div class="tw-bg-red-50 tw-rounded-lg tw-p-4 tw-text-center">
                                    <div class="tw-text-2xl tw-font-bold tw-text-red-600">
                                        <?php echo (isset($campaign['stats']) && is_array($campaign['stats']) && isset($campaign['stats']['unanswered_calls'])) ? (int)$campaign['stats']['unanswered_calls'] : 0; ?>
                                    </div>
                                    <div class="tw-text-sm tw-text-red-600">Un-Answered Calls</div>
                                </div>
                            </div>
                            <div class="col-md-2 col-sm-6 col-xs-6">
                                <div class="tw-bg-orange-50 tw-rounded-lg tw-p-4 tw-text-center">
                                    <div class="tw-text-2xl tw-font-bold tw-text-orange-600">
                                        <?php echo (isset($campaign['stats']) && is_array($campaign['stats']) && isset($campaign['stats']['rescheduled_attempts'])) ? (int)$campaign['stats']['rescheduled_attempts'] : 0; ?>
                                    </div>
                                    <div class="tw-text-sm tw-text-orange-600">Attempt Rescheduled</div>
                                </div>
                            </div>
                            <div class="col-md-2 col-sm-6 col-xs-6">
                                <div class="tw-bg-blue-50 tw-rounded-lg tw-p-4 tw-text-center">
                                    <div class="tw-text-2xl tw-font-bold tw-text-blue-600">
                                        <?php
                                        $success_rate_display = 0;
                                        if (isset($campaign['stats']) && is_array($campaign['stats']) && isset($campaign['stats']['success_rate']) && is_numeric($campaign['stats']['success_rate'])) {
                                            $success_rate_display = (float)$campaign['stats']['success_rate'];
                                        }
                                        echo $success_rate_display . '%';
                                        ?>
                                    </div>
                                    <div class="tw-text-sm tw-text-blue-600">Success Rate</div>
                                </div>
                            </div>
                            <div class="col-md-2 col-sm-6 col-xs-6">
                                <div class="tw-bg-purple-50 tw-rounded-lg tw-p-4 tw-text-center">
                                    <div class="tw-text-2xl tw-font-bold tw-text-purple-600">
                                        <?php
                                        $completion_rate_display = 0;
                                        if (isset($campaign['stats']) && is_array($campaign['stats']) && isset($campaign['stats']['completion_rate']) && is_numeric($campaign['stats']['completion_rate'])) {
                                            $completion_rate_display = (float)$campaign['stats']['completion_rate'];
                                        }
                                        echo $completion_rate_display . '%';
                                        ?>
                                    </div>
                                    <div class="tw-text-sm tw-text-purple-600">Completion Rate</div>
                                </div>
                            </div>
                        </div>

                        <!-- Progress Bar -->
                        <div class="row tw-mb-6">
                            <div class="col-md-12">
                                <?php

                                $completion_rate = 0;
                                if (isset($campaign['stats']) && is_array($campaign['stats']) && isset($campaign['stats']['completion_rate'])) {
                                    $completion_rate = is_numeric($campaign['stats']['completion_rate']) ? (float)$campaign['stats']['completion_rate'] : 0;
                                }

                                $completed = (isset($campaign['stats']) && is_array($campaign['stats']) && isset($campaign['stats']['completed'])) ? (int)$campaign['stats']['completed'] : 0;
                                $total_contacts = (isset($campaign['stats']) && is_array($campaign['stats']) && isset($campaign['stats']['total_contacts'])) ? (int)$campaign['stats']['total_contacts'] : 0;
                                $total_calls = (isset($campaign['stats']) && is_array($campaign['stats']) && isset($campaign['stats']['total_calls'])) ? (int)$campaign['stats']['total_calls'] : 0;
                                $avg_duration = (isset($campaign['stats']) && is_array($campaign['stats']) && isset($campaign['stats']['avg_call_duration'])) ? (float)$campaign['stats']['avg_call_duration'] : 0;
                                ?>
                                <div class="alm-campaign-progress" style="height: 10px;">
                                    <div class="alm-campaign-progress-bar" style="width: <?php echo ($completion_rate !== null && $completion_rate !== '') ? $completion_rate : 0; ?>%">
                                        <span class="sr-only"><?php echo ($completion_rate !== null && $completion_rate !== '') ? $completion_rate : 0; ?>% Complete</span>
                                    </div>
                                </div>
                                <p class="tw-text-sm tw-text-neutral-600 tw-mt-2">
                                    Campaign Progress: <?php echo $completion_rate; ?>%
                                    (<?php echo $completed; ?> of <?php echo $total_contacts; ?> completed)
                                    <?php if ($total_calls > 0): ?>
                                        | Total Calls Made: <?php echo $total_calls; ?>
                                        <?php if ($avg_duration > 0): ?>
                                            | Avg Duration: <?php echo $avg_duration; ?>s
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>

                        <!-- Campaign Details -->
                        <div class="row tw-mb-6">
                            <div class="col-md-4">
                                <div class="tw-bg-white tw-border tw-rounded-lg tw-p-4">
                                    <h5 class="tw-font-semibold tw-mb-3">Campaign Timeline</h5>
                                    <div class="tw-space-y-2">
                                        <div class="tw-flex tw-justify-between">
                                            <span class="tw-text-neutral-600">Created:</span>
                                            <span><?php echo _dt($campaign['created_at']); ?></span>
                                        </div>
                                        <?php if ($campaign['started_at']): ?>
                                            <div class="tw-flex tw-justify-between">
                                                <span class="tw-text-neutral-600">Started:</span>
                                                <span><?php echo _dt($campaign['started_at']); ?></span>
                                            </div>
                                        <?php endif; ?>
                                        <?php if ($campaign['scheduled_at'] && $campaign['schedule_type'] === 'scheduled'): ?>
                                            <div class="tw-flex tw-justify-between">
                                                <span class="tw-text-neutral-600">Scheduled:</span>
                                                <span><?php echo _dt($campaign['scheduled_at']); ?></span>
                                            </div>
                                        <?php endif; ?>
                                        <?php if ($campaign['completed_at']): ?>
                                            <div class="tw-flex tw-justify-between">
                                                <span class="tw-text-neutral-600">Completed:</span>
                                                <span><?php echo _dt($campaign['completed_at']); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="tw-bg-white tw-border tw-rounded-lg tw-p-4">
                                    <h5 class="tw-font-semibold tw-mb-3">Configuration</h5>
                                    <div class="tw-space-y-2">
                                        <div class="tw-flex tw-justify-between">
                                            <span class="tw-text-neutral-600">AI Provider:</span>
                                            <span class="badge badge-<?php echo $current_ai_provider === 'vapi_ai' ? 'info' : 'success'; ?>">
                                                <?php echo ucfirst(str_replace('_', ' ', $current_ai_provider)); ?>
                                            </span>
                                        </div>
                                        <div class="tw-flex tw-justify-between">
                                            <span class="tw-text-neutral-600">Phone Number:</span>
                                            <span class="text-muted"><?php echo get_option('twilio_account_number'); ?></span>
                                        </div>
                                        <div class="tw-flex tw-justify-between">
                                            <span class="tw-text-neutral-600">Schedule Type:</span>
                                            <span class="badge badge-<?php echo $campaign['schedule_type'] === 'send_now' ? 'success' : 'warning'; ?>">
                                                <?php echo ucfirst(str_replace('_', ' ', $campaign['schedule_type'])); ?>
                                            </span>
                                        </div>
                                        <div class="tw-flex tw-justify-between">
                                            <span class="tw-text-neutral-600">Max Attempts:</span>
                                            <span class="badge badge-default"><?php echo $campaign['max_attempts'] ?? 3; ?> attempts</span>
                                        </div>
                                        <?php if ($campaign['evaluation_enabled']): ?>
                                            <div class="tw-flex tw-justify-between">
                                                <span class="tw-text-neutral-600">Lead Evaluation:</span>
                                                <span class="badge badge-warning">
                                                    <i class="fa fa-filter"></i> Enabled
                                                </span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="tw-bg-white tw-border tw-rounded-lg tw-p-4">
                                    <h5 class="tw-font-semibold tw-mb-3">AI Customization</h5>
                                    <div class="tw-space-y-2">
                                        <?php if (!empty($campaign['first_message'])): ?>
                                            <div class="tw-mb-2">
                                                <span class="tw-text-neutral-600 tw-text-sm">Opening Message:</span>
                                                <div class="tw-mt-1 tw-p-2 tw-bg-gray-50 tw-rounded tw-text-sm">
                                                    <?php echo htmlspecialchars($campaign['first_message']); ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                        <?php if (!empty($campaign['assistant_prompt'])): ?>
                                            <div class="tw-mb-2">
                                                <span class="tw-text-neutral-600 tw-text-sm">Assistant Instructions:</span>
                                                <button type="button" class="btn btn-xs btn-default pull-right" onclick="viewAssistantInstructions()" title="View in larger window" style="margin-top: -2px;">
                                                    <i class="fa fa-expand"></i>
                                                </button>
                                                <div class="tw-mt-1 tw-p-2 tw-bg-gray-50 tw-rounded tw-text-sm">
                                                    <?php 
                                                    $prompt = htmlspecialchars($campaign['assistant_prompt']);
                                                    echo strlen($prompt) > 200 ? substr($prompt, 0, 200) . '...' : $prompt;
                                                    ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                        <?php if ($campaign['evaluation_enabled'] && !empty($campaign['evaluation_prompt'])): ?>
                                            <div class="tw-mb-2">
                                                <span class="tw-text-neutral-600 tw-text-sm">Qualification Criteria:</span>
                                                <div class="tw-mt-1 tw-p-2 tw-bg-gray-50 tw-rounded tw-text-sm">
                                                    <?php echo htmlspecialchars($campaign['evaluation_prompt']); ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                        <?php
                                        // Display attached knowledge bases
                                        if (!empty($campaign['knowledge_bases'])):
                                            $attached_kbs = json_decode($campaign['knowledge_bases'], true);
                                            if (!empty($attached_kbs)):
                                        ?>
                                                <div class="tw-mb-2">
                                                    <span class="tw-text-neutral-600 tw-text-sm">Knowledge Bases:</span>
                                                    <div class="tw-mt-1">
                                                        <span class="badge badge-info" style="cursor: pointer;"
                                                            onclick="showKnowledgeBases('<?php echo htmlspecialchars(json_encode($attached_kbs)); ?>')">
                                                            <i class="fa fa-database"></i> <?php echo count($attached_kbs); ?> Attached
                                                        </span>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        <?php if (empty($campaign['first_message']) && empty($campaign['assistant_prompt']) && empty($campaign['evaluation_prompt']) && empty($campaign['knowledge_bases'])): ?>
                                            <div class="text-muted tw-text-sm tw-text-center">
                                                <i class="fa fa-info-circle"></i><br>
                                                Using system defaults
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Tabs for Tables -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="nav-tabs-custom">
                                    <ul class="nav nav-tabs">
                                        <li class="active">
                                            <a href="#campaign_numbers" data-toggle="tab">
                                                <i class="fa fa-users tw-mr-1"></i>
                                                Campaign Numbers
                                                <span class="badge badge-default tw-ml-1"><?php echo $campaign['stats']['total_contacts']; ?></span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#call_logs" data-toggle="tab">
                                                <i class="fa fa-phone tw-mr-1"></i>
                                                Call Logs
                                                <span class="badge badge-info tw-ml-1"><?php echo $campaign['stats']['total_calls']; ?></span>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="tab-content">
                                        <div class="tab-pane active" id="campaign_numbers">
                                            <h5 class="tw-font-semibold tw-mb-3 tw-mt-4">Campaign Numbers</h5>
                                            <?php
                                            $table_data = [
                                                [
                                                    'name' => 'Phone Number',
                                                    'th_attrs' => ['class' => 'toggleable', 'id' => 'th-phone-number'],
                                                ],
                                                [
                                                    'name' => 'Customer Name',
                                                    'th_attrs' => ['class' => 'toggleable', 'id' => 'th-customer-name'],
                                                ],
                                                [
                                                    'name' => 'Email',
                                                    'th_attrs' => ['class' => 'toggleable', 'id' => 'th-email'],
                                                ],
                                                [
                                                    'name' => 'Company',
                                                    'th_attrs' => ['class' => 'toggleable', 'id' => 'th-company'],
                                                ],
                                                [
                                                    'name' => 'Location',
                                                    'th_attrs' => ['class' => 'toggleable', 'id' => 'th-location'],
                                                ],
                                                [
                                                    'name' => 'Description',
                                                    'th_attrs' => ['class' => 'toggleable', 'id' => 'th-description'],
                                                ],
                                                [
                                                    'name' => 'Status',
                                                    'th_attrs' => ['class' => 'toggleable', 'id' => 'th-status'],
                                                ],
                                                [
                                                    'name' => 'Attempts',
                                                    'th_attrs' => ['class' => 'toggleable', 'id' => 'th-attempts'],
                                                ],
                                                [
                                                    'name' => 'Last Attempt',
                                                    'th_attrs' => ['class' => 'toggleable', 'id' => 'th-last-attempt'],
                                                ],
                                                [
                                                    'name' => 'Lead Created',
                                                    'th_attrs' => ['class' => 'toggleable', 'id' => 'th-lead-created'],
                                                ],
                                                [
                                                    'name' => 'Actions',
                                                    'th_attrs' => ['class' => 'not-export'],
                                                ]
                                            ];
                                            ?>
                                            <div class="panel-table-full">
                                                <?php
                                                render_datatable($table_data, 'campaign_numbers', [], [
                                                    'data-last-order-identifier' => 'campaign_numbers',
                                                    'data-default-order' => get_table_last_order('campaign_numbers'),
                                                    'data-campaign-id' => $campaign['id']
                                                ]);
                                                ?>
                                            </div>
                                        </div>

                                        <div class="tab-pane" id="call_logs">
                                            <h5 class="tw-font-semibold tw-mb-3 tw-mt-4">Call Logs</h5>
                                            <div class="alert alert-info">
                                                <i class="fa fa-info-circle"></i>
                                                <strong>Campaign Call Logs:</strong> This shows all calls made for this campaign.
                                                Multiple calls can be made to the same number based on your retry settings.
                                            </div>
                                            <?php
                                            $alm_voice_assistant = get_option('alm_voice_assistant');
                                            $call_logs_table_data = [
                                                '#',
                                                _l('alm_call_log_call_id'),
                                                _l('alm_call_log_created_at'),
                                                _l('alm_call_log_direction'),
                                                _l('alm_call_log_to_number'),
                                                _l('alm_call_log_from_number'),
                                                _l('alm_call_log_recording'),
                                                ($alm_voice_assistant == 'vapi_ai' ? _l('alm_call_log_ended_reason') : _l('alm_call_log_status')),
                                                _l('alm_call_log_duration'),
                                                _l('alm_call_log_price'),
                                                'Summary',
                                                'Started At',
                                                'Ended At',
                                                'AI Provider'
                                            ];
                                            ?>
                                            <div class="panel-table-full">
                                                <?php
                                                render_datatable($call_logs_table_data, 'campaign_call_logs_complete', [], [
                                                    'data-last-order-identifier' => 'campaign_call_logs_complete',
                                                    'data-default-order' => get_table_last_order('campaign_call_logs_complete'),
                                                    'data-campaign-id' => $campaign['id']
                                                ]);
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php init_tail(); ?>


<script>
    $(function() {
        // Initialize server parameters for campaign numbers table
        var CampaignNumbersServerParams = {
            'campaign_id': '<?php echo $campaign['id']; ?>'
        };

        // Initialize DataTable with server-side processing
        var tAPI = initDataTable('.table-campaign_numbers', admin_url + 'ai_lead_manager/campaigns/campaign_numbers_table/<?php echo $campaign['id']; ?>', false, false, CampaignNumbersServerParams, [6, 'desc']);

        // Initialize Call Logs DataTable
        var callLogsAPI = null;

        // Initialize call logs table when tab is shown
        $('a[href="#call_logs"]').on('shown.bs.tab', function(e) {
            if (callLogsAPI === null) {
                var CallLogsServerParams = {
                    'campaign_id': '<?php echo $campaign['id']; ?>'
                };
                callLogsAPI = initDataTable('.table-campaign_call_logs_complete', admin_url + 'ai_lead_manager/campaigns/campaign_call_logs_complete_table/<?php echo $campaign['id']; ?>', false, false, CallLogsServerParams, [2, 'desc']);
            }
        });

        // Auto refresh every 30 seconds if campaign is running
        <?php if ($campaign['status'] === 'running'): ?>
            setInterval(function() {
                if (tAPI && tAPI.ajax) {
                    tAPI.ajax.reload(null, false);
                }
                if (callLogsAPI && callLogsAPI.ajax) {
                    callLogsAPI.ajax.reload(null, false);
                }
            }, 30000);
        <?php endif; ?>
    });

    // Show customer details modal
    function showCustomerDetails(extraData, customerName) {
        var modalContent = '<div class="modal fade" id="customerDetailsModal" tabindex="-1" role="dialog">' +
            '<div class="modal-dialog" role="document">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>' +
            '<h4 class="modal-title"><i class="fa fa-user"></i> Customer Details - ' + customerName + '</h4>' +
            '</div>' +
            '<div class="modal-body">' +
            '<table class="table table-bordered">';

        // Add customer details
        if (extraData.email) {
            modalContent += '<tr><th>Email:</th><td>' + extraData.email + '</td></tr>';
        }
        if (extraData.company) {
            modalContent += '<tr><th>Company:</th><td>' + extraData.company + '</td></tr>';
        }
        if (extraData.address) {
            modalContent += '<tr><th>Address:</th><td>' + extraData.address + '</td></tr>';
        }
        if (extraData.city) {
            modalContent += '<tr><th>City:</th><td>' + extraData.city + '</td></tr>';
        }
        if (extraData.state) {
            modalContent += '<tr><th>State:</th><td>' + extraData.state + '</td></tr>';
        }
        if (extraData.country) {
            modalContent += '<tr><th>Country:</th><td>' + extraData.country + '</td></tr>';
        }
        if (extraData.zip_code) {
            modalContent += '<tr><th>Zip Code:</th><td>' + extraData.zip_code + '</td></tr>';
        }
        if (extraData.description) {
            modalContent += '<tr><th>Description:</th><td>' + extraData.description + '</td></tr>';
        }

        modalContent += '</table>' +
            '</div>' +
            '<div class="modal-footer">' +
            '<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>';

        // Remove existing modal if present
        $('#customerDetailsModal').remove();

        // Add modal to body and show
        $('body').append(modalContent);
        $('#customerDetailsModal').modal('show');

        // Remove modal from DOM when hidden
        $('#customerDetailsModal').on('hidden.bs.modal', function() {
            $(this).remove();
        });
    }

    // Show error details modal
    function showErrorDetails(errorMessage, isBase64) {
        // Decode base64 if needed
        if (isBase64) {
            errorMessage = atob(errorMessage);
        }
        
        // Escape HTML to prevent XSS but preserve readability
        var escapedMessage = $('<div>').text(errorMessage).html();
        
        var modalContent = '<div class="modal fade" id="errorDetailsModal" tabindex="-1" role="dialog">' +
            '<div class="modal-dialog modal-lg" role="document">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>' +
            '<h4 class="modal-title text-danger"><i class="fa fa-exclamation-triangle"></i> Error Details</h4>' +
            '</div>' +
            '<div class="modal-body">' +
            '<div class="alert alert-danger">' +
            '<strong>Error Message:</strong><br>' +
            '<pre style="white-space: pre-wrap; word-wrap: break-word; background: #f8f8f8; padding: 10px; border: 1px solid #ddd; border-radius: 4px;">' + escapedMessage + '</pre>' +
            '</div>' +
            '</div>' +
            '<div class="modal-footer">' +
            '<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>';

        // Remove existing modal if present
        $('#errorDetailsModal').remove();

        // Add modal to body and show
        $('body').append(modalContent);
        $('#errorDetailsModal').modal('show');

        // Remove modal from DOM when hidden
        $('#errorDetailsModal').on('hidden.bs.modal', function() {
            $(this).remove();
        });
    }

    // Show knowledge bases modal
    function showKnowledgeBases(kbIds) {
        var kbArray = JSON.parse(kbIds);
        var modalContent = '<div class="modal fade" id="knowledgeBasesModal" tabindex="-1" role="dialog">' +
            '<div class="modal-dialog modal-lg" role="document">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>' +
            '<h4 class="modal-title"><i class="fa fa-database"></i> Attached Knowledge Bases</h4>' +
            '</div>' +
            '<div class="modal-body">' +
            '<div class="alert alert-success">' +
            '<i class="fa fa-info-circle"></i> <strong>Knowledge Bases:</strong> AI assistant can query these knowledge bases during calls for accurate information.' +
            '</div>';

        // Fetch knowledge base details via AJAX
        $.ajax({
            url: '<?php echo admin_url('ai_lead_manager/campaigns/get_knowledge_bases_details'); ?>',
            type: 'POST',
            data: {
                kb_ids: kbArray
            },
            dataType: 'json',
            success: function(response) {
                var kbContent = '<div class="knowledge-bases-list">';

                if (response.success && response.knowledge_bases) {
                    response.knowledge_bases.forEach(function(kb) {
                        kbContent += '<div class="kb-item-view">' +
                            '<div class="kb-header">' +
                            '<h5><i class="fa fa-database text-info"></i> ' + kb.name + '</h5>' +
                            '</div>' +
                            '<div class="kb-details">';

                        if (kb.description) {
                            kbContent += '<p class="text-muted">' + kb.description + '</p>';
                        }

                        if (kb.file_count) {
                            kbContent += '<span class="label label-info">' + kb.file_count + ' files</span>';
                        }

                        kbContent += '</div></div>';
                    });
                } else {
                    kbContent += '<div class="alert alert-warning">' +
                        '<i class="fa fa-exclamation-triangle"></i> Unable to load knowledge base details.' +
                        '</div>';
                }

                kbContent += '</div>';

                // Update modal content
                $('#knowledgeBasesModal .modal-body').append(kbContent);
            },
            error: function() {
                var errorContent = '<div class="alert alert-danger">' +
                    '<i class="fa fa-exclamation-triangle"></i> Error loading knowledge base details.' +
                    '</div>';
                $('#knowledgeBasesModal .modal-body').append(errorContent);
            }
        });

        modalContent += '</div>' +
            '<div class="modal-footer">' +
            '<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>';

        $('#knowledgeBasesModal').remove();
        $('body').append(modalContent);
        $('#knowledgeBasesModal').modal('show');

        $('#knowledgeBasesModal').on('hidden.bs.modal', function() {
            $(this).remove();
        });
    }

    // Retry campaign number function
    function retryCampaignNumber(campaignNumberId, phoneNumber) {
        if (!confirm('Are you sure you want to retry the call for ' + phoneNumber + '?')) {
            return;
        }

        // Show loading state
        var loadingText = '<i class="fa fa-spinner fa-spin"></i> Retrying...';
        var modalContent = '<div class="modal fade" id="retryLoadingModal" tabindex="-1" role="dialog" data-backdrop="static">' +
            '<div class="modal-dialog modal-sm" role="document">' +
            '<div class="modal-content">' +
            '<div class="modal-body text-center">' +
            loadingText +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>';

        $('body').append(modalContent);
        $('#retryLoadingModal').modal('show');

        // Make AJAX request to retry the campaign number
        $.ajax({
            url: '<?php echo admin_url('ai_lead_manager/campaigns/retry_campaign_number'); ?>',
            type: 'POST',
            data: {
                campaign_number_id: campaignNumberId,
                <?php echo $this->security->get_csrf_token_name(); ?>: '<?php echo $this->security->get_csrf_hash(); ?>'
            },
            dataType: 'json',
            success: function(response) {
                // Force hide and remove the modal
                $('#retryLoadingModal').modal('hide');
                $('.modal-backdrop').remove(); // Remove backdrop
                $('body').removeClass('modal-open'); // Remove modal-open class
                setTimeout(function() {
                    $('#retryLoadingModal').remove();
                }, 100);

                if (response.success) {
                    alert_float('success', response.message || 'Campaign number retry initiated successfully!');

                    // Refresh the table to show updated status
                    if (typeof tAPI !== 'undefined' && tAPI.ajax) {
                        tAPI.ajax.reload(null, false);
                    }
                } else {
                    alert_float('danger', response.message || 'Failed to retry campaign number. Please try again.');
                }
            },
            error: function(xhr, status, error) {
                // Force hide and remove the modal
                $('#retryLoadingModal').modal('hide');
                $('.modal-backdrop').remove(); // Remove backdrop
                $('body').removeClass('modal-open'); // Remove modal-open class
                setTimeout(function() {
                    $('#retryLoadingModal').remove();
                }, 100);

                var errorMessage = 'An error occurred while retrying the campaign number.';
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response.message) {
                        errorMessage = response.message;
                    }
                } catch (e) {
                    // Use default error message
                }

                alert_float('danger', errorMessage);
            }
        });
    }

    // Edit campaign number function
    function editCampaignNumber(dataBase64) {
        var data = JSON.parse(atob(dataBase64));
        
        // Function to escape HTML for safe insertion
        function escapeHtml(text) {
            if (!text) return '';
            return $('<div>').text(text.toString()).html();
        }
        
        var modalContent = '<div class="modal fade" id="editNumberModal" tabindex="-1" role="dialog">' +
            '<div class="modal-dialog modal-lg" role="document">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>' +
            '<h4 class="modal-title"><i class="fa fa-edit"></i> Edit Campaign Number</h4>' +
            '</div>' +
            '<div class="modal-body">' +
            '<form id="editNumberForm">' +
            '<input type="hidden" id="edit_campaign_number_id" value="' + data.id + '">' +
            
            // Basic Information Tab
            '<ul class="nav nav-tabs" role="tablist">' +
            '<li role="presentation" class="active"><a href="#basic-info" aria-controls="basic-info" role="tab" data-toggle="tab">Basic Info</a></li>' +
            '<li role="presentation"><a href="#contact-details" aria-controls="contact-details" role="tab" data-toggle="tab">Contact Details</a></li>' +
            '<li role="presentation"><a href="#status-settings" aria-controls="status-settings" role="tab" data-toggle="tab">Status & Settings</a></li>' +
            '</ul>' +
            
            '<div class="tab-content" style="margin-top: 15px;">' +
            
            // Basic Info Tab
            '<div role="tabpanel" class="tab-pane active" id="basic-info">' +
            '<div class="row">' +
            '<div class="col-md-6">' +
            '<div class="form-group">' +
            '<label for="edit_phone_number">Phone Number <span class="text-danger">*</span>:</label>' +
            '<input type="text" class="form-control" id="edit_phone_number" value="' + escapeHtml(data.phone_number || '') + '" required>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-6">' +
            '<div class="form-group">' +
            '<label for="edit_customer_name">Customer Name <span class="text-danger">*</span>:</label>' +
            '<input type="text" class="form-control" id="edit_customer_name" value="' + escapeHtml(data.customer_name || '') + '" required>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '<div class="form-group">' +
            '<label for="edit_customer_email">Email Address:</label>' +
            '<input type="email" class="form-control" id="edit_customer_email" value="' + escapeHtml(data.customer_email || '') + '">' +
            '</div>' +
            '<div class="form-group">' +
            '<label for="edit_company">Company:</label>' +
            '<input type="text" class="form-control" id="edit_company" value="' + escapeHtml(data.company || '') + '">' +
            '</div>' +
            '</div>' +
            
            // Contact Details Tab  
            '<div role="tabpanel" class="tab-pane" id="contact-details">' +
            '<div class="form-group">' +
            '<label for="edit_address">Address:</label>' +
            '<input type="text" class="form-control" id="edit_address" value="' + escapeHtml(data.address || '') + '">' +
            '</div>' +
            '<div class="row">' +
            '<div class="col-md-4">' +
            '<div class="form-group">' +
            '<label for="edit_city">City:</label>' +
            '<input type="text" class="form-control" id="edit_city" value="' + escapeHtml(data.city || '') + '">' +
            '</div>' +
            '</div>' +
            '<div class="col-md-4">' +
            '<div class="form-group">' +
            '<label for="edit_state">State:</label>' +
            '<input type="text" class="form-control" id="edit_state" value="' + escapeHtml(data.state || '') + '">' +
            '</div>' +
            '</div>' +
            '<div class="col-md-4">' +
            '<div class="form-group">' +
            '<label for="edit_zip_code">ZIP Code:</label>' +
            '<input type="text" class="form-control" id="edit_zip_code" value="' + escapeHtml(data.zip_code || '') + '">' +
            '</div>' +
            '</div>' +
            '</div>' +
            '<div class="form-group">' +
            '<label for="edit_country">Country:</label>' +
            '<input type="text" class="form-control" id="edit_country" value="' + escapeHtml(data.country || '') + '">' +
            '</div>' +
            '<div class="form-group">' +
            '<label for="edit_description">Description/Notes:</label>' +
            '<textarea class="form-control" id="edit_description" rows="3">' + escapeHtml(data.description || '') + '</textarea>' +
            '</div>' +
            '</div>' +
            
            // Status & Settings Tab
            '<div role="tabpanel" class="tab-pane" id="status-settings">' +
            '<div class="row">' +
            '<div class="col-md-6">' +
            '<div class="form-group">' +
            '<label for="edit_status">Status:</label>' +
            '<select class="form-control" id="edit_status">' +
            '<option value="pending"' + (data.status === 'pending' ? ' selected' : '') + '>Pending</option>' +
            '<option value="calling"' + (data.status === 'calling' ? ' selected' : '') + '>Calling</option>' +
            '<option value="completed"' + (data.status === 'completed' ? ' selected' : '') + '>Completed</option>' +
            '<option value="failed"' + (data.status === 'failed' ? ' selected' : '') + '>Failed</option>' +
            '<option value="skipped"' + (data.status === 'skipped' ? ' selected' : '') + '>Skipped</option>' +
            '</select>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-6">' +
            '<div class="form-group">' +
            '<label for="edit_attempts">Retry Attempts:</label>' +
            '<input type="number" class="form-control" id="edit_attempts" value="' + (data.attempts || 0) + '" min="0" max="10">' +
            '<small class="help-block">Number of call attempts made (0-10)</small>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '<div class="alert alert-warning">' +
            '<i class="fa fa-warning"></i> <strong>Note:</strong> Changing status to "pending" will allow the number to be called again. ' +
            'Be careful when modifying these settings as they affect campaign execution.' +
            '</div>' +
            '</div>' +
            
            '</div>' + // End tab-content
            '</form>' +
            '</div>' +
            '<div class="modal-footer">' +
            '<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>' +
            '<button type="button" class="btn btn-primary" onclick="saveEditedNumber()">Save Changes</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>';

        // Remove existing modal if present
        $('#editNumberModal').remove();
        
        // Add modal to body and show
        $('body').append(modalContent);
        $('#editNumberModal').modal('show');
        
        // Remove modal from DOM when hidden
        $('#editNumberModal').on('hidden.bs.modal', function() {
            $(this).remove();
        });
    }

    // Save edited number function
    function saveEditedNumber() {
        var campaignNumberId = $('#edit_campaign_number_id').val();
        var phoneNumber = $('#edit_phone_number').val().trim();
        var customerName = $('#edit_customer_name').val().trim();
        
        if (!phoneNumber) {
            alert_float('danger', 'Phone number is required');
            return;
        }
        
        if (!customerName) {
            alert_float('danger', 'Customer name is required');
            return;
        }
        
        // Collect all form data
        var formData = {
            campaign_number_id: campaignNumberId,
            phone_number: phoneNumber,
            customer_name: customerName,
            customer_email: $('#edit_customer_email').val().trim(),
            status: $('#edit_status').val(),
            attempts: parseInt($('#edit_attempts').val()) || 0,
            // Extra data fields
            company: $('#edit_company').val().trim(),
            address: $('#edit_address').val().trim(),
            city: $('#edit_city').val().trim(),
            state: $('#edit_state').val().trim(),
            country: $('#edit_country').val().trim(),
            zip_code: $('#edit_zip_code').val().trim(),
            description: $('#edit_description').val().trim(),
            <?php echo $this->security->get_csrf_token_name(); ?>: '<?php echo $this->security->get_csrf_hash(); ?>'
        };
        
        // Disable save button and show loading
        var $saveBtn = $('#editNumberModal .btn-primary');
        var originalText = $saveBtn.text();
        $saveBtn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Saving...');
        
        // Make AJAX request to update the number
        $.ajax({
            url: '<?php echo admin_url('ai_lead_manager/campaigns/update_campaign_number'); ?>',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                $('#editNumberModal').modal('hide');
                if (response.success) {
                    alert_float('success', response.message || 'Campaign number updated successfully');
                    // Reload the table to show updated data
                    $('.table-alm_campaign_numbers').DataTable().ajax.reload();
                } else {
                    alert_float('danger', response.message || 'Failed to update campaign number');
                }
            },
            error: function(xhr, status, error) {
                $('#editNumberModal').modal('hide');
                var errorMessage = 'An error occurred while updating the campaign number.';
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response.message) {
                        errorMessage = response.message;
                    }
                } catch (e) {
                    // Use default error message
                }
                alert_float('danger', errorMessage);
            },
            complete: function() {
                $saveBtn.prop('disabled', false).text(originalText);
            }
        });
    }

    // Edit campaign function
    function editCampaign() {
        var campaignData = {
            id: <?php echo $campaign['id']; ?>,
            name: <?php echo json_encode($campaign['name']); ?>,
            assistant_prompt: <?php echo json_encode($campaign['assistant_prompt'] ?? ''); ?>,
            first_message: <?php echo json_encode($campaign['first_message'] ?? ''); ?>,
            max_attempts: <?php echo (int)($campaign['max_attempts'] ?? 3); ?>,
            status: <?php echo json_encode($campaign['status']); ?>,
            knowledge_bases: <?php echo json_encode($campaign['knowledge_bases'] ?? '[]'); ?>,
            tools: <?php echo json_encode($campaign['tools'] ?? '[]'); ?>,
            evaluation_enabled: <?php echo (int)($campaign['evaluation_enabled'] ?? 0); ?>,
            evaluation_prompt: <?php echo json_encode($campaign['evaluation_prompt'] ?? ''); ?>,
        };

        var modalContent = '<div class="modal fade" id="editCampaignModal" tabindex="-1" role="dialog">' +
            '<div class="modal-dialog modal-lg" role="document">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>' +
            '<h4 class="modal-title"><i class="fa fa-edit"></i> Edit Campaign</h4>' +
            '</div>' +
            '<div class="modal-body">' +
            '<form id="editCampaignForm">' +
            '<input type="hidden" id="edit_campaign_id" value="' + campaignData.id + '">' +
            
            // Tabs for organization
            '<ul class="nav nav-tabs" role="tablist">' +
            '<li role="presentation" class="active"><a href="#campaign-basic" aria-controls="campaign-basic" role="tab" data-toggle="tab">Basic Info</a></li>' +
            '<li role="presentation"><a href="#campaign-assistant" aria-controls="campaign-assistant" role="tab" data-toggle="tab">Assistant Settings</a></li>' +
            '<li role="presentation"><a href="#campaign-tools" aria-controls="campaign-tools" role="tab" data-toggle="tab">Tools & Knowledge</a></li>' +
            '<li role="presentation"><a href="#campaign-advanced" aria-controls="campaign-advanced" role="tab" data-toggle="tab">Advanced Settings</a></li>' +
            '</ul>' +
            
            '<div class="tab-content" style="margin-top: 15px;">' +
            
            // Basic Info Tab
            '<div role="tabpanel" class="tab-pane active" id="campaign-basic">' +
            '<div class="form-group">' +
            '<label for="edit_campaign_name">Campaign Name <span class="text-danger">*</span>:</label>' +
            '<input type="text" class="form-control" id="edit_campaign_name" value="' + escapeHtml(campaignData.name) + '" required>' +
            '<small class="help-block">Choose a descriptive name that clearly identifies this campaign.</small>' +
            '</div>' +
            '<div class="row">' +
            '<div class="col-md-6">' +
            '<div class="form-group">' +
            '<label for="edit_campaign_status">Status:</label>' +
            '<select class="form-control" id="edit_campaign_status">' +
            '<option value="draft"' + (campaignData.status === 'draft' ? ' selected' : '') + '>Draft</option>' +
            '<option value="scheduled"' + (campaignData.status === 'scheduled' ? ' selected' : '') + '>Scheduled</option>' +
            '<option value="running"' + (campaignData.status === 'running' ? ' selected' : '') + '>Running</option>' +
            '<option value="paused"' + (campaignData.status === 'paused' ? ' selected' : '') + '>Paused</option>' +
            '<option value="completed"' + (campaignData.status === 'completed' ? ' selected' : '') + '>Completed</option>' +
            '<option value="cancelled"' + (campaignData.status === 'cancelled' ? ' selected' : '') + '>Cancelled</option>' +
            '</select>' +
            '</div>' +
            '</div>' +
            '<div class="col-md-6">' +
            '<div class="form-group">' +
            '<label for="edit_campaign_max_attempts">Max Attempts per Number:</label>' +
            '<input type="number" class="form-control" id="edit_campaign_max_attempts" value="' + campaignData.max_attempts + '" min="1" max="10">' +
            '<small class="help-block">Maximum call attempts for each number (1-10)</small>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            
            // Assistant Settings Tab
            '<div role="tabpanel" class="tab-pane" id="campaign-assistant">' +
            '<div class="form-group">' +
            '<label for="edit_assistant_prompt">Assistant Instructions/Prompt:</label>' +
            '<textarea class="form-control" id="edit_assistant_prompt" rows="6" placeholder="Enter the main instructions for the AI assistant...">' + escapeHtml(campaignData.assistant_prompt) + '</textarea>' +
            '<small class="help-block">This defines how the AI assistant should behave and what it should accomplish during calls.</small>' +
            '</div>' +
            '<div class="form-group">' +
            '<label for="edit_first_message">Opening Message:</label>' +
            '<textarea class="form-control" id="edit_first_message" rows="3" placeholder="Hi {name}, this is...">' + escapeHtml(campaignData.first_message) + '</textarea>' +
            '<small class="help-block">The first message spoken when the call begins. Use {name} for customer name placeholder.</small>' +
            '</div>' +
            '</div>' +
            
            // Tools & Knowledge Tab
            '<div role="tabpanel" class="tab-pane" id="campaign-tools">' +
            '<div class="form-group">' +
            '<label>Knowledge Bases:</label>' +
            '<div id="edit_knowledge_bases_container">' +
            '<p class="text-muted">Loading knowledge bases...</p>' +
            '</div>' +
            '</div>' +
            '<div class="form-group">' +
            '<label>Tools:</label>' +
            '<div id="edit_tools_container">' +
            '<p class="text-muted">Loading tools...</p>' +
            '</div>' +
            '</div>' +
            '</div>' +
            
            // Advanced Settings Tab
            '<div role="tabpanel" class="tab-pane" id="campaign-advanced">' +
            '<div class="form-group">' +
            '<div class="checkbox checkbox-primary">' +
            '<input type="checkbox" id="edit_evaluation_enabled"' + (campaignData.evaluation_enabled == 1 ? ' checked' : '') + '>' +
            '<label for="edit_evaluation_enabled">Enable Call Evaluation</label>' +
            '</div>' +
            '</div>' +
            '<div class="form-group" id="edit_evaluation_prompt_group"' + (campaignData.evaluation_enabled == 1 ? '' : ' style="display:none;"') + '>' +
            '<label for="edit_evaluation_prompt">Evaluation Prompt:</label>' +
            '<textarea class="form-control" id="edit_evaluation_prompt" rows="4" placeholder="Evaluate the call based on...">' + escapeHtml(campaignData.evaluation_prompt) + '</textarea>' +
            '<small class="help-block">Define criteria for evaluating call success.</small>' +
            '</div>' +
            '<div class="alert alert-info">' +
            '<i class="fa fa-info-circle"></i> <strong>Note:</strong> Changes to assistant settings will apply to new calls only. ' +
            'Ongoing calls will continue with their original configuration.' +
            '</div>' +
            '</div>' +
            
            '</div>' + // End tab-content
            '</form>' +
            '</div>' +
            '<div class="modal-footer">' +
            '<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>' +
            '<button type="button" class="btn btn-primary" onclick="saveCampaignEdits()">Save Changes</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>';

        // Function to escape HTML for safe insertion
        function escapeHtml(text) {
            if (!text) return '';
            return $('<div>').text(text.toString()).html();
        }

        // Remove existing modal if present
        $('#editCampaignModal').remove();
        
        // Add modal to body and show
        $('body').append(modalContent);
        $('#editCampaignModal').modal('show');
        
        // Load knowledge bases and tools
        loadCampaignKnowledgeBases(campaignData.knowledge_bases);
        loadCampaignTools(campaignData.tools);
        
        // Handle evaluation checkbox
        $('#edit_evaluation_enabled').change(function() {
            if ($(this).is(':checked')) {
                $('#edit_evaluation_prompt_group').show();
            } else {
                $('#edit_evaluation_prompt_group').hide();
            }
        });
        
        // Remove modal from DOM when hidden
        $('#editCampaignModal').on('hidden.bs.modal', function() {
            $(this).remove();
        });
    }

    // Load knowledge bases for campaign editing
    function loadCampaignKnowledgeBases(selectedKbs) {
        selectedKbs = selectedKbs || '[]';
        var selected = [];
        try {
            selected = JSON.parse(selectedKbs);
        } catch (e) {
            selected = [];
        }
        
        $.ajax({
            url: '<?php echo admin_url('ai_lead_manager/campaigns/get_knowledge_bases_details'); ?>',
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                var html = '<div class="row">';
                if (response.success && response.data && response.data.length > 0) {
                    response.data.forEach(function(kb) {
                        var isChecked = selected.includes(kb.id.toString()) || selected.includes(kb.id) ? ' checked' : '';
                        var kbId = 'edit_kb_' + kb.id;
                        html += '<div class="col-md-6">';
                        html += '<div class="checkbox checkbox-primary">';
                        html += '<input type="checkbox" name="edit_knowledge_bases[]" value="' + kb.id + '" id="' + kbId + '"' + isChecked + '>';
                        html += '<label for="' + kbId + '">' + kb.name + '</label>';
                        html += '</div>';
                        html += '</div>';
                    });
                } else {
                    html += '<div class="col-md-12"><p class="text-muted">No knowledge bases available</p></div>';
                }
                html += '</div>';
                $('#edit_knowledge_bases_container').html(html);
            },
            error: function() {
                $('#edit_knowledge_bases_container').html('<p class="text-danger">Error loading knowledge bases</p>');
            }
        });
    }

    // Load tools for campaign editing
    function loadCampaignTools(selectedTools) {
        selectedTools = selectedTools || '[]';
        var selected = [];
        try {
            selected = JSON.parse(selectedTools);
        } catch (e) {
            selected = [];
        }
        
        // For now, show a simple message about tools
        var html = '<div class="alert alert-info">' +
            '<i class="fa fa-info-circle"></i> Tool configuration is managed through the main AI Lead Manager settings. ' +
            'Changes there will apply to all new campaign calls.' +
            '</div>';
        $('#edit_tools_container').html(html);
    }

    // Save campaign edits
    function saveCampaignEdits() {
        var campaignId = $('#edit_campaign_id').val();
        var name = $('#edit_campaign_name').val().trim();
        
        if (!name) {
            alert_float('danger', 'Campaign name is required');
            return;
        }
        
        // Collect knowledge base selections
        var selectedKbs = [];
        $('input[name="edit_knowledge_bases[]"]:checked').each(function() {
            selectedKbs.push($(this).val());
        });
        
        var formData = {
            campaign_id: campaignId,
            name: name,
            status: $('#edit_campaign_status').val(),
            max_attempts: parseInt($('#edit_campaign_max_attempts').val()) || 3,
            assistant_prompt: $('#edit_assistant_prompt').val().trim(),
            first_message: $('#edit_first_message').val().trim(),
            knowledge_bases: JSON.stringify(selectedKbs),
            evaluation_enabled: $('#edit_evaluation_enabled').is(':checked') ? 1 : 0,
            evaluation_prompt: $('#edit_evaluation_prompt').val().trim(),
            <?php echo $this->security->get_csrf_token_name(); ?>: '<?php echo $this->security->get_csrf_hash(); ?>'
        };
        
        // Disable save button and show loading
        var $saveBtn = $('#editCampaignModal .btn-primary');
        var originalText = $saveBtn.text();
        $saveBtn.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Saving...');
        
        // Make AJAX request to update campaign
        $.ajax({
            url: '<?php echo admin_url('ai_lead_manager/campaigns/update_campaign'); ?>',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                $('#editCampaignModal').modal('hide');
                if (response.success) {
                    alert_float('success', response.message || 'Campaign updated successfully');
                    // Reload the page to show updated data
                    window.location.reload();
                } else {
                    alert_float('danger', response.message || 'Failed to update campaign');
                }
            },
            error: function(xhr, status, error) {
                $('#editCampaignModal').modal('hide');
                var errorMessage = 'An error occurred while updating the campaign.';
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response.message) {
                        errorMessage = response.message;
                    }
                } catch (e) {
                    // Use default error message
                }
                alert_float('danger', errorMessage);
            },
            complete: function() {
                $saveBtn.prop('disabled', false).text(originalText);
            }
        });
    }

    // View assistant instructions in modal (read-only)
    function viewAssistantInstructions() {
        var assistantPrompt = <?php echo json_encode($campaign['assistant_prompt'] ?? ''); ?>;
        
        var modalContent = '<div class="modal fade" id="viewAssistantInstructionsModal" tabindex="-1" role="dialog">' +
            '<div class="modal-dialog modal-lg" role="document">' +
            '<div class="modal-content">' +
            '<div class="modal-header">' +
            '<button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>' +
            '<h4 class="modal-title"><i class="fa fa-robot"></i> Assistant Instructions - <?php echo htmlspecialchars($campaign['name']); ?></h4>' +
            '</div>' +
            '<div class="modal-body">' +
            '<div class="form-group">' +
            '<label>Current Assistant Instructions:</label>' +
            '<div class="well" style="max-height: 400px; overflow-y: auto; white-space: pre-wrap; font-family: monospace; background: #f9f9f9;">' + 
            htmlEscape(assistantPrompt) + 
            '</div>' +
            '<small class="help-block">These are the current instructions defining how the AI assistant behaves during calls for this campaign.</small>' +
            '</div>' +
            '<div class="alert alert-info">' +
            '<strong>💡 Note:</strong> To modify these instructions, use the "Edit Campaign" button and go to the Assistant Settings tab.' +
            '</div>' +
            '</div>' +
            '<div class="modal-footer">' +
            '<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>';

        // Remove existing modal if present
        $('#viewAssistantInstructionsModal').remove();
        
        // Add modal to body and show
        $('body').append(modalContent);
        $('#viewAssistantInstructionsModal').modal('show');
        
        // Remove modal from DOM when hidden
        $('#viewAssistantInstructionsModal').on('hidden.bs.modal', function() {
            $(this).remove();
        });
    }

    // Helper function to escape HTML
    function htmlEscape(str) {
        if (!str) return '';
        return str.replace(/&/g, '&amp;')
                  .replace(/</g, '&lt;')
                  .replace(/>/g, '&gt;')
                  .replace(/"/g, '&quot;')
                  .replace(/'/g, '&#x27;');
    }

</script>

<style>
    .label-lg {
        font-size: 14px;
        padding: 8px 12px;
    }

    /* Custom campaign progress bar styling */
    .alm-campaign-progress {
        background-color: #f5f5f5;
        border-radius: 4px;
        box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
        overflow: hidden;
    }

    .alm-campaign-progress-bar {
        background-color: #5cb85c;
        background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
        background-size: 40px 40px;
        height: 100%;
        transition: width 0.3s ease;
        color: #fff;
        text-align: center;
        line-height: 20px;
        font-size: 12px;
        font-weight: bold;
    }

    /* Campaign action buttons styling */
    .campaign-action-btn {
        margin-left: 8px;
        margin-right: 8px;
        display: inline-block;
        text-decoration: none;
        transition: all 0.2s ease;
    }

    .campaign-action-btn:first-child {
        margin-left: 0;
    }

    .campaign-action-btn:hover {
        text-decoration: none;
        transform: scale(1.1);
    }

    .campaign-action-btn i {
        font-size: 16px !important;
    }

    /* Knowledge Base Modal Styling */
    .knowledge-bases-list {
        margin-top: 15px;
    }

    .kb-item-view {
        background: #f8f9fa;
        border: 1px solid #e9ecef;
        border-radius: 6px;
        padding: 15px;
        margin-bottom: 15px;
        transition: all 0.15s ease-in-out;
    }

    .kb-item-view:hover {
        background: #e9ecef;
        border-color: #007bff;
    }

    .kb-item-view .kb-header h5 {
        margin: 0 0 10px 0;
        color: #495057;
        font-weight: 600;
    }

    .kb-item-view .kb-details {
        margin-top: 10px;
    }

    .kb-item-view .kb-details p {
        margin-bottom: 10px;
        color: #6c757d;
        font-size: 14px;
    }

    .kb-item-view .label {
        font-size: 12px;
        margin-right: 5px;
    }

    /* Modal improvements */
    .modal-lg {
        width: 900px;
    }

    .modal-header {
        background: #f8f9fa;
        border-bottom: 1px solid #dee2e6;
    }

    .modal-title {
        color: #495057;
        font-weight: 600;
    }
</style>