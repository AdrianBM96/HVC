<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
    <div class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="panel_s">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-8">
                                <h4 class="tw-font-semibold tw-text-neutral-800">
                                    <i class="fa fa-bullhorn tw-mr-2"></i>
                                    <?php echo _l('alm_campaigns'); ?>
                                </h4>
                            </div>
                            <div class="col-md-4 text-right">
                                <?php 
                                $current_ai_provider = get_option('alm_voice_assistant');
                                if ($current_ai_provider === 'vapi_ai'): ?>
                                    <a href="<?php echo admin_url('ai_lead_manager/campaigns/create'); ?>" class="btn btn-info">
                                        <i class="fa fa-plus"></i> <?php echo _l('alm_new_campaign'); ?>
                                    </a>
                                <?php else: ?>
                                    <button type="button" class="btn btn-info" disabled title="Campaign creation is currently available only for VAPI AI">
                                        <i class="fa fa-plus"></i> <?php echo _l('alm_new_campaign'); ?>
                                    </button>
                                <?php endif; ?>
                                <a href="<?php echo admin_url('ai_lead_manager/campaigns/download_template'); ?>" class="btn btn-default">
                                    <i class="fa fa-download"></i> CSV Template
                                </a>
                            </div>
                        </div>
                        <hr class="hr-panel-heading" />

                        <?php if ($current_ai_provider !== 'vapi_ai'): ?>
                        <div class="alert alert-info">
                            <i class="fa fa-info-circle"></i>
                            <strong>Campaign Feature Notice:</strong> Campaign creation is currently available only for <strong>VAPI AI</strong>. 
                            Bland AI campaign support is coming soon! 
                            <?php if ($current_ai_provider === 'bland_ai'): ?>
                                You are currently using <strong>Bland AI</strong> - please switch to VAPI AI in 
                                <a href="<?php echo admin_url('settings?group=ai_lead_manager'); ?>" class="alert-link">Settings</a> 
                                to access campaign functionality.
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>

                        <?php
                        $table_data = [
                            [
                                'name' => _l('alm_campaign_name'),
                                'th_attrs' => ['class' => 'toggleable', 'id' => 'th-campaign-name'],
                            ],
                            [
                                'name' => _l('alm_status'),
                                'th_attrs' => ['class' => 'toggleable', 'id' => 'th-status'],
                            ],
                            [
                                'name' => 'Success Rate',
                                'th_attrs' => ['class' => 'toggleable', 'id' => 'th-success-rate'],
                            ],
                            [
                                'name' => 'Total Contacts',
                                'th_attrs' => ['class' => 'toggleable', 'id' => 'th-total-contacts'],
                            ],
                            [
                                'name' => 'Answered Calls',
                                'th_attrs' => ['class' => 'toggleable', 'id' => 'th-answered-calls'],
                            ],
                            [
                                'name' => 'Un-Answered + Rescheduled',
                                'th_attrs' => ['class' => 'toggleable', 'id' => 'th-unanswered-rescheduled'],
                            ],
                            [
                                'name' => _l('alm_created_at'),
                                'th_attrs' => ['class' => 'toggleable', 'id' => 'th-created-at'],
                            ],
                            [
                                'name' => _l('options'),
                                'th_attrs' => ['class' => 'not-export'],
                            ]
                        ];
                        ?>
                        <div class="panel-table-full">
                            <?php
                            render_datatable($table_data, 'campaigns', [], [
                                'data-last-order-identifier' => 'campaigns',
                                'data-default-order' => get_table_last_order('campaigns'),
                            ]);
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php init_tail(); ?>

<script>
$(function() {
    // Initialize campaigns DataTable with server-side processing
    var campaignsAPI = initDataTable('.table-campaigns', admin_url + 'ai_lead_manager/campaigns/table', false, false, {}, [6, 'desc']);
});
</script>