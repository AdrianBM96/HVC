<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
    <div class="content">
        <div class="row">
            <?php echo form_open(admin_url('ai_lead_manager/campaigns/create'), ['id' => 'campaign_form', 'enctype' => 'multipart/form-data']); ?>
            <div class="col-md-12">
                <h4 class="tw-mt-0 tw-font-semibold tw-text-lg tw-text-neutral-700">
                    <i class="fa fa-rocket tw-mr-2"></i>
                    <?php echo _l('create_new_campaign'); ?>
                </h4>
                <div class="row">
                    <!-- Left Column - Campaign Setup (6 columns) -->
                    <div class="col-md-6">
                        <div class="panel_s campaign-setup-panel">
                            <div class="panel-heading">
                                <h3 class="panel-title">
                                    <i class="fa fa-info-circle tw-mr-2"></i>
                                    <?php echo _l('campaign_setup'); ?>
                                </h3>
                            </div>
                            <div class="panel-body">
                                <!-- Campaign Details -->
                                <?php echo render_input('campaign_name', 'campaign_name', '', 'text', ['required' => true, 'placeholder' => _l('enter_campaign_name')]); ?>
                                
                                <?php echo render_textarea('campaign_description', 'description', '', ['placeholder' => _l('campaign_description_placeholder'), 'rows' => 3]); ?>
                                
                                <!-- Max Attempts & AI Provider -->
                                <div class="row">
                                    <div class="col-md-6">
                                        <?php
                                        $call_attempts = [
                                            ['id' => '1', 'name' => _l('one_attempt')],
                                            ['id' => '2', 'name' => _l('two_attempts')],
                                            ['id' => '3', 'name' => _l('three_attempts')],
                                            ['id' => '4', 'name' => _l('four_attempts')],
                                            ['id' => '5', 'name' => _l('five_attempts')]
                                        ];
                                        echo render_select('max_attempts', $call_attempts, ['id', 'name'], 'max_call_attempts', '3');
                                        ?>
                                    </div>
                                    <div class="col-md-6">
                                        <?php
                                        $ai_provider = get_option('alm_voice_assistant');
                                        $provider_name = $ai_provider == 'vapi_ai' ? _l('vapi_ai') : _l('bland_ai');
                                        ?>
                                        <div class="form-group">
                                            <label class="control-label"><?php echo _l('alm_ai_provider'); ?></label>
                                            <div class="tw-mt-2">
                                                <span class="label label-primary">
                                                    <i class="fa fa-robot tw-mr-1"></i>
                                                    <?php echo $provider_name; ?>
                                                </span>
                                                <?php if (!empty(get_option('twilio_account_number'))): ?>
                                                    <span class="label label-info tw-ml-2">
                                                        <i class="fa fa-phone tw-mr-1"></i>
                                                        <?php echo get_option('twilio_account_number'); ?>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <small class="help-block"><?php echo _l('ai_provider_configured'); ?></small>
                                        </div>
                                    </div>
                                </div>

                                <!-- Contact List Upload -->
                                <hr class="section-divider">
                                <h5 class="section-heading">
                                    <i class="fa fa-users tw-mr-2"></i>
                                    <?php echo _l('contact_list'); ?>
                                </h5>
                                
                                <div class="alert alert-info alert-sm">
                                    <i class="fa fa-info-circle"></i>
                                    <strong><?php echo _l('csv_requirements'); ?>:</strong> <?php echo _l('csv_requirements_desc'); ?>
                                </div>
                                
                                <div class="form-group">
                                    <label class="control-label">
                                        <?php echo _l('contact_list_csv_file'); ?> <span class="text-danger">*</span>
                                    </label>
                                    <input type="file" name="csv_file" id="csv_file" class="form-control" accept=".csv" required>
                                    <small class="help-block">
                                        <a href="<?php echo admin_url('ai_lead_manager/campaigns/download_template'); ?>" class="text-primary">
                                            <i class="fa fa-download tw-mr-1"></i><?php echo _l('download_csv_template'); ?>
                                        </a>
                                    </small>
                                </div>

                                <!-- CSV Preview -->
                                <div id="csv_preview" class="tw-mt-4" style="display: none;">
                                    <h6 class="tw-font-medium text-muted"><?php echo _l('csv_preview'); ?></h6>
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-sm" id="csv_preview_table">
                                            <thead></thead>
                                            <tbody></tbody>
                                        </table>
                                    </div>
                                    <div id="csv_stats" class="tw-mt-2"></div>
                                </div>

                                <!-- Schedule Options -->
                                <hr class="section-divider">
                                <h5 class="section-heading">
                                    <i class="fa fa-calendar tw-mr-2"></i>
                                    <?php echo _l('launch_schedule'); ?>
                                </h5>
                                
                                <div class="alert alert-info alert-sm">
                                    <i class="fa fa-info-circle tw-mr-1"></i>
                                    <strong><?php echo _l('how_ai_calling_works'); ?></strong> <?php echo _l('ai_calling_sequential'); ?>
                                </div>
                                
                                <div class="form-group">
                                    <div class="radio radio-primary">
                                        <input type="radio" name="schedule_type" value="send_now" id="schedule_now" checked>
                                        <label for="schedule_now">
                                            <i class="fa fa-bolt text-success tw-mr-2"></i>
                                            <strong><?php echo _l('launch_now'); ?></strong>
                                            <br><small class="text-muted"><?php echo _l('launch_now_desc'); ?></small>
                                        </label>
                                    </div>
                                    <div class="radio radio-primary">
                                        <input type="radio" name="schedule_type" value="scheduled" id="schedule_later">
                                        <label for="schedule_later">
                                            <i class="fa fa-calendar text-primary tw-mr-2"></i>
                                            <strong><?php echo _l('schedule_later'); ?></strong>
                                            <br><small class="text-muted"><?php echo _l('schedule_later_desc'); ?></small>
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="row" id="schedule_options" style="display: none;">
                                    <div class="col-md-6">
                                        <?php echo render_date_input('scheduled_date', 'launch_date'); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label"><?php echo _l('launch_time'); ?></label>
                                            <input type="time" name="scheduled_time" class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Right Column - AI Configuration (6 columns) -->
                    <div class="col-md-6">
                        <div class="panel_s ai-config-panel">
                            <div class="panel-heading">
                                <h3 class="panel-title">
                                    <i class="fa fa-robot tw-mr-2"></i>
                                    <?php echo _l('ai_configuration'); ?>
                                </h3>
                            </div>
                            <div class="panel-body">
                                <!-- AI Settings -->
                                <?php echo render_input('first_message', 'opening_message', '', 'text', ['placeholder' => 'Hi [name], this is calling from [company]. How can I help you today?']); ?>
                                <small class="help-block">Use placeholders: [name], [company]. Leave empty for system default.</small>

                                <div class="form-group">
                                    <label for="assistant_prompt">Assistant Instructions <i class="fa fa-regular fa-question-circle pull-left tw-mt-0.5 tw-mr-1" data-toggle="tooltip" data-title="Define how your AI should behave during calls. Be specific about tone, goals, and conversation flow."></i></label>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="template-selector-container" style="margin-bottom: 10px;">
                                                <div class="btn-group" role="group">
                                                    <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="fa fa-magic"></i> <?php echo _l('quick_start_templates'); ?> <span class="caret"></span>
                                                    </button>
                                                    <ul class="dropdown-menu template-dropdown">
                                                        <li class="dropdown-header"><?php echo _l('system_prompt_templates'); ?></li>
                                                        <li><a href="#" class="template-option" data-target="assistant_prompt" data-template="inbound_customer_support"><?php echo _l('customer_support_specialist'); ?></a></li>
                                                        <li><a href="#" class="template-option" data-target="assistant_prompt" data-template="inbound_lead_qualification"><?php echo _l('lead_qualification_specialist'); ?></a></li>
                                                        <li><a href="#" class="template-option" data-target="assistant_prompt" data-template="inbound_appointment_scheduler"><?php echo _l('appointment_scheduler'); ?></a></li>
                                                        <li><a href="#" class="template-option" data-target="assistant_prompt" data-template="inbound_info_collector"><?php echo _l('info_collector'); ?></a></li>
                                                        <li><a href="#" class="template-option" data-target="assistant_prompt" data-template="inbound_care_coordinator"><?php echo _l('care_coordinator'); ?></a></li>
                                                        <li><a href="#" class="template-option" data-target="assistant_prompt" data-template="inbound_feedback_gatherer"><?php echo _l('feedback_gatherer'); ?></a></li>
                                                    </ul>
                                                </div>
                                                <button type="button" id="start-campaign-test-call" class="btn btn-success btn-sm pull-right" style="margin-left: 10px;">
                                                    <i class="fa fa-microphone"></i> Test Call
                                                </button>
                                                <button type="button" id="end-campaign-test-call" class="btn btn-danger btn-sm pull-right" style="display: none; margin-left: 5px;">
                                                    <i class="fa fa-phone-slash"></i> End Call
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <textarea name="assistant_prompt" id="assistant_prompt" class="form-control" rows="4" placeholder="Define how your AI should behave during calls. Be specific about tone, goals, and conversation flow."></textarea>
                                    <small class="help-block">Custom AI behavior instructions. Leave empty for system defaults.</small>
                                </div>

                                <?php if (get_option('alm_voice_assistant') == 'vapi_ai'): ?>
                                <!-- Knowledge Base Selection -->
                                <hr class="section-divider">
                                <h5 class="section-heading">
                                    <i class="fa fa-database tw-mr-2"></i>
                                    <?php echo _l('knowledge_bases'); ?>
                                </h5>
                                <p class="text-muted"><?php echo _l('knowledge_bases_desc'); ?></p>
                                
                                <?php
                                $knowledge_bases = alm_vapi_ai_get_knowledge_base_tools();
                                if (!empty($knowledge_bases)):
                                ?>
                                <div class="form-group">
                                    <div class="knowledge-base-grid">
                                        <?php foreach ($knowledge_bases as $kb): ?>
                                        <div class="kb-item">
                                            <div class="checkbox checkbox-primary">
                                                <input type="checkbox" name="knowledge_bases[]" value="<?php echo $kb['id']; ?>" id="kb_<?php echo $kb['id']; ?>">
                                                <label for="kb_<?php echo $kb['id']; ?>">
                                                    <strong><?php echo htmlspecialchars($kb['name']); ?></strong>
                                                    <?php if (!empty($kb['knowledgeBases'][0]['description'])): ?>
                                                    <br><small class="text-muted"><?php echo htmlspecialchars($kb['knowledgeBases'][0]['description']); ?></small>
                                                    <?php endif; ?>
                                                    <span class="label label-info label-sm tw-ml-1">
                                                        <?php echo count($kb['knowledgeBases'][0]['fileIds'] ?? []); ?> files
                                                    </span>
                                                </label>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <small class="help-block">
                                        <a href="<?php echo admin_url('settings?group=ai_lead_manager&tab=vapi_ai_settings_tab'); ?>" target="_blank">
                                            <i class="fa fa-external-link tw-mr-1"></i><?php echo _l('manage_knowledge_bases'); ?>
                                        </a>
                                    </small>
                                </div>
                                <?php else: ?>
                                <div class="alert alert-warning alert-sm">
                                    <i class="fa fa-exclamation-triangle"></i>
                                    <?php echo _l('no_knowledge_bases_available'); ?> 
                                    <a href="<?php echo admin_url('settings?group=ai_lead_manager&tab=vapi_ai_settings_tab'); ?>" target="_blank">
                                        <?php echo _l('create_knowledge_bases'); ?>
                                    </a> <?php echo _l('enhance_ai_capabilities'); ?>
                                </div>
                                <?php endif; ?>
                                <?php endif; ?>

                                <!-- Lead Qualification -->
                                <hr class="section-divider">
                                <h5 class="section-heading">
                                    <i class="fa fa-filter tw-mr-2"></i>
                                    Lead Qualification
                                </h5>
                                
                                <div class="form-group">
                                    <div class="qualification-toggle">
                                        <div class="checkbox checkbox-primary">
                                            <input type="checkbox" name="evaluation_enabled" value="1" id="evaluation_enabled">
                                            <label for="evaluation_enabled">
                                                <strong>Enable Smart Qualification</strong>
                                                <br><small class="text-muted">Use AI analysis to automatically evaluate call quality and create leads only for qualified prospects</small>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="form-group" id="evaluation_criteria" style="display: none;">
                                    <?php echo render_textarea('evaluation_prompt', 'qualification_criteria', '', ['placeholder' => 'Create leads for prospects who show interest, ask questions, mention budget, or want to schedule meetings', 'rows' => 3]); ?>
                                    <small class="help-block">Define what makes a prospect qualified for lead creation.</small>
                                </div>


                                <!-- Campaign Preview Stats -->
                                <hr class="section-divider">
                                <h5 class="section-heading">
                                    <i class="fa fa-chart-bar tw-mr-2"></i>
                                    <?php echo _l('campaign_preview'); ?>
                                </h5>
                                
                                <div class="campaign-stats">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="stat-box">
                                                <div class="stat-icon">
                                                    <i class="fa fa-users"></i>
                                                </div>
                                                <div class="stat-content">
                                                    <span class="stat-number" id="contacts_count">0</span>
                                                    <span class="stat-label">Contacts</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="stat-box">
                                                <div class="stat-icon">
                                                    <i class="fa fa-phone"></i>
                                                </div>
                                                <div class="stat-content">
                                                    <span class="stat-number" id="total_calls">0</span>
                                                    <span class="stat-label">Max Calls</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row tw-mt-2">
                                        <div class="col-md-6">
                                            <div class="stat-box">
                                                <div class="stat-icon">
                                                    <i class="fa fa-repeat"></i>
                                                </div>
                                                <div class="stat-content">
                                                    <span class="stat-number" id="max_attempts_display">3</span>
                                                    <span class="stat-label">Attempts</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="stat-box">
                                                <div class="stat-icon">
                                                    <i class="fa fa-robot"></i>
                                                </div>
                                                <div class="stat-content">
                                                    <span class="stat-number"><?php echo $provider_name; ?></span>
                                                    <span class="stat-label">AI Provider</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                    <div class="panel-footer text-right">
                        <button type="submit" class="btn btn-primary">
                            <i class="fa fa-rocket tw-mr-1"></i>
                            <?php echo _l('create_campaign'); ?>
                        </button>
                        <a href="<?php echo admin_url('ai_lead_manager/campaigns'); ?>" class="btn btn-default">
                            <?php echo _l('cancel'); ?>
                        </a>
                    </div>
                </div>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>
<?php init_tail(); ?>

<!-- Include centralized templates -->
<script src="<?php echo module_dir_url('ai_lead_manager', 'assets/js/templates.js'); ?>"></script>

<!-- Vapi Web SDK -->
<?php if (get_option('alm_voice_assistant') == 'vapi_ai' && !empty(get_option('vapi_ai_public_key'))): ?>
<script src="https://cdn.jsdelivr.net/npm/@vapi-ai/web@latest/dist/index.js"></script>
<?php endif; ?>

<script>
$(function() {
    // Form validation
    appValidateForm($('#campaign_form'), {
        campaign_name: 'required',
        csv_file: 'required',
        max_attempts: 'required'
    });
    
    // Max attempts change handler for live updates
    $('select[name="max_attempts"]').change(function() {
        const maxAttempts = $(this).val();
        const contactsCount = parseInt($('#contacts_count').text()) || 0;
        $('#max_attempts_display').text(maxAttempts);
        $('#total_calls').text(contactsCount * maxAttempts);
    });
    
    // Schedule options toggle
    $('input[name="schedule_type"]').change(function() {
        if ($(this).val() === 'scheduled') {
            $('#schedule_options').slideDown();
            $('#scheduled_date, input[name="scheduled_time"]').attr('required', true);
        } else {
            $('#schedule_options').slideUp();
            $('#scheduled_date, input[name="scheduled_time"]').removeAttr('required');
        }
    });
    
    // Evaluation toggle
    $('#evaluation_enabled').change(function() {
        if ($(this).is(':checked')) {
            $('#evaluation_criteria').slideDown();
            $('textarea[name="evaluation_prompt"]').attr('required', true);
        } else {
            $('#evaluation_criteria').slideUp();
            $('textarea[name="evaluation_prompt"]').removeAttr('required');
        }
    });
    
    // CSV file preview with live stats update
    $('#csv_file').change(function() {
        const file = this.files[0];
        if (file && file.type === 'text/csv') {
            const reader = new FileReader();
            reader.onload = function(e) {
                const csv = e.target.result;
                const lines = csv.split('\n').filter(line => line.trim());
                
                if (lines.length > 0) {
                    const headers = lines[0].split(',');
                    let tableHtml = '<thead><tr>';
                    headers.forEach(header => {
                        tableHtml += '<th>' + header.trim().replace(/"/g, '') + '</th>';
                    });
                    tableHtml += '</tr></thead><tbody>';
                    
                    // Show first 5 rows as preview
                    for (let i = 1; i < Math.min(6, lines.length); i++) {
                        if (lines[i].trim()) {
                            const row = lines[i].split(',');
                            tableHtml += '<tr>';
                            row.forEach(cell => {
                                tableHtml += '<td>' + cell.trim().replace(/"/g, '') + '</td>';
                            });
                            tableHtml += '</tr>';
                        }
                    }
                    tableHtml += '</tbody>';
                    
                    $('#csv_preview_table').html(tableHtml);
                    
                    const contactsCount = lines.length - 1;
                    const maxAttempts = parseInt($('select[name="max_attempts"]').val()) || 3;
                    
                    $('#csv_stats').html(
                        '<span class="label label-info">' + contactsCount + ' contacts</span> ' +
                        '<span class="label label-default">' + headers.length + ' columns</span>'
                    );
                    
                    // Update live stats
                    $('#contacts_count').text(contactsCount);
                    $('#total_calls').text(contactsCount * maxAttempts);
                    
                    $('#csv_preview').show();
                }
            };
            reader.readAsText(file);
        }
    });
    
    // Set minimum date to today
    const today = new Date().toISOString().split('T')[0];
    $('input[name="scheduled_date"]').attr('min', today);
    
    // Form submission loading state
    $('#campaign_form').on('submit', function() {
        const btn = $(this).find('button[type="submit"]');
        btn.prop('disabled', true);
        btn.html('<i class="fa fa-spinner fa-spin tw-mr-1"></i>Creating Campaign...');
        return true;
    });
    
    // Use centralized templates
    const templates = AITemplates.systemPrompts;
    const openingMessages = AITemplates.openingMessages;

    <?php if (get_option('alm_voice_assistant') == 'vapi_ai' && !empty(get_option('vapi_ai_public_key'))): ?>
    // Vapi Web-based calling initialization
    let webVapiInstance = null;
    let callStartTime = null;
    let callTimer = null;
    let isWebCallActive = false;

    const webVapiConfig = {
        apiKey: '<?php echo get_option('vapi_ai_public_key'); ?>',
        assistant: {
            model: {
                provider: 'openai',
                model: 'gpt-3.5-turbo',
                temperature: <?php echo get_option('vapi_ai_temperature') ?: '0.7'; ?>,
                maxTokens: <?php echo get_option('vapi_ai_max_tokens') ?: '250'; ?>
            },
            voice: {
                provider: '<?php echo get_option('vapi_ai_voice_provider') ?: 'playht'; ?>',
                voiceId: '<?php echo get_option('vapi_ai_agent_voice') ?: 'jennifer'; ?>'
            },
            firstMessage: function() {
                const msg = $('#first_message').val();
                return msg || 'Hi there! I\'m your AI assistant. This is a web-based test conversation. How can I help you today?';
            }(),
            systemPrompt: function() {
                const prompt = $('#assistant_prompt').val();
                return prompt || 'You are a helpful AI assistant in a web-based test conversation. Be friendly, professional, and demonstrate your capabilities. The user is testing how you sound and behave.';
            }()
        }
    };

    // Initialize Vapi Web SDK
    function initializeWebVapi() {
        if (typeof Vapi !== 'undefined') {
            try {
                webVapiInstance = new Vapi(webVapiConfig.apiKey);
                setupWebVapiEventListeners();
                $('#start-web-call').prop('disabled', false);
                showWebCallStatus('Web assistant ready! Click "Start Conversation" to begin.', 'info');
            } catch (error) {
                console.error('Failed to initialize Vapi:', error);
                showWebCallStatus('Failed to initialize AI assistant: ' + error.message, 'danger');
            }
        }
    }

    // Setup Vapi event listeners for web calling
    function setupWebVapiEventListeners() {
        if (!webVapiInstance) return;

        webVapiInstance.on('call-start', () => {
            isWebCallActive = true;
            callStartTime = Date.now();
            startCallTimer();
            updateCallState('Connected');
            $('#call-info').show();
            showWebCallStatus('Conversation started! You can now talk with your AI assistant.', 'success');
        });

        webVapiInstance.on('call-end', () => {
            isWebCallActive = false;
            stopCallTimer();
            resetWebCallUI();
            $('#call-info').hide();
            showWebCallStatus('Conversation ended. Great job testing your AI assistant!', 'info');
        });

        webVapiInstance.on('error', (error) => {
            isWebCallActive = false;
            stopCallTimer();
            resetWebCallUI();
            $('#call-info').hide();
            showWebCallStatus('Conversation error: ' + error.message, 'danger');
        });

        webVapiInstance.on('speech-start', () => {
            updateCallState('AI Speaking...');
        });

        webVapiInstance.on('speech-end', () => {
            updateCallState('Listening...');
        });
    }

    // Start web-based call
    $('#start-web-call').click(function() {
        if (!webVapiInstance) {
            showWebCallStatus('AI assistant not initialized. Please refresh the page and try again.', 'danger');
            return;
        }

        if (isWebCallActive) {
            showWebCallStatus('A conversation is already in progress.', 'warning');
            return;
        }

        // Update config with current form values
        webVapiConfig.assistant.firstMessage = $('#first_message').val() || 'Hi there! I\'m your AI assistant. This is a web-based test conversation. How can I help you today?';
        webVapiConfig.assistant.systemPrompt = $('#assistant_prompt').val() || 'You are a helpful AI assistant in a web-based test conversation. Be friendly, professional, and demonstrate your capabilities. The user is testing how you sound and behave.';

        $(this).hide();
        $('#end-web-call').show();
        updateCallState('Connecting...');
        $('#call-info').show();
        
        showWebCallStatus('Starting web conversation...', 'info');

        // Start web-based call (no phone number needed)
        webVapiInstance.start(webVapiConfig.assistant)
            .then(() => {
                console.log('Web call started successfully');
            })
            .catch((error) => {
                console.error('Web call failed:', error);
                showWebCallStatus('Failed to start conversation: ' + error.message, 'danger');
                resetWebCallUI();
                $('#call-info').hide();
            });
    });

    // End web-based call
    $('#end-web-call').click(function() {
        if (webVapiInstance && isWebCallActive) {
            webVapiInstance.stop();
        }
    });

    // Update call state display
    function updateCallState(state) {
        $('#call-state').text(state);
    }

    // Start call timer
    function startCallTimer() {
        callTimer = setInterval(function() {
            if (callStartTime) {
                const elapsed = Math.floor((Date.now() - callStartTime) / 1000);
                const minutes = Math.floor(elapsed / 60);
                const seconds = elapsed % 60;
                $('#call-duration').text(
                    (minutes < 10 ? '0' : '') + minutes + ':' + 
                    (seconds < 10 ? '0' : '') + seconds
                );
            }
        }, 1000);
    }

    // Stop call timer
    function stopCallTimer() {
        if (callTimer) {
            clearInterval(callTimer);
            callTimer = null;
        }
        callStartTime = null;
    }

    // Reset web call UI
    function resetWebCallUI() {
        $('#start-web-call').show();
        $('#end-web-call').hide();
        stopCallTimer();
        $('#call-duration').text('00:00');
    }

    // Update web call config when form fields change
    $('#first_message, #assistant_prompt').on('input', function() {
        if (webVapiInstance && !isWebCallActive) {
            webVapiConfig.assistant.firstMessage = $('#first_message').val() || 'Hi there! I\'m your AI assistant. This is a web-based test conversation. How can I help you today?';
            webVapiConfig.assistant.systemPrompt = $('#assistant_prompt').val() || 'You are a helpful AI assistant in a web-based test conversation. Be friendly, professional, and demonstrate your capabilities. The user is testing how you sound and behave.';
        }
    });

    // Initialize Vapi on page load
    setTimeout(initializeWebVapi, 1000);

    function showWebCallStatus(message, type) {
        const alertClasses = {
            'success': 'alert-success',
            'info': 'alert-info', 
            'warning': 'alert-warning',
            'danger': 'alert-danger'
        };
        
        const iconClasses = {
            'success': 'fa-check-circle',
            'info': 'fa-info-circle',
            'warning': 'fa-exclamation-triangle', 
            'danger': 'fa-times-circle'
        };

        $('#web-call-status').removeClass('alert-success alert-info alert-warning alert-danger')
                             .addClass(alertClasses[type]);
        $('#web-call-status-content').html('<i class="fa ' + iconClasses[type] + '"></i> ' + message);
        $('#web-call-status').show();

        // Auto-hide info messages after 5 seconds
        if (type === 'info') {
            setTimeout(() => {
                $('#web-call-status').fadeOut();
            }, 5000);
        }
    }
    <?php endif; ?>

    // Handle template selection
    $(document).on('click', '.template-option', function(e) {
        e.preventDefault();
        
        const target = $(this).attr('data-target');
        const templateKey = $(this).attr('data-template');
        const template = templates[templateKey];
        const openingTemplate = openingMessages[templateKey];
        
        if (template && target) {
            const textarea = $('#' + target);
            const firstMessageInput = $('input[name="first_message"]');
            
            // Check if either field has content and show confirmation
            const hasPromptContent = textarea.length && textarea.val().trim();
            const hasOpeningContent = firstMessageInput.length && firstMessageInput.val().trim();
            
            if ((hasPromptContent || hasOpeningContent) && !confirm('This will replace the current content in both Assistant Instructions and Opening Message. Are you sure?')) {
                return;
            }
            
            if (textarea.length) {
                // Update system prompt
                textarea.val(template.content);
                
                // Update opening message if available
                if (openingTemplate && firstMessageInput.length) {
                    firstMessageInput.val(openingTemplate.content);
                } else if (firstMessageInput.length) {
                    // If no opening template available, clear the field or set a default
                    console.log('No opening message template found for:', templateKey);
                }
                
                // Show success message
                const container = textarea.closest('.form-group');
                const existingAlert = container.find('.template-success-alert');
                if (existingAlert.length) {
                    existingAlert.remove();
                }
                
                // Create success message based on what was updated
                let successMessage = template.title + ' template loaded successfully! Assistant Instructions updated.';
                if (openingTemplate) {
                    successMessage = template.title + ' template loaded successfully! Both Assistant Instructions and Opening Message have been updated.';
                }
                
                const alert = $('<div class="alert alert-success template-success-alert" style="margin-top: 10px;"><i class="fa fa-check"></i> <strong>' + successMessage + '</strong></div>');
                
                textarea.after(alert);
                
                // Remove success message after 5 seconds
                setTimeout(function() {
                    alert.remove();
                }, 5000);
                
                // Focus on textarea
                textarea.focus();
            }
        }
    });
});
</script>

<style>
/* Campaign Layout Improvements */
.campaign-setup-panel,
.ai-config-panel {
    height: 100%;
    margin-bottom: 20px;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.campaign-setup-panel .panel-body,
.ai-config-panel .panel-body {
    padding: 24px;
    background: #ffffff;
    border-radius: 0 0 8px 8px;
}

/* Panel Headers */
.panel-heading {
    background: #f8f9fa;
    color: #495057;
    border-bottom: 1px solid #dee2e6;
    border-radius: 8px 8px 0 0;
    padding: 16px 24px;
}

.campaign-setup-panel .panel-heading {
    background: #343a40;
    color: white;
}

.ai-config-panel .panel-heading {
    background: #28a745;
    color: white;
}

.panel-title {
    font-weight: 600;
    font-size: 16px;
}

/* Section Styling */
.section-divider {
    margin: 25px 0 20px 0;
    border-top: 1px solid #dee2e6;
}

.section-heading {
    color: #212529;
    font-weight: 600;
    margin-bottom: 15px;
    font-size: 15px;
}

/* Form Improvements */
.form-group {
    margin-bottom: 20px;
}

.form-control {
    border-radius: 6px;
    border: 1px solid #e0e6ed;
    transition: all 0.15s ease-in-out;
}

.form-control:focus {
    border-color: #007bff;
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}

/* Alert Improvements */
.alert-sm {
    padding: 12px 16px;
    font-size: 13px;
    margin-bottom: 15px;
    border-radius: 6px;
}

.alert-info {
    background-color: #d1ecf1;
    border-color: #bee5eb;
    color: #0c5460;
}

.alert-warning {
    background-color: #fff3cd;
    border-color: #ffeaa7;
    color: #856404;
}

/* CSV Preview */
#csv_preview_table {
    font-size: 12px;
    margin-top: 10px;
}

#csv_preview_table th,
#csv_preview_table td {
    white-space: nowrap;
    max-width: 120px;
    overflow: hidden;
    text-overflow: ellipsis;
    padding: 6px 8px;
}

#csv_preview_table th {
    background-color: #f8f9fa;
    font-weight: 600;
    color: #495057;
}

/* Radio Button Styling */
.radio {
    margin-bottom: 15px;
}

.radio label {
    font-weight: normal;
    padding-left: 5px;
    cursor: pointer;
}

.radio input[type="radio"] {
    margin-top: 2px;
}

/* Checkbox Improvements */
.checkbox-primary label {
    font-weight: normal;
    padding-left: 5px;
    cursor: pointer;
}

.qualification-toggle .checkbox {
    margin-bottom: 0;
}

/* Knowledge Base Grid */
.knowledge-base-grid {
    display: grid;
    gap: 10px;
    margin-top: 10px;
}

.kb-item {
    background: #f8f9fa;
    border: 1px solid #e9ecef;
    border-radius: 6px;
    padding: 10px;
    transition: all 0.15s ease-in-out;
}

.kb-item:hover {
    background: #e9ecef;
    border-color: #007bff;
}

.kb-item .checkbox {
    margin-bottom: 0;
}

/* Campaign Stats */
.campaign-stats {
    margin-top: 15px;
}

.stat-box {
    display: flex;
    align-items: center;
    background: #f8f9fa;
    border: 1px solid #e9ecef;
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 10px;
    transition: all 0.15s ease-in-out;
}

.stat-box:hover {
    background: #e9ecef;
    transform: translateY(-1px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.stat-icon {
    width: 40px;
    height: 40px;
    background: #6c757d;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 12px;
    color: white;
    font-size: 16px;
}

.stat-content {
    flex: 1;
}

.stat-number {
    display: block;
    font-size: 20px;
    font-weight: 700;
    color: #495057;
    line-height: 1.2;
}

.stat-label {
    display: block;
    font-size: 12px;
    color: #6c757d;
    text-transform: uppercase;
    font-weight: 500;
    letter-spacing: 0.5px;
}

/* Button Improvements */
.btn {
    border-radius: 6px;
    font-weight: 500;
    transition: all 0.15s ease-in-out;
}

.btn-primary {
    background-color: #007bff;
    border-color: #007bff;
}

.btn-primary:hover {
    background-color: #0056b3;
    border-color: #004085;
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(0, 123, 255, 0.3);
}

/* Panel Footer */
.panel-footer {
    background: #ffffff;
    border-top: 1px solid #dee2e6;
    padding: 20px;
    border-radius: 0 0 6px 6px;
}

/* Responsive Design */
@media (max-width: 768px) {
    .campaign-setup-panel,
    .ai-config-panel {
        margin-bottom: 20px;
    }
    
    .stat-box {
        margin-bottom: 15px;
    }
    
    .section-divider {
        margin: 20px 0 15px 0;
    }
}

/* Help Text */
.help-block {
    font-size: 12px;
    color: #6c757d;
    margin-top: 5px;
}

/* Labels */
.label {
    border-radius: 4px;
    font-weight: 500;
}
/* Form Control Focus States */
.selectpicker:focus,
select.form-control:focus {
    border-color: #007bff;
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}

/* Loading State */
.btn[disabled] {
    opacity: 0.7;
    cursor: not-allowed;
}

/* Smooth Transitions */
* {
    transition: all 0.15s ease-in-out;
}

/* Template Selector Styling */
.template-selector-container .dropdown-menu {
    max-height: 300px;
    overflow-y: auto;
}

.template-success-alert {
    border-left: 4px solid #5cb85c;
}

.template-dropdown {
    min-width: 250px;
}

/* Web Call Interface Styling */
.web-call-interface {
    background: #f8f9fa;
    border: 1px solid #e9ecef;
    border-radius: 12px;
    padding: 24px;
    text-align: center;
    position: relative;
    overflow: hidden;
}

.web-call-interface::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #007bff, #28a745, #17a2b8);
    border-radius: 12px 12px 0 0;
}

.call-controls {
    margin-bottom: 20px;
}

.call-btn {
    min-width: 200px;
    height: 60px;
    border-radius: 30px;
    font-size: 16px;
    font-weight: 600;
    transition: all 0.3s ease;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    border: none;
}

.call-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(0,0,0,0.15);
}

.call-btn:active {
    transform: translateY(0);
}

.call-btn i {
    font-size: 18px;
    margin-right: 8px;
}

.call-btn .call-text {
    font-weight: 600;
}

.call-info {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 20px;
    margin-top: 20px;
    padding: 20px;
    background: rgba(255,255,255,0.7);
    border-radius: 8px;
    backdrop-filter: blur(10px);
}

.call-status-indicator {
    position: relative;
    width: 40px;
    height: 40px;
}

.pulse-ring {
    position: absolute;
    border: 3px solid #28a745;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    animation: pulse-ring 1.5s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}

.pulse-dot {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    background: #28a745;
    border-radius: 50%;
    width: 16px;
    height: 16px;
}

@keyframes pulse-ring {
    0% {
        transform: scale(0.8);
        opacity: 1;
    }
    80%, 100% {
        transform: scale(1.4);
        opacity: 0;
    }
}

.call-details {
    text-align: left;
}

.call-state {
    font-size: 16px;
    font-weight: 600;
    color: #495057;
    margin-bottom: 4px;
}

.call-duration {
    font-size: 14px;
    color: #6c757d;
    font-family: 'Courier New', monospace;
}

/* Responsive Design for Web Call */
@media (max-width: 768px) {
    .call-btn {
        min-width: 100%;
        margin-bottom: 10px;
    }
    
    .call-info {
        flex-direction: column;
        gap: 10px;
    }
    
    .call-details {
        text-align: center;
    }
    
    .web-call-interface {
        padding: 16px;
    }
}

/* Dark mode support */
@media (prefers-color-scheme: dark) {
    .web-call-interface {
        background: #2d3748;
        border-color: #4a5568;
        color: #e2e8f0;
    }
    
    .call-info {
        background: rgba(45,55,72,0.7);
    }
    
    .call-state {
        color: #e2e8f0;
    }
    
    .call-duration {
        color: #a0aec0;
    }
}
</style>