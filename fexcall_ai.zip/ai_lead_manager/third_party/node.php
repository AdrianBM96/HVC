<?php 
	defined('AI_LEAD_MANAGER_REG_PROD_POINT') or define('AI_LEAD_MANAGER_REG_PROD_POINT', 'https://t29zrfey40.execute-api.us-east-1.amazonaws.com/envato/api/register');
	defined('AI_LEAD_MANAGER_VAL_PROD_POINT') or define('AI_LEAD_MANAGER_VAL_PROD_POINT', 'https://t29zrfey40.execute-api.us-east-1.amazonaws.com/envato/api/validate');
	defined('DE_PROD_POINT') or define('DE_PROD_POINT', 'https://t29zrfey40.execute-api.us-east-1.amazonaws.com/envato/api/deactivate');
?>