<?php
return [
    'admin/ai_lead_manager/webhooks/vapi_ai_campaign',
    'admin/ai_lead_manager/webhooks/bland_ai',
    'admin/ai_lead_manager/webhooks/vapi_ai_outbound',
    'admin/ai_lead_manager/webhooks/vapi_ai_inbound',
];
