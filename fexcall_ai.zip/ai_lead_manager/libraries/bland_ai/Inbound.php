<?php

namespace modules\ai_lead_manager\libraries\bland_ai;

trait Inbound
{
    /**
     * Retrieves the current configuration for a given inbound phone number.
     *
     * @param string $number The phone number to retrieve the configuration for.
     * @return array The API response containing the configuration, or an error message if the request failed.
     */
    public function get_inbound_number_details($number) {
        return $this->send_request('GET', "/v1/inbound/" . urlencode($number));
    }

    /**
     * Retrieves a list of all inbound phone numbers.
     *
     * @return array The API response containing the list of inbound numbers, or an error message if the request failed.
     */
    public function get_inbound_numbers() {
        return $this->send_request('GET', "/inbound/get_inbound");
    }

    /**
     * Retrieves BYOT (Bring Your Own Twilio) phone numbers.
     *
     * @return array The API response containing the list of BYOT numbers, or an error message if the request failed.
     */
    public function get_byot_numbers() {
        $encrypted_key = get_option('bland_ai_encrypted_key');
        if (empty($encrypted_key)) {
            return ['error' => 'No encrypted key found for BYOT numbers'];
        }
        return $this->send_request('GET', "/byot/get", []);
    }

    /**
     * Check BYOT phone numbers status in Twilio account.
     *
     * @param array $phone_numbers Array of phone numbers to check
     * @return array The API response containing check results
     */
    public function check_byot_numbers($phone_numbers) {
        $data = ['phone_numbers' => $phone_numbers];
        return $this->send_request('POST', "/v1/byot/manage/check", $data);
    }

    /**
     * Get all available encrypted keys for BYOT.
     *
     * @return array The API response containing the list of encrypted keys
     */
    public function get_encrypted_keys() {
        return $this->send_request('GET', "/byot/get_keys");
    }

    /**
     * Get Twilio numbers for a specific encrypted key.
     *
     * @param string $encrypted_key The encrypted key ID
     * @param int $page Page number (default 0)
     * @param int $page_size Page size (default 20)
     * @param string $search Search term (default empty)
     * @return array The API response containing Twilio numbers for this key
     */
    public function get_twilio_numbers($encrypted_key, $page = 0, $page_size = 20, $search = '') {
        $data = [
            'encrypted_key' => $encrypted_key,
            'page' => $page,
            'page_size' => $page_size,
            'search' => $search
        ];
        return $this->send_request('POST', "/byot/get_twilio", $data);
    }

    /**
     * Update inbound agent details for a specific phone number.
     *
     * @param string $phoneNumber The inbound phone number to update.
     * @param array $updateDetails An associative array containing the details to update.
     * @param string|null $encryptedKey The encrypted key for the Twilio account, if applicable.
     * @return array The API response indicating success or failure.
     */
    public function update_inbound_details($phoneNumber, array $updateDetails)
    {
        return $this->send_request('POST', "/v1/inbound/" . urlencode($phoneNumber), $updateDetails, ['encrypted_key: ' . get_option('bland_ai_encrypted_key')]);
    }
}
