<?php

namespace modules\ai_lead_manager\libraries\bland_ai;

/**
 * Builder class for creating Bland AI Call configurations
 * Provides a fluent interface for building complex call settings
 */
class BlandAiCallBuilder
{
    private $config = [];

    public function __construct()
    {
        $this->reset();
    }

    /**
     * Reset builder to default state
     */
    public function reset(): self
    {
        $this->config = [
            'model' => 'enhanced',
            'max_duration' => 12,
            'first_sentence' => '',
            'voice' => '',
            'temperature' => 0.5,
            'summary_prompt' => 'Provide a complete summary of the call.',
            'wait_for_greeting' => false,
            'record' => true,
            'prompt' => '',
            'analysis_schema' => [],
            'tools' => [],
            'webhook_events' => ['call', 'webhook'],
        ];
        
        return $this;
    }

    /**
     * Set model type
     */
    public function setModel(string $model = 'enhanced'): self
    {
        $this->config['model'] = $model;
        return $this;
    }

    /**
     * Set maximum call duration in minutes
     */
    public function setMaxDuration(int $minutes): self
    {
        $this->config['max_duration'] = $minutes;
        return $this;
    }

    /**
     * Set first sentence/greeting
     */
    public function setFirstSentence(string $sentence): self
    {
        $this->config['first_sentence'] = $sentence;
        return $this;
    }

    /**
     * Set voice ID
     */
    public function setVoice(string $voiceId): self
    {
        $this->config['voice'] = $voiceId;
        return $this;
    }

    /**
     * Set temperature for response generation
     */
    public function setTemperature(float $temperature): self
    {
        $this->config['temperature'] = $temperature;
        return $this;
    }

    /**
     * Set system prompt
     */
    public function setPrompt(string $prompt): self
    {
        $this->config['prompt'] = $prompt;
        return $this;
    }

    /**
     * Set summary prompt
     */
    public function setSummaryPrompt(string $prompt): self
    {
        $this->config['summary_prompt'] = $prompt;
        return $this;
    }

    /**
     * Set whether to wait for greeting
     */
    public function setWaitForGreeting(bool $wait): self
    {
        $this->config['wait_for_greeting'] = $wait;
        return $this;
    }

    /**
     * Set webhook URL
     */
    public function setWebhook(string $url): self
    {
        $this->config['webhook'] = $url;
        return $this;
    }

    /**
     * Set webhook events
     */
    public function setWebhookEvents(array $events): self
    {
        $this->config['webhook_events'] = $events;
        return $this;
    }

    /**
     * Enable/disable call recording
     */
    public function setRecording(bool $record): self
    {
        $this->config['record'] = $record;
        return $this;
    }

    /**
     * Add analysis schema field
     */
    public function addAnalysisField(string $fieldName, string $type): self
    {
        $this->config['analysis_schema'][$fieldName] = $type;
        return $this;
    }

    /**
     * Set complete analysis schema
     */
    public function setAnalysisSchema(array $schema): self
    {
        $this->config['analysis_schema'] = $schema;
        return $this;
    }

    /**
     * Add knowledge base tools
     */
    public function addKnowledgeBaseTools(array $toolIds): self
    {
        $this->config['tools'] = array_merge($this->config['tools'], $toolIds);
        return $this;
    }

    /**
     * Set encrypted key for security
     */
    public function setEncryptedKey(string $key): self
    {
        $this->config['encrypted_key'] = $key;
        return $this;
    }

    /**
     * Replace placeholders in first sentence with company information
     */
    public function replaceCompanyPlaceholders(): self
    {
        $replacements = [
            '{company_name}' => get_option('invoice_company_name'),
            '{address}' => get_option('invoice_company_address'),
            '{city}' => get_option('invoice_company_city'),
            '{state}' => get_option('invoice_company_state'),
            '{zip}' => get_option('invoice_company_zip'),
            '{country}' => get_option('invoice_company_country'),
        ];

        $this->config['first_sentence'] = str_replace(
            array_keys($replacements),
            array_values($replacements),
            $this->config['first_sentence']
        );

        return $this;
    }

    /**
     * Set interruption threshold  
     */
    public function setInterruptionThreshold(float $threshold): self
    {
        $this->config['interruption_threshold'] = $threshold;
        return $this;
    }

    /**
     * Set language for the call
     */
    public function setLanguage(string $language): self
    {
        $this->config['language'] = $language;
        return $this;
    }

    /**
     * Set request data for the call
     */
    public function setRequestData(array $data): self
    {
        $this->config['request_data'] = $data;
        return $this;
    }

    /**
     * Set transfer phone number
     */
    public function setTransferPhoneNumber(string $phoneNumber): self
    {
        $this->config['transfer_phone_number'] = $phoneNumber;
        return $this;
    }

    /**
     * Set local dialing code
     */
    public function setLocalDialingCode(string $code): self
    {
        $this->config['local_dialing_code'] = $code;
        return $this;
    }

    /**
     * Set caller ID
     */
    public function setCallerId(string $callerId): self
    {
        $this->config['caller_id'] = $callerId;
        return $this;
    }

    /**
     * Enable/disable answering machine detection
     */
    public function setAnsweringMachineDetection(bool $enabled): self
    {
        $this->config['answering_machine_detection'] = $enabled;
        return $this;
    }

    /**
     * Set keywords for dynamic responses
     */
    public function setKeywords(array $keywords): self
    {
        $this->config['keywords'] = $keywords;
        return $this;
    }

    /**
     * Set pronunciation guide
     */
    public function setPronunciationGuide(array $guide): self
    {
        $this->config['pronunciation_guide'] = $guide;
        return $this;
    }

    /**
     * Set start time for scheduled calls
     */
    public function setStartTime(string $startTime): self
    {
        $this->config['start_time'] = $startTime;
        return $this;
    }

    /**
     * Set timezone for the call
     */
    public function setTimezone(string $timezone): self
    {
        $this->config['timezone'] = $timezone;
        return $this;
    }

    /**
     * Set maximum call length in seconds
     */
    public function setMaxCallLength(int $seconds): self
    {
        $this->config['max_call_length'] = $seconds;
        return $this;
    }

    /**
     * Enable/disable voicemail detection
     */
    public function setVoicemailDetection(bool $enabled): self
    {
        $this->config['voicemail_detection'] = $enabled;
        return $this;
    }

    /**
     * Set voicemail message
     */
    public function setVoicemailMessage(string $message): self
    {
        $this->config['voicemail_message'] = $message;
        return $this;
    }

    /**
     * Set call transfer settings
     */
    public function setTransferSettings(array $settings): self
    {
        $this->config['transfer_settings'] = $settings;
        return $this;
    }

    /**
     * Set dynamic data for personalization
     */
    public function setDynamicData(array $data): self
    {
        $this->config['dynamic_data'] = $data;
        return $this;
    }

    /**
     * Add custom analysis field
     */
    public function addCustomAnalysisField(string $fieldName, string $type): self
    {
        $this->config['analysis_schema'][$fieldName] = $type;
        return $this;
    }

    /**
     * Set retry settings for failed calls
     */
    public function setRetrySettings(int $maxRetries, int $retryDelay): self
    {
        $this->config['retry_settings'] = [
            'max_retries' => $maxRetries,
            'retry_delay' => $retryDelay
        ];
        return $this;
    }

    /**
     * Set call priority (high, normal, low)
     */
    public function setPriority(string $priority): self
    {
        $validPriorities = ['high', 'normal', 'low'];
        if (in_array($priority, $validPriorities)) {
            $this->config['priority'] = $priority;
        }
        return $this;
    }

    /**
     * Set batch ID for bulk calls
     */
    public function setBatchId(string $batchId): self
    {
        $this->config['batch_id'] = $batchId;
        return $this;
    }

    /**
     * Set metadata for the call
     */
    public function setMetadata(array $metadata): self
    {
        $this->config['metadata'] = $metadata;
        return $this;
    }

    /**
     * Set call tags for organization
     */
    public function setTags(array $tags): self
    {
        $this->config['tags'] = $tags;
        return $this;
    }

    /**
     * Add single tag
     */
    public function addTag(string $tag): self
    {
        if (!isset($this->config['tags'])) {
            $this->config['tags'] = [];
        }
        $this->config['tags'][] = $tag;
        return $this;
    }

    /**
     * Set campaign ID
     */
    public function setCampaignId(string $campaignId): self
    {
        $this->config['campaign_id'] = $campaignId;
        return $this;
    }

    /**
     * Configure for sales calls
     */
    public function configureForSales(): self
    {
        return $this->setTemperature(0.7)
                    ->setMaxDuration(15)
                    ->setWaitForGreeting(true)
                    ->addTag('sales')
                    ->setPriority('high')
                    ->setAnalysisSchema([
                        'interest_level' => 'string',
                        'budget_range' => 'string',
                        'decision_maker' => 'boolean',
                        'follow_up_date' => 'string',
                        'competitor_mentioned' => 'string'
                    ]);
    }

    /**
     * Configure for customer support calls
     */
    public function configureForSupport(): self
    {
        return $this->setTemperature(0.5)
                    ->setMaxDuration(20)
                    ->setWaitForGreeting(true)
                    ->addTag('support')
                    ->setPriority('normal')
                    ->setAnalysisSchema([
                        'issue_category' => 'string',
                        'issue_severity' => 'string',
                        'resolution_provided' => 'boolean',
                        'escalation_needed' => 'boolean',
                        'satisfaction_score' => 'integer'
                    ]);
    }

    /**
     * Configure for appointment scheduling
     */
    public function configureForAppointment(): self
    {
        return $this->setTemperature(0.6)
                    ->setMaxDuration(10)
                    ->setWaitForGreeting(true)
                    ->addTag('appointment')
                    ->setPriority('normal')
                    ->setAnalysisSchema([
                        'appointment_date' => 'string',
                        'appointment_time' => 'string',
                        'appointment_type' => 'string',
                        'confirmed' => 'boolean',
                        'calendar_invite_sent' => 'boolean'
                    ]);
    }

    /**
     * Configure for survey calls
     */
    public function configureForSurvey(): self
    {
        return $this->setTemperature(0.4)
                    ->setMaxDuration(8)
                    ->setWaitForGreeting(true)
                    ->addTag('survey')
                    ->setPriority('low')
                    ->setAnalysisSchema([
                        'survey_completed' => 'boolean',
                        'completion_percentage' => 'integer',
                        'feedback_category' => 'string',
                        'net_promoter_score' => 'integer'
                    ]);
    }

    /**
     * Set advanced speech settings
     */
    public function setSpeechSettings(array $settings): self
    {
        $validKeys = ['speed', 'pitch', 'volume', 'emphasis'];
        foreach ($settings as $key => $value) {
            if (in_array($key, $validKeys)) {
                $this->config['speech_settings'][$key] = $value;
            }
        }
        return $this;
    }

    /**
     * Set conversation flow rules
     */
    public function setConversationFlow(array $flowRules): self
    {
        $this->config['conversation_flow'] = $flowRules;
        return $this;
    }

    /**
     * Add lead qualification questions
     */
    public function addQualificationQuestions(array $questions): self
    {
        if (!isset($this->config['qualification_questions'])) {
            $this->config['qualification_questions'] = [];
        }
        $this->config['qualification_questions'] = array_merge(
            $this->config['qualification_questions'],
            $questions
        );
        return $this;
    }

    /**
     * Set call completion triggers
     */
    public function setCompletionTriggers(array $triggers): self
    {
        $this->config['completion_triggers'] = $triggers;
        return $this;
    }

    /**
     * Validate configuration before building
     */
    protected function validate(): bool
    {
        $required = ['voice', 'prompt'];
        foreach ($required as $field) {
            if (!isset($this->config[$field]) || empty($this->config[$field])) {
                throw new \InvalidArgumentException("Required field '$field' is missing or empty");
            }
        }
        return true;
    }

    /**
     * Build and return the configuration array
     */
    public function build(): array
    {
        $this->validate();
        return $this->config;
    }

    /**
     * Create a default lead generation call configuration
     */
    public static function createLeadGenerationCall(): self
    {
        return (new self())
            ->setModel('enhanced')
            ->setMaxDuration(12)
            ->setTemperature(0.5)
            ->setSummaryPrompt('Provide a complete summary of the call.')
            ->setWaitForGreeting(false)
            ->setRecording(true)
            ->setWebhookEvents(['call', 'webhook'])
            ->setAnalysisSchema([
                'Name' => 'string',
                'Email' => 'string',
                'Phone' => 'string',
                'Address' => 'string',
                'City' => 'string',
                'State' => 'string',
                'Country' => 'string',
                'Zip Code' => 'string',
                'Description' => 'string',
            ]);
    }

    /**
     * Create configuration for inbound calls
     */
    public static function createInboundCall(): self
    {
        return self::createLeadGenerationCall()
            ->setWaitForGreeting(true);
    }

    /**
     * Create configuration for outbound calls
     */
    public static function createOutboundCall(): self
    {
        return self::createLeadGenerationCall()
            ->setWaitForGreeting(false);
    }
}