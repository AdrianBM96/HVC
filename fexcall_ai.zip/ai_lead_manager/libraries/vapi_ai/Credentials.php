<?php

namespace modules\ai_lead_manager\libraries\vapi_ai;

trait Credentials
{
    /**
     * Retrieves a list of all credentials with optional filters.
     *
     * @param array $filters Optional associative array of filters to apply to the credentials list.
     * @return array The API response containing the list of credentials.
     */
    public function get_credentials($filters = [])
    {
        $endpoint = '/credential';

        if (!empty($filters)) {
            $endpoint .= '?' . http_build_query($filters);
        }

        return $this->send_request('GET', $endpoint);
    }

    /**
     * Creates a new credential.
     *
     * @param array $data An associative array containing the data for the new credential.
     * @return array The API response containing the created credential.
     */
    public function create_credential($data = [])
    {
        return $this->send_request('POST', '/credential', $data);
    }

    /**
     * Retrieves a credential by its ID.
     *
     * @param string $id The ID of the credential to retrieve.
     * @return array The API response containing the credential data.
     */
    public function get_credential_by_id($id)
    {
        return $this->send_request('GET', '/credential/' . $id);
    }

    /**
     * Updates a credential by its ID.
     *
     * @param string $id The ID of the credential to update.
     * @param array $data An associative array containing the updated credential data.
     * @return array The API response from the update request.
     */
    public function update_credential($id, $data = [])
    {
        return $this->send_request('PATCH', '/credential/' . $id, $data);
    }

    /**
     * Deletes a credential by its ID.
     *
     * @param string $id The ID of the credential to delete.
     * @return array The API response from the deletion request.
     */
    public function delete_credential($id)
    {
        return $this->send_request('DELETE', '/credential/' . $id);
    }

    /**
     * Retrieves BYO phone number credentials specifically.
     * Filters credentials to only return those with provider 'byo-phone-number'.
     *
     * @return array The API response containing BYO phone number credentials only.
     */
    public function get_byo_phone_credentials()
    {
        $response = $this->get_credentials();

        // Filter to only BYO phone number credentials
        if (isset($response['data']) && is_array($response['data'])) {
            $byo_credentials = array_filter($response['data'], function($credential) {
                return isset($credential['provider']) && $credential['provider'] === 'byo-phone-number';
            });

            return array_values($byo_credentials); // Reindex array
        } elseif (is_array($response) && !isset($response['error'])) {
            // Handle case where response is directly an array of credentials
            $byo_credentials = array_filter($response, function($credential) {
                return isset($credential['provider']) && $credential['provider'] === 'byo-phone-number';
            });

            return array_values($byo_credentials); // Reindex array
        }

        return isset($response['error']) ? $response : [];
    }
}