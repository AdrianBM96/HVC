<?php

namespace modules\ai_lead_manager\libraries\vapi_ai;

/**
 * Builder class for creating Vapi AI Knowledge Base configurations and Query Tools
 * Based on current Vapi API structure where knowledge bases are accessed via query tools
 */
class VapiKnowledgeBaseBuilder
{
    private $knowledgeBase = [];
    private $queryTool = [];

    public function __construct()
    {
        $this->reset();
    }

    /**
     * Reset builder to default state
     */
    public function reset(): self
    {
        $this->knowledgeBase = [
            'provider' => 'trieve',
            'name' => '',
            'searchPlan' => [
                'topK' => 10,
                'removeStopWords' => true,
                'scoreThreshold' => 0.7,
                'searchType' => 'fulltext',
            ],
        ];

        $this->queryTool = [
            'type' => 'query',
            'function' => [
                'name' => '',
            ],
            'knowledgeBases' => [],
        ];

        return $this;
    }

    /**
     * Set knowledge base name
     */
    public function setName(string $name): self
    {
        $this->knowledgeBase['name'] = $name;
        $this->queryTool['function']['name'] = $this->sanitizeToolName($name) . '-query';
        return $this;
    }

    /**
     * Set knowledge base provider (trieve, custom)
     */
    public function setProvider(string $provider): self
    {
        $this->knowledgeBase['provider'] = $provider;
        return $this;
    }

    /**
     * Set search configuration
     */
    public function setSearchPlan(
        int $topK = 10,
        bool $removeStopWords = true,
        float $scoreThreshold = 0.7,
        string $searchType = 'fulltext'
    ): self {
        $this->knowledgeBase['searchPlan'] = [
            'topK' => $topK,
            'removeStopWords' => $removeStopWords,
            'scoreThreshold' => $scoreThreshold,
            'searchType' => $searchType,
        ];
        return $this;
    }

    /**
     * Set create plan for knowledge base
     */
    public function setCreatePlan(string $type, string $providerId = null): self
    {
        $this->knowledgeBase['createPlan'] = [
            'type' => $type,
        ];
        
        if ($providerId) {
            $this->knowledgeBase['createPlan']['providerId'] = $providerId;
        }
        
        return $this;
    }

    /**
     * Add file IDs to knowledge base (used when creating query tool)
     */
    public function setFileIds(array $fileIds): self
    {
        $this->queryTool['fileIds'] = $fileIds;
        return $this;
    }

    /**
     * Set description for when to use this knowledge base
     */
    public function setDescription(string $description): self
    {
        $this->queryTool['description'] = $description;
        return $this;
    }

    /**
     * Build knowledge base creation configuration
     */
    public function buildKnowledgeBase(): array
    {
        return $this->knowledgeBase;
    }

    /**
     * Build query tool configuration (for assistant tools)
     */
    public function buildQueryTool(array $fileIds = [], string $description = ''): array
    {
        $tool = $this->queryTool;
        
        if (!empty($fileIds)) {
            $this->setFileIds($fileIds);
        }
        
        if (!empty($description)) {
            $this->setDescription($description);
        }

        // Create knowledge base configuration for query tool
        $kbConfig = [
            'provider' => 'google', // Current Vapi limitation for query tools
            'name' => $this->knowledgeBase['name'],
            'description' => $this->queryTool['description'] ?? "Use this knowledge base when users ask about {$this->knowledgeBase['name']}",
        ];

        if (isset($this->queryTool['fileIds'])) {
            $kbConfig['fileIds'] = $this->queryTool['fileIds'];
        }

        $tool['knowledgeBases'] = [$kbConfig];

        return $tool;
    }

    /**
     * Build complete configuration including both KB and query tool
     */
    public function buildComplete(array $fileIds = [], string $description = ''): array
    {
        return [
            'knowledgeBase' => $this->buildKnowledgeBase(),
            'queryTool' => $this->buildQueryTool($fileIds, $description),
        ];
    }

    /**
     * Sanitize name for tool function name
     */
    private function sanitizeToolName(string $name): string
    {
        // Convert to lowercase, replace spaces and special chars with hyphens
        $sanitized = strtolower($name);
        $sanitized = preg_replace('/[^a-z0-9]+/', '-', $sanitized);
        $sanitized = trim($sanitized, '-');
        return $sanitized;
    }

    /**
     * Create a customer support knowledge base
     */
    public static function createCustomerSupportKB(string $name = 'Customer Support'): self
    {
        return (new self())
            ->setName($name)
            ->setProvider('trieve')
            ->setSearchPlan(15, true, 0.8, 'fulltext')
            ->setDescription('Use this knowledge base when users ask questions about customer support, policies, procedures, or need help with products and services');
    }

    /**
     * Create a product information knowledge base
     */
    public static function createProductInfoKB(string $name = 'Product Information'): self
    {
        return (new self())
            ->setName($name)
            ->setProvider('trieve')
            ->setSearchPlan(12, true, 0.75, 'fulltext')
            ->setDescription('Use this knowledge base when users ask about product features, specifications, pricing, or product-related questions');
    }

    /**
     * Create a company policies knowledge base
     */
    public static function createCompanyPoliciesKB(string $name = 'Company Policies'): self
    {
        return (new self())
            ->setName($name)
            ->setProvider('trieve')
            ->setSearchPlan(8, true, 0.85, 'fulltext')
            ->setDescription('Use this knowledge base when users ask about company policies, terms of service, privacy policy, or legal information');
    }

    /**
     * Create a FAQ knowledge base
     */
    public static function createFaqKB(string $name = 'Frequently Asked Questions'): self
    {
        return (new self())
            ->setName($name)
            ->setProvider('trieve')
            ->setSearchPlan(10, true, 0.7, 'fulltext')
            ->setDescription('Use this knowledge base when users ask common questions or need general information that might be in the FAQ');
    }

    /**
     * Validate file types for Vapi knowledge base
     */
    public static function validateFileType(string $filename): bool
    {
        $allowedExtensions = ['pdf', 'doc', 'docx', 'txt', 'md', 'csv', 'json', 'xml', 'log', 'tsv', 'yaml', 'yml'];
        $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        return in_array($extension, $allowedExtensions);
    }

    /**
     * Validate file size for Vapi knowledge base (300KB limit)
     */
    public static function validateFileSize(int $fileSize): bool
    {
        return $fileSize <= (300 * 1024); // 300KB in bytes
    }

    /**
     * Get supported file types
     */
    public static function getSupportedFileTypes(): array
    {
        return ['pdf', 'doc', 'docx', 'txt', 'md', 'csv', 'json', 'xml', 'log', 'tsv', 'yaml', 'yml'];
    }

    /**
     * Get file accept string for HTML input
     */
    public static function getFileAcceptString(): string
    {
        $types = self::getSupportedFileTypes();
        return '.' . implode(',.', $types);
    }
}