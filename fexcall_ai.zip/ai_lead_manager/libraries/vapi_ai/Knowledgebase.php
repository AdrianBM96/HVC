<?php

namespace modules\ai_lead_manager\libraries\vapi_ai;

trait Knowledgebase
{
    /**
     * Retrieves a list of knowledge base entries with optional filters.
     *
     * @param array $filters Optional associative array of filters to apply to the knowledge base list.
     * @return array The API response containing the list of knowledge base entries.
     */
    public function list_knowledgebase($filters = [])
    {
        $endpoint = '/knowledge-base';

        if (!empty($filters)) {
            $endpoint .= '?' . http_build_query($filters);
        }

        return $this->send_request('GET', $endpoint);
    }

    /**
     * Creates a new knowledge base entry using the new Vapi structure.
     *
     * @param array $data An associative array containing the data for the new knowledge base entry.
     *                    Expected structure: ['provider' => 'trieve', 'name' => 'string', 'searchPlan' => [...], 'createPlan' => [...]]
     * @return array The API response from the knowledge base creation request.
     */
    public function create_knowledgebase($data = [])
    {
        // Ensure required fields are present for new Vapi structure
        if (!isset($data['provider'])) {
            $data['provider'] = 'trieve'; // Default to trieve as recommended
        }
        
        if (!isset($data['name'])) {
            return ['error' => 'Name is required for knowledge base creation'];
        }

        // Set default search plan if not provided
        if (!isset($data['searchPlan'])) {
            $data['searchPlan'] = [
                'topK' => 10,
                'removeStopWords' => true,
                'scoreThreshold' => 0.7,
                'searchType' => 'fulltext'
            ];
        }

        return $this->send_request('POST', '/knowledge-base', $data);
    }

    /**
     * Retrieves a knowledge base entry by its ID.
     *
     * @param string $id The ID of the knowledge base entry to retrieve.
     * @return array The API response containing the knowledge base entry data.
     */
    public function get_knowledgebase_by_id($id)
    {
        return $this->send_request('GET', '/knowledge-base/' . $id);
    }

    /**
     * Deletes a knowledge base entry by its ID.
     *
     * @param string $id The ID of the knowledge base entry to delete.
     * @return array The API response from the deletion request.
     */
    public function delete_knowledgebase($id)
    {
        return $this->send_request('DELETE', '/knowledge-base/' . $id);
    }

    /**
     * Updates a knowledge base entry by its ID.
     *
     * @param string $id The ID of the knowledge base entry to update.
     * @param array $data An associative array containing the updated data for the knowledge base entry.
     * @return array The API response from the update request.
     */
    public function update_knowledgebase($id, $data)
    {
        return $this->send_request('PATCH', '/knowledge-base/' . $id, $data);
    }

    /**
     * Upload file to knowledge base (corrected for current Vapi API)
     *
     * @param string $knowledge_base_id The ID of the knowledge base
     * @param string $file_path Path to the file to upload
     * @param string $file_name Optional custom filename
     * @return array The API response from the upload request
     */
    public function upload_file_to_knowledgebase($knowledge_base_id, $file_path, $file_name = null)
    {
        if (!file_exists($file_path)) {
            return ['error' => 'File does not exist: ' . $file_path];
        }

        $mime_type = mime_content_type($file_path);
        $file_name = $file_name ?? basename($file_path);

        $file = new \CURLFile($file_path);
        $file->setMimeType($mime_type);
        $file->setPostFilename($file_name);

        // Step 1: Upload file using the Files API
        $upload_response = $this->send_request('POST', '/file', ['file' => $file]);
        
        if (isset($upload_response['error'])) {
            return $upload_response;
        }
        
        if (!isset($upload_response['id'])) {
            return ['error' => 'File upload failed - no file ID returned'];
        }
        
        // Step 2: Associate file with knowledge base by updating the KB
        $file_id = $upload_response['id'];
        
        // Get current knowledge base to preserve existing file associations
        $kb = $this->get_knowledgebase_by_id($knowledge_base_id);
        if (isset($kb['error'])) {
            // Clean up the uploaded file if KB retrieval fails
            $this->delete_file($file_id);
            return ['error' => 'Failed to retrieve knowledge base: ' . $kb['error']];
        }
        
        // Add the new file ID to existing file IDs
        $existing_files = $kb['fileIds'] ?? [];
        if (!in_array($file_id, $existing_files)) {
            $existing_files[] = $file_id;
        }
        
        // Update knowledge base with new file
        $update_data = [
            'fileIds' => $existing_files
        ];
        
        $update_response = $this->update_knowledgebase($knowledge_base_id, $update_data);
        
        if (isset($update_response['error'])) {
            // Clean up the uploaded file if KB update fails
            $this->delete_file($file_id);
            return ['error' => 'Failed to associate file with knowledge base: ' . $update_response['error']];
        }
        
        return $upload_response; // Return the file upload response
    }

    /**
     * List files in a knowledge base
     *
     * @param string $knowledge_base_id The ID of the knowledge base
     * @param array $filters Optional filters
     * @return array The API response containing the list of files
     */
    public function list_knowledgebase_files($knowledge_base_id, $filters = [])
    {
        $endpoint = '/knowledge-base/' . $knowledge_base_id . '/file';

        if (!empty($filters)) {
            $endpoint .= '?' . http_build_query($filters);
        }

        return $this->send_request('GET', $endpoint);
    }

    /**
     * Delete a file from knowledge base
     *
     * @param string $knowledge_base_id The ID of the knowledge base
     * @param string $file_id The ID of the file to delete
     * @return array The API response from the deletion request
     */
    public function delete_knowledgebase_file($knowledge_base_id, $file_id)
    {
        return $this->send_request('DELETE', '/knowledge-base/' . $knowledge_base_id . '/file/' . $file_id);
    }
}
