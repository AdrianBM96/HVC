<?php

namespace modules\ai_lead_manager\libraries\vapi_ai;

/**
 * Builder class for creating Vapi AI Assistant configurations
 * Provides a fluent interface for building complex assistant settings
 */
class VapiAssistantBuilder
{
    private $config = [];

    public function __construct()
    {
        $this->reset();
    }

    /**
     * Reset builder to default state
     */
    public function reset(): self
    {
        $this->config = [
            'name' => 'AI Assistant',
            'firstMessage' => '',
            'transcriber' => [
                'provider' => 'deepgram',
                'model' => 'nova-2',
                'language' => 'en-US',
            ],
            'voice' => [
                'provider' => 'playht',
                'voiceId' => 'jennifer',
            ],
            'model' => [
                'provider' => 'openai',
                'model' => 'gpt-4',
                'temperature' => 0.7,
                'maxTokens' => 150,
                'emotionRecognitionEnabled' => false,
            ],
            // 'analysisSchema' => [],
            // 'tools' => [],
            // 'toolIds' => [],
        ];

        return $this;
    }

    /**
     * Set assistant name
     */
    public function setName(string $name): self
    {
        $this->config['name'] = $name;
        return $this;
    }

    /**
     * Set first message
     */
    public function setFirstMessage(string $message): self
    {
        $this->config['firstMessage'] = $message;
        return $this;
    }

    /**
     * Set transcriber configuration
     */
    public function setTranscriber(string $provider = 'deepgram', string $model = 'nova-2', string $language = 'en-US'): self
    {
        $this->config['transcriber'] = [
            'provider' => $provider,
            'model' => $model,
            'language' => $language,
        ];
        return $this;
    }

    /**
     * Set voice configuration
     */
    public function setVoice(string $provider, string $voiceId): self
    {
        $this->config['voice'] = [
            'provider' => $provider,
            'voiceId' => $voiceId,
        ];
        return $this;
    }

    /**
     * Set custom voice ID (when using custom voice)
     */
    public function setCustomVoiceId(string $voiceId): self
    {
        $this->config['voice'] = [
            'provider' => 'custom',
            'voiceId' => $voiceId,
        ];
        return $this;
    }

    /**
     * Set model configuration
     */
    public function setModel(
        string $provider = 'openai',
        string $model = 'gpt-4',
        float $temperature = 0.7,
        int $maxTokens = 150
    ): self {
        $this->config['model']['provider'] = $provider;
        $this->config['model']['model'] = $model;
        $this->config['model']['temperature'] = $temperature;
        $this->config['model']['maxTokens'] = $maxTokens;
        return $this;
    }

    /**
     * Set system prompt for the model
     */
    public function setSystemPrompt(string $prompt): self
    {
        $this->config['model']['messages'] = [
            [
                'role' => 'system',
                'content' => $prompt,
            ],
        ];
        return $this;
    }

    /**
     * Enable/disable emotion recognition
     */
    public function setEmotionRecognition(bool $enabled): self
    {
        $this->config['model']['emotionRecognitionEnabled'] = $enabled;
        return $this;
    }

    /**
     * Enable/disable filler injection
     */
    public function setFillerInjection(bool $enabled): self
    {
        $this->config['voice']['fillerInjectionEnabled'] = $enabled;
        return $this;
    }

    /**
     * Enable/disable back channeling
     */
    public function setBackChanneling(bool $enabled): self
    {
        $this->config['backChannelingEnabled'] = $enabled;
        return $this;
    }

    /**
     * Set call duration limits
     */
    public function setMaxDuration(int $seconds): self
    {
        $this->config['maxDurationSeconds'] = $seconds;
        return $this;
    }

    /**
     * Add analysis schema field
     */
    public function addAnalysisField(string $fieldName, string $type): self
    {
        $this->config['analysisSchema'][$fieldName] = $type;
        return $this;
    }

    /**
     * Set complete analysis schema
     */
    public function setAnalysisSchema(array $schema): self
    {
        $this->config['analysisSchema'] = $schema;
        return $this;
    }

    /**
     * Add a tool to the model
     */
    public function addTool(array $tool): self
    {
        if (!isset($this->config['model']['tools'])) {
            $this->config['model']['tools'] = [];
        }
        $this->config['model']['tools'][] = $tool;
        return $this;
    }

    /**
     * Add multiple tools to the model
     */
    public function addTools(array $tools): self
    {
        foreach ($tools as $tool) {
            $this->addTool($tool);
        }
        return $this;
    }

    /**
     * Add tool IDs to the model configuration (Vapi will resolve them)
     */
    public function addToolIds(array $toolIds): self
    {
        if (empty($toolIds)) {
            return $this;
        }

        if (!isset($this->config['model']['toolIds'])) {
            $this->config['model']['toolIds'] = [];
        }

        foreach ($toolIds as $toolId) {
            if (!in_array($toolId, $this->config['model']['toolIds'])) {
                $this->config['model']['toolIds'][] = $toolId;
            }
        }

        return $this;
    }

    /**
     * Set tool IDs in the model (replaces any existing toolIds)
     */
    public function setToolIds(array $toolIds): self
    {
        $this->config['model']['toolIds'] = array_values(array_unique($toolIds));
        return $this;
    }

    /**
     * Add knowledge base as query tool
     */
    public function addKnowledgeBase(string $name, array $fileIds, string $description = ''): self
    {
        $queryTool = [
            'type' => 'query',
            'function' => [
                'name' => $name . '-query',
            ],
            'knowledgeBases' => [
                [
                    'provider' => 'google', // Current Vapi limitation
                    'name' => $name,
                    'description' => $description ?: "Use this knowledge base when users ask about {$name}",
                    'fileIds' => $fileIds,
                ],
            ],
        ];

        return $this->addTool($queryTool);
    }

    /**
     * Enable end call function
     */
    public function enableEndCallFunction(bool $enabled = true): self
    {
        if ($enabled) {
            $endCallTool = [
                'type' => 'endCall',
                'function' => [
                    'name' => 'endCall',
                ],
            ];
            $this->addTool($endCallTool);
        }
        return $this;
    }

    /**
     * Enable dial keypad function
     */
    public function enableDialKeypadFunction(bool $enabled = true): self
    {
        if ($enabled) {
            $dialKeypadTool = [
                'type' => 'dtmf',
                'function' => [
                    'name' => 'dialKeypad',
                ],
            ];
            $this->addTool($dialKeypadTool);
        }
        return $this;
    }

    /**
     * Set structured data schema for analysis
     */
    public function setStructuredDataSchema(array $schema): self
    {
        if (!isset($this->config['analysisPlan'])) {
            $this->config['analysisPlan'] = [];
        }
        $this->config['analysisPlan']['structuredDataSchema'] = $schema;
        return $this;
    }

    /**
     * Set success evaluation prompt for analysis
     */
    public function setSuccessEvaluationPrompt(string $prompt): self
    {
        if (!isset($this->config['analysisPlan'])) {
            $this->config['analysisPlan'] = [];
        }
        $this->config['analysisPlan']['successEvaluationPrompt'] = $prompt;
        return $this;
    }

    /**
     * Set complete analysis plan
     */
    public function setAnalysisPlan(array $analysisPlan): self
    {
        $this->config['analysisPlan'] = $analysisPlan;
        return $this;
    }

    /**
     * Create lead generation structured data schema
     */
    public function setLeadGenerationSchema(): self
    {
        $schema = [
            'type' => 'object',
            'properties' => [
                'customer_name' => [
                    'type' => 'string',
                    'description' => 'The name of the customer'
                ],
                'customer_email' => [
                    'type' => 'string',
                    'description' => 'The email address of the customer'
                ],
                'customer_phonenumber' => [
                    'type' => 'string',
                    'description' => 'The phone number of the customer'
                ],
                'customer_address' => [
                    'type' => 'string',
                    'description' => 'The address of the customer'
                ],
                'customer_city' => [
                    'type' => 'string',
                    'description' => 'The city of the customer'
                ],
                'customer_state' => [
                    'type' => 'string',
                    'description' => 'The state of the customer'
                ],
                'customer_country' => [
                    'type' => 'string',
                    'description' => 'The country of the customer'
                ],
                'customer_zip' => [
                    'type' => 'integer',
                    'description' => 'The zip code of the customer'
                ],
                'description' => [
                    'type' => 'string',
                    'description' => 'A description of the customer'
                ]
            ],
            'required' => ['customer_name', 'customer_email', 'customer_phonenumber', 'description']
        ];

        return $this->setStructuredDataSchema($schema)
            ->setSuccessEvaluationPrompt("Evaluate the call's success based on the customer's satisfaction, the completeness of the information provided, and whether any appointments were scheduled.");
    }

    /**
     * Set server URL for webhooks
     */
    public function setServerUrl(string $url): self
    {
        $this->config['serverUrl'] = $url;
        return $this;
    }

    /**
     * Set server messages configuration
     */
    public function setServerMessages(array $messages): self
    {
        $this->config['serverMessages'] = $messages;
        return $this;
    }

    /**
     * Set start speaking plan configuration
     */
    public function setStartSpeakingPlan(array $plan): self
    {
        $this->config['startSpeakingPlan'] = $plan;
        return $this;
    }

    /**
     * Enable smart endpointing in start speaking plan
     */
    public function enableSmartEndpointing(bool $enabled = true): self
    {
        if (!isset($this->config['startSpeakingPlan'])) {
            $this->config['startSpeakingPlan'] = [];
        }
        $this->config['startSpeakingPlan']['smartEndpointingEnabled'] = $enabled;
        return $this;
    }

    /**
     * Set stop speaking plan configuration
     */
    public function setStopSpeakingPlan(array $plan): self
    {
        $this->config['stopSpeakingPlan'] = $plan;
        return $this;
    }

    /**
     * Configure stop speaking plan with specific parameters
     */
    public function configureStopSpeaking(int $numWords = 2, float $voiceSeconds = 0.2, float $backoffSeconds = 1): self
    {
        $this->config['stopSpeakingPlan'] = [
            'numWords' => $numWords,
            'voiceSeconds' => $voiceSeconds,
            'backoffSeconds' => $backoffSeconds
        ];
        return $this;
    }

    /**
     * Set end call phrases
     */
    public function setEndCallPhrases(array $phrases): self
    {
        $this->config['endCallPhrases'] = $phrases;
        return $this;
    }

    /**
     * Set default end call phrases
     */
    public function setDefaultEndCallPhrases(): self
    {
        return $this->setEndCallPhrases([
            "Have a great day",
            "Goodbye",
            "Thank you for your time"
        ]);
    }

    /**
     * Set dial keypad function enabled
     */
    public function setDialKeypadFunctionEnabled(bool $enabled): self
    {
        $this->config['dialKeypadFunctionEnabled'] = $enabled;
        return $this;
    }

    /**
     * Set end call function enabled
     */
    public function setEndCallFunctionEnabled(bool $enabled): self
    {
        $this->config['endCallFunctionEnabled'] = $enabled;
        return $this;
    }

    /**
     * Set backchanelling enabled
     */
    public function setBackChannelingEnabled(bool $enabled): self
    {
        $this->config['backchannelingEnabled'] = $enabled;
        return $this;
    }

    /**
     * Add schema field to structured data schema
     */
    public function addSchemaField(string $fieldName, string $type, string $description, bool $required = false): self
    {
        if (!isset($this->config['analysisPlan']['structuredDataSchema'])) {
            $this->config['analysisPlan']['structuredDataSchema'] = [
                'type' => 'object',
                'properties' => [],
                'required' => []
            ];
        }

        $this->config['analysisPlan']['structuredDataSchema']['properties'][$fieldName] = [
            'type' => $type,
            'description' => $description
        ];

        if ($required) {
            if (!in_array($fieldName, $this->config['analysisPlan']['structuredDataSchema']['required'])) {
                $this->config['analysisPlan']['structuredDataSchema']['required'][] = $fieldName;
            }
        }

        return $this;
    }

    /**
     * Set voice provider specific settings
     */
    public function setVoiceProviderSettings(string $provider, array $settings): self
    {
        $this->config['voice']['provider'] = $provider;
        foreach ($settings as $key => $value) {
            $this->config['voice'][$key] = $value;
        }
        return $this;
    }

    /**
     * Set language for transcriber
     */
    public function setTranscriberLanguage(string $language): self
    {
        $this->config['transcriber']['language'] = $language;
        return $this;
    }

    /**
     * Set transcriber provider and model
     */
    public function setTranscriberProvider(string $provider, string $model = null): self
    {
        $this->config['transcriber']['provider'] = $provider;
        if ($model) {
            $this->config['transcriber']['model'] = $model;
        }
        return $this;
    }

    /**
     * Add custom messages to model
     */
    public function addModelMessage(string $role, string $content): self
    {
        if (!isset($this->config['model']['messages'])) {
            $this->config['model']['messages'] = [];
        }

        $this->config['model']['messages'][] = [
            'role' => $role,
            'content' => $content
        ];

        return $this;
    }

    /**
     * Set model provider and specific settings
     */
    public function setModelProvider(string $provider, array $settings = []): self
    {
        $this->config['model']['provider'] = $provider;
        foreach ($settings as $key => $value) {
            $this->config['model'][$key] = $value;
        }
        return $this;
    }

    /**
     * Replace company placeholders in first message
     */
    public function replaceCompanyPlaceholders(): self
    {
        $replacements = [
            '{company_name}' => get_option('invoice_company_name'),
            '{address}' => get_option('invoice_company_address'),
            '{city}' => get_option('invoice_company_city'),
            '{state}' => get_option('invoice_company_state'),
            '{zip}' => get_option('invoice_company_zip'),
            '{country}' => get_option('invoice_company_country'),
        ];

        if (isset($this->config['firstMessage'])) {
            $this->config['firstMessage'] = str_replace(
                array_keys($replacements),
                array_values($replacements),
                $this->config['firstMessage']
            );
        }

        return $this;
    }

    /**
     * Set complete webhook configuration
     */
    public function setWebhookConfiguration(string $url, array $messages = ['end-of-call-report']): self
    {
        return $this->setServerUrl($url)->setServerMessages($messages);
    }

    /**
     * Configure for inbound calls
     */
    public function configureForInbound(string $webhookUrl = null): self
    {
        if ($webhookUrl) {
            $this->setServerUrl($webhookUrl);
        }

        return $this->setServerMessages(['end-of-call-report'])
            ->enableSmartEndpointing()
            ->configureStopSpeaking(2, 0.2, 1)
            ->setDefaultEndCallPhrases();
    }

    /**
     * Configure for outbound calls  
     */
    public function configureForOutbound(string $webhookUrl = null): self
    {
        if ($webhookUrl) {
            $this->setServerUrl($webhookUrl);
        }

        return $this->setServerMessages(['end-of-call-report'])
            ->enableSmartEndpointing()
            ->configureStopSpeaking(1, 0.1, 0.5)
            ->setDefaultEndCallPhrases();
    }

    /**
     * Build and return the configuration array
     */
    public function build(): array
    {
        $config = $this->config;
        
        // Remove empty arrays from model to prevent API errors
        if (isset($config['model']['tools']) && empty($config['model']['tools'])) {
            unset($config['model']['tools']);
        }
        
        if (isset($config['model']['toolIds']) && empty($config['model']['toolIds'])) {
            unset($config['model']['toolIds']);
        }
        
        return $config;
    }

    /**
     * Build configuration for specific call type (inbound/outbound)
     */
    public function buildForCallType(string $callType, array $additionalTools = [], array $additionalKnowledgeBases = []): array
    {
        $config = $this->config;

        // Add call-type specific tools to model
        if (!empty($additionalTools)) {
            if (!isset($config['model']['tools'])) {
                $config['model']['tools'] = [];
            }
            foreach ($additionalTools as $tool) {
                $config['model']['tools'][] = $tool;
            }
        }

        // Add call-type specific knowledge bases to model
        if (!empty($additionalKnowledgeBases)) {
            if (!isset($config['model']['tools'])) {
                $config['model']['tools'] = [];
            }
            foreach ($additionalKnowledgeBases as $kbData) {
                $queryTool = [
                    'type' => 'query',
                    'function' => [
                        'name' => $kbData['name'] . '-query',
                    ],
                    'knowledgeBases' => [
                        [
                            'provider' => 'google',
                            'name' => $kbData['name'],
                            'description' => $kbData['description'] ?? "Knowledge base for {$callType} calls",
                            'fileIds' => $kbData['fileIds'],
                        ],
                    ],
                ];
                $config['model']['tools'][] = $queryTool;
            }
        }

        // Remove empty arrays from model to prevent API errors
        if (isset($config['model']['tools']) && empty($config['model']['tools'])) {
            unset($config['model']['tools']);
        }
        
        if (isset($config['model']['toolIds']) && empty($config['model']['toolIds'])) {
            unset($config['model']['toolIds']);
        }

        return $config;
    }

    /**
     * Create a default lead generation assistant
     */
    public static function createLeadGenerationAssistant(): self
    {
        return (new self())
            ->setName('AI Lead Manager')
            ->setTranscriber('deepgram', 'nova-2', 'en-US')
            ->setModel('openai', 'gpt-4', 0.7, 150)
            ->setAnalysisSchema([
                'Name' => 'string',
                'Email' => 'string',
                'Phone' => 'string',
                'Address' => 'string',
                'City' => 'string',
                'State' => 'string',
                'Country' => 'string',
                'Zip Code' => 'string',
                'Description' => 'string',
            ])
            ->enableEndCallFunction()
            ->enableDialKeypadFunction();
    }
}
