<?php

namespace modules\ai_lead_manager\libraries;

/**
 * Builder class for transforming webhook data into standardized format
 * Handles data mapping between different AI providers (Vapi, Bland AI) and database structure
 */
class WebhookDataBuilder
{
    private $provider;
    private $rawData;
    private $transformedData = [];
    private $callLogData = [];
    private $leadData = [];
    private $metadata = [];

    public function __construct(string $provider)
    {
        $this->provider = $provider;
        $this->reset();
    }

    /**
     * Factory method to create builder for specific provider
     */
    public static function forProvider(string $provider): self
    {
        return new self($provider);
    }

    /**
     * Reset builder to initial state
     */
    public function reset(): self
    {
        $this->rawData = null;
        $this->transformedData = [];
        $this->callLogData = [];
        $this->leadData = [];
        $this->metadata = [];
        return $this;
    }

    /**
     * Set the raw webhook payload data
     */
    public function fromWebhookPayload(array $data): self
    {
        $this->rawData = $data;
        return $this;
    }

    /**
     * Map call-specific data from webhook
     */
    public function mapCallData(): self
    {
        switch ($this->provider) {
            case 'vapi_ai':
                $this->mapVapiCallData();
                break;
            case 'bland_ai':
                $this->mapBlandCallData();
                break;
        }
        return $this;
    }

    /**
     * Map Vapi AI call data
     */
    private function mapVapiCallData(): void
    {
        if (!$this->rawData) return;

        $message = $this->rawData['message'] ?? [];
        
        $this->callLogData = [
            'call_id' => $message['call']['id'] ?? '',
            'to_number' => $message['customer']['number'] ?? '',
            'from_number' => $message['phoneNumber']['number'] ?? '',
            'status' => $message['call']['status'] ?? 'completed',
            'call_length' => $message['durationMinutes'] ?? 0,
            'recording_url' => $message['recordingUrl'] ?? '',
            'transcripts' => json_encode($message['messages'] ?? []),
            'summary' => $message['summary'] ?? '',
            'call_ended_by' => $message['endedReason'] ?? '',
            'price' => $message['cost'] ?? 0,
            'ai_provider' => 'vapi_ai'
        ];
    }

    /**
     * Map Bland AI call data
     */
    private function mapBlandCallData(): void
    {
        if (!$this->rawData) return;

        $this->callLogData = [
            'call_id' => $this->rawData['call_id'] ?? '',
            'to_number' => $this->rawData['to'] ?? '',
            'from_number' => $this->rawData['from'] ?? '',
            'status' => $this->rawData['status'] ?? 'completed',
            'call_length' => $this->rawData['call_length'] ?? 0,
            'recording_url' => $this->rawData['recording_url'] ?? '',
            'transcripts' => json_encode($this->rawData['transcripts'] ?? []),
            'summary' => $this->rawData['summary'] ?? '',
            'call_ended_by' => $this->rawData['call_ended_by'] ?? '',
            'price' => $this->rawData['price'] ?? 0,
            'ai_provider' => 'bland_ai'
        ];
    }

    /**
     * Map lead data from webhook analysis
     */
    public function mapLeadData(): self
    {
        switch ($this->provider) {
            case 'vapi_ai':
                $this->mapVapiLeadData();
                break;
            case 'bland_ai':
                $this->mapBlandLeadData();
                break;
        }
        return $this;
    }

    /**
     * Map Vapi AI lead data from analysis
     */
    private function mapVapiLeadData(): void
    {
        if (!$this->rawData) return;

        $analysis = $this->rawData['message']['analysis']['structuredData'] ?? [];
        
        $this->leadData = [
            'name' => $analysis['customer_name'] ?? '',
            'email' => $analysis['customer_email'] ?? '',
            'phonenumber' => $this->rawData['message']['customer']['number'] ?? '',
            'address' => $analysis['customer_address'] ?? '',
            'city' => $analysis['customer_city'] ?? '',
            'state' => $analysis['customer_state'] ?? '',
            'country' => $analysis['customer_country'] ?? '',
            'zip' => $analysis['customer_zip'] ?? '',
            'description' => $analysis['description'] ?? '',
            'source' => get_option('ai_lead_manager_lead_source'),
            'status' => get_option('ai_lead_manager_lead_status'), // Active lead
            'dateadded' => date('Y-m-d H:i:s'),
            'addedfrom' => get_staff_user_id()
        ];
    }

    /**
     * Map Bland AI lead data from variables
     */
    private function mapBlandLeadData(): void
    {
        if (!$this->rawData) return;

        $variables = $this->rawData['variables'] ?? [];
        
        $this->leadData = [
            'name' => $variables['Name'] ?? '',
            'email' => $variables['Email'] ?? '',
            'phonenumber' => $this->cleanPhoneNumber($variables['Phone'] ?? ''),
            'address' => $variables['Address'] ?? '',
            'city' => $variables['City'] ?? '',
            'state' => $variables['State'] ?? '',
            'country' => $variables['Country'] ?? '',
            'zip' => $variables['Zip Code'] ?? '',
            'description' => $variables['Description'] ?? '',
            'source' => 'bland_ai_call',
            'status' => 1,
            'public' => 0,
            'dateadded' => date('Y-m-d H:i:s'),
            'addedfrom' => get_staff_user_id()
        ];
    }

    /**
     * Add metadata for database relationships
     */
    public function addMetadata(array $metadata): self
    {
        $this->metadata = array_merge($this->metadata, $metadata);
        return $this;
    }

    /**
     * Set relationship metadata (rel_type, rel_id)
     */
    public function setRelationship(string $relType, int $relId): self
    {
        $this->metadata['rel_type'] = $relType;
        $this->metadata['rel_id'] = $relId;
        return $this;
    }

    /**
     * Add custom field data
     */
    public function addCustomFieldData(array $customFields): self
    {
        foreach ($customFields as $field => $value) {
            if (!empty($value)) {
                $this->leadData[$field] = $value;
            }
        }
        return $this;
    }

    /**
     * Validate required lead data fields
     */
    public function validateLeadData(): bool
    {
        $required = ['name', 'phonenumber'];
        foreach ($required as $field) {
            if (empty($this->leadData[$field])) {
                return false;
            }
        }
        return true;
    }

    /**
     * Filter out empty or invalid data
     */
    public function filterEmptyData(): self
    {
        $this->leadData = array_filter($this->leadData, function($value) {
            return !is_null($value) && $value !== '';
        });

        $this->callLogData = array_filter($this->callLogData, function($value) {
            return !is_null($value) && $value !== '';
        });

        return $this;
    }

    /**
     * Build and return all transformed data
     */
    public function build(): array
    {
        // $this->filterEmptyData();
        
        return [
            'callLog' => $this->callLogData,
            'lead' => $this->leadData,
            'metadata' => $this->metadata,
            'isValid' => $this->validateLeadData()
        ];
    }

    /**
     * Build only call log data
     */
    public function buildCallLog(): array
    {
        return $this->callLogData;
    }

    /**
     * Build only lead data
     */
    public function buildLead(): array
    {
        $this->filterEmptyData();
        return $this->leadData;
    }

    /**
     * Helper: Calculate call duration in seconds
     */
    private function calculateDuration(?string $startTime, ?string $endTime): int
    {
        if (!$startTime || !$endTime) {
            return 0;
        }

        try {
            $start = new \DateTime($startTime);
            $end = new \DateTime($endTime);
            return $end->getTimestamp() - $start->getTimestamp();
        } catch (\Exception $e) {
            return 0;
        }
    }

    /**
     * Helper: Extract transcript from Vapi message
     */
    private function extractTranscript(array $message): string
    {
        if (isset($message['transcript'])) {
            return is_array($message['transcript']) 
                ? json_encode($message['transcript']) 
                : $message['transcript'];
        }

        if (isset($message['call']['transcript'])) {
            return is_array($message['call']['transcript']) 
                ? json_encode($message['call']['transcript']) 
                : $message['call']['transcript'];
        }

        return '';
    }

    /**
     * Helper: Clean and validate phone number
     */
    private function cleanPhoneNumber(string $phone): string
    {
        // Remove all non-digit characters
        $cleaned = preg_replace('/[^0-9]/', '', $phone);
        
        // Handle common formats
        if (strlen($cleaned) === 11 && substr($cleaned, 0, 1) === '1') {
            return substr($cleaned, 1); // Remove leading 1 for US numbers
        }
        
        return $cleaned;
    }

    /**
     * Add call outcome data
     */
    public function setCallOutcome(string $outcome, array $details = []): self
    {
        $this->callLogData['outcome'] = $outcome;
        $this->callLogData['outcome_details'] = json_encode($details);
        return $this;
    }

    /**
     * Set lead quality score based on analysis
     */
    public function setLeadQuality(int $score, array $factors = []): self
    {
        $this->leadData['quality_score'] = $score;
        $this->metadata['quality_factors'] = $factors;
        return $this;
    }

    /**
     * Add conversation sentiment analysis
     */
    public function addSentimentAnalysis(array $sentiment): self
    {
        $this->callLogData['sentiment'] = json_encode($sentiment);
        return $this;
    }
}