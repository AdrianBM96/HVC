<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Simple test class for PhoneNumberFormatter
 * This is for development/debugging purposes only
 */
class PhoneNumberFormatterTest
{
    /**
     * Run basic tests on the phone number formatter
     * 
     * @return array Test results
     */
    public static function runBasicTests()
    {
        $test_cases = [
            // US/Canada numbers
            ['input' => '5551234567', 'country' => 'US', 'expected' => '+15551234567'],
            ['input' => '(555) 123-4567', 'country' => 'US', 'expected' => '+15551234567'],
            ['input' => '+15551234567', 'country' => 'US', 'expected' => '+15551234567'],
            ['input' => '1-555-123-4567', 'country' => 'US', 'expected' => '+15551234567'],
            ['input' => '555.123.4567', 'country' => 'US', 'expected' => '+15551234567'],
            
            // UK numbers
            ['input' => '7700900123', 'country' => 'GB', 'expected' => '+447700900123'],
            ['input' => '+447700900123', 'country' => 'GB', 'expected' => '+447700900123'],
            
            // German numbers
            ['input' => '1701234567', 'country' => 'DE', 'expected' => '+491701234567'],
            ['input' => '+491701234567', 'country' => 'DE', 'expected' => '+491701234567'],
            
            // Invalid numbers (should fail)
            ['input' => '123', 'country' => 'US', 'expected' => null], // Too short
            ['input' => '0551234567', 'country' => 'US', 'expected' => null], // Invalid area code
            ['input' => '1551234567', 'country' => 'US', 'expected' => null], // Invalid area code
        ];
        
        $results = [];
        $passed = 0;
        $failed = 0;
        
        foreach ($test_cases as $i => $test) {
            $result = PhoneNumberFormatter::formatToE164($test['input'], $test['country']);
            
            $test_result = [
                'test_case' => $i + 1,
                'input' => $test['input'],
                'country' => $test['country'],
                'expected' => $test['expected'],
                'actual' => $result['success'] ? $result['formatted'] : 'FAILED: ' . $result['error'],
                'passed' => false
            ];
            
            if ($test['expected'] === null) {
                // Expected to fail
                $test_result['passed'] = !$result['success'];
            } else {
                // Expected to succeed with specific result
                $test_result['passed'] = $result['success'] && $result['formatted'] === $test['expected'];
            }
            
            if ($test_result['passed']) {
                $passed++;
            } else {
                $failed++;
            }
            
            $results[] = $test_result;
        }
        
        return [
            'summary' => [
                'total' => count($test_cases),
                'passed' => $passed,
                'failed' => $failed,
                'success_rate' => round(($passed / count($test_cases)) * 100, 1) . '%'
            ],
            'details' => $results
        ];
    }

    /**
     * Test batch formatting functionality
     * 
     * @return array Test results
     */
    public static function testBatchFormatting()
    {
        $test_numbers = [
            '5551234567',
            '(555) 987-6543',
            '+15551112222',
            '555.444.3333',
            '123', // Invalid
            '(555) 000-1234', // Invalid area code
        ];
        
        $result = PhoneNumberFormatter::batchFormat($test_numbers, 'US');
        
        return [
            'batch_summary' => $result,
            'expected_success' => 4,
            'expected_failed' => 2,
            'test_passed' => $result['success'] === 4 && $result['failed'] === 2
        ];
    }
}