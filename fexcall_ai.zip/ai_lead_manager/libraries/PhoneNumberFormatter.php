<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Phone Number Formatter for AI Lead Manager
 * 
 * This class provides phone number validation and formatting to E.164 standard
 * which is required by VAPI and most telephony services.
 */
class PhoneNumberFormatter
{
    /**
     * Default country code mappings for common countries
     */
    private static $country_codes = [
        'US' => '+1',
        'CA' => '+1', 
        'GB' => '+44',
        'AU' => '+61',
        'DE' => '+49',
        'FR' => '+33',
        'IT' => '+39',
        'ES' => '+34',
        'NL' => '+31',
        'BE' => '+32',
        'CH' => '+41',
        'AT' => '+43',
        'SE' => '+46',
        'NO' => '+47',
        'DK' => '+45',
        'FI' => '+358',
        'IS' => '+354',
        'IE' => '+353',
        'PT' => '+351',
        'GR' => '+30',
        'PL' => '+48',
        'CZ' => '+420',
        'HU' => '+36',
        'RO' => '+40',
        'BG' => '+359',
        'HR' => '+385',
        'SI' => '+386',
        'SK' => '+421',
        'LT' => '+370',
        'LV' => '+371',
        'EE' => '+372',
        'JP' => '+81',
        'KR' => '+82',
        'CN' => '+86',
        'IN' => '+91',
        'SG' => '+65',
        'MY' => '+60',
        'TH' => '+66',
        'PH' => '+63',
        'ID' => '+62',
        'VN' => '+84',
        'HK' => '+852',
        'TW' => '+886',
        'MX' => '+52',
        'BR' => '+55',
        'AR' => '+54',
        'CL' => '+56',
        'CO' => '+57',
        'PE' => '+51',
        'VE' => '+58',
        'ZA' => '+27',
        'NG' => '+234',
        'KE' => '+254',
        'GH' => '+233',
        'EG' => '+20',
        'MA' => '+212',
        'IL' => '+972',
        'AE' => '+971',
        'SA' => '+966',
        'TR' => '+90',
        'RU' => '+7',
        'UA' => '+380',
        'BY' => '+375',
        'KZ' => '+7',
        'UZ' => '+998',
        'NZ' => '+64'
    ];

    /**
     * Phone number length ranges by country code
     */
    private static $length_validation = [
        '+1' => [10, 11], // US/CA: 10 digits without country code
        '+44' => [10, 11], // UK
        '+49' => [10, 12], // Germany
        '+33' => [9, 10],  // France
        '+39' => [9, 10],  // Italy
        '+34' => [9, 9],   // Spain
        '+91' => [10, 10], // India
        '+86' => [11, 11], // China
        '+81' => [10, 11], // Japan
        '+82' => [10, 11], // South Korea
        '+61' => [9, 10],  // Australia
        '+65' => [8, 8],   // Singapore
        '+971' => [8, 9],  // UAE
        '+966' => [9, 9],  // Saudi Arabia
        '+7' => [10, 10],  // Russia/Kazakhstan
    ];

    /**
     * Default country for phone number formatting
     * @var string
     */
    private static $default_country = 'US';

    /**
     * Set default country for phone number formatting
     * 
     * @param string $country_code ISO 2-letter country code (e.g., 'US', 'GB', 'DE')
     */
    public static function setDefaultCountry($country_code)
    {
        $country_code = strtoupper($country_code);
        if (isset(self::$country_codes[$country_code])) {
            self::$default_country = $country_code;
        }
    }

    /**
     * Format phone number to E.164 standard
     * This function is designed to be very lenient and auto-correct rather than reject numbers
     * 
     * @param string $phone_number Raw phone number
     * @param string $country_code ISO 2-letter country code (optional, uses default if not provided)
     * @return array ['success' => bool, 'formatted' => string, 'original' => string, 'error' => string]
     */
    public static function formatToE164($phone_number, $country_code = null)
    {
        $original = $phone_number;
        $country_code = $country_code ? strtoupper($country_code) : self::$default_country;
        
        // If empty or too short, reject only extreme cases
        if (empty($phone_number) || strlen(preg_replace('/[^\d]/', '', $phone_number)) < 7) {
            return [
                'success' => false,
                'formatted' => '',
                'original' => $original,
                'error' => 'Phone number too short (minimum 7 digits required)'
            ];
        }
        
        // Remove all non-digit characters except +
        $cleaned = preg_replace('/[^\d+]/', '', $phone_number);
        
        // If already starts with +, try to clean and validate
        if (substr($cleaned, 0, 1) === '+') {
            // Basic length check for E.164 (7-15 digits after +)
            $digits_only = substr($cleaned, 1);
            if (strlen($digits_only) >= 7 && strlen($digits_only) <= 15) {
                return [
                    'success' => true,
                    'formatted' => $cleaned,
                    'original' => $original,
                    'country_detected' => self::detectCountryFromE164($cleaned)
                ];
            }
        }
        
        // Get country code for formatting - default to US if unsupported
        if (!isset(self::$country_codes[$country_code])) {
            $country_code = 'US'; // Fallback to US
        }
        
        $country_prefix = self::$country_codes[$country_code];
        
        // Remove leading zeros
        $cleaned = ltrim($cleaned, '0');
        
        // Handle US/CA numbers with auto-correction
        if ($country_code === 'US' || $country_code === 'CA') {
            // If starts with 1, it might already include country code
            if (substr($cleaned, 0, 1) === '1' && strlen($cleaned) === 11) {
                $cleaned = substr($cleaned, 1); // Remove the 1
            }
            
            // Try to auto-correct common US number formats
            if (strlen($cleaned) < 10) {
                // Pad with zeros if too short (common data entry error)
                $cleaned = str_pad($cleaned, 10, '0', STR_PAD_LEFT);
            } else if (strlen($cleaned) > 10) {
                // Take last 10 digits if too long
                $cleaned = substr($cleaned, -10);
            }
            
            // Auto-correct area codes that start with 0 or 1 (make them start with 2)
            if (strlen($cleaned) === 10) {
                $area_code = substr($cleaned, 0, 3);
                if ($area_code[0] === '0') {
                    $cleaned = '2' . substr($cleaned, 1); // Change 0xx to 2xx
                } else if ($area_code[0] === '1') {
                    $cleaned = '2' . substr($cleaned, 1); // Change 1xx to 2xx
                }
            }
        } else {
            // For other countries, be more lenient
            // Remove country code if it appears to be duplicated
            $prefix_digits = substr($country_prefix, 1);
            if (strlen($cleaned) > 10 && substr($cleaned, 0, strlen($prefix_digits)) === $prefix_digits) {
                // Already has country code, just add +
                return [
                    'success' => true,
                    'formatted' => '+' . $cleaned,
                    'original' => $original,
                    'country_detected' => $country_code
                ];
            }
        }
        
        // Build final formatted number
        $formatted = $country_prefix . $cleaned;
        
        // Final length check - be lenient
        $digits_only = substr($formatted, 1);
        if (strlen($digits_only) < 7 || strlen($digits_only) > 15) {
            return [
                'success' => false,
                'formatted' => '',
                'original' => $original,
                'error' => 'Unable to format phone number to valid length'
            ];
        }
        
        return [
            'success' => true,
            'formatted' => $formatted,
            'original' => $original,
            'country_detected' => $country_code
        ];
    }

    /**
     * Validate E.164 formatted phone number
     * 
     * @param string $phone_number E.164 formatted number
     * @return array ['valid' => bool, 'error' => string, 'country' => string]
     */
    public static function validateE164($phone_number)
    {
        // Must start with + and contain only digits after
        if (!preg_match('/^\+\d{7,15}$/', $phone_number)) {
            return [
                'valid' => false,
                'error' => 'Invalid E.164 format (must be +[7-15 digits])',
                'country' => null
            ];
        }
        
        // Check length is reasonable (E.164 allows 7-15 digits after +)
        $digits_only = substr($phone_number, 1);
        if (strlen($digits_only) < 7 || strlen($digits_only) > 15) {
            return [
                'valid' => false,
                'error' => 'Invalid length (E.164 allows 7-15 digits)',
                'country' => null
            ];
        }
        
        // Try to detect country
        $detected_country = self::detectCountryFromE164($phone_number);
        
        return [
            'valid' => true,
            'error' => '',
            'country' => $detected_country
        ];
    }

    /**
     * Detect country from E.164 formatted number
     * 
     * @param string $e164_number
     * @return string|null Country code or null if not detected
     */
    public static function detectCountryFromE164($e164_number)
    {
        // Sort country codes by length (longest first) for better matching
        $codes_by_length = [];
        foreach (self::$country_codes as $country => $code) {
            $code_length = strlen($code);
            if (!isset($codes_by_length[$code_length])) {
                $codes_by_length[$code_length] = [];
            }
            $codes_by_length[$code_length][$country] = $code;
        }
        krsort($codes_by_length); // Sort by length descending
        
        // Try to match longest codes first
        foreach ($codes_by_length as $length => $codes) {
            foreach ($codes as $country => $code) {
                if (substr($e164_number, 0, strlen($code)) === $code) {
                    return $country;
                }
            }
        }
        
        return null;
    }

    /**
     * Batch format multiple phone numbers
     * 
     * @param array $phone_numbers Array of phone numbers
     * @param string $default_country Default country code for formatting
     * @return array ['success' => int, 'failed' => int, 'results' => array, 'errors' => array]
     */
    public static function batchFormat($phone_numbers, $default_country = null)
    {
        if ($default_country) {
            self::setDefaultCountry($default_country);
        }
        
        $results = [];
        $errors = [];
        $success_count = 0;
        $failed_count = 0;
        
        foreach ($phone_numbers as $index => $phone_number) {
            $result = self::formatToE164($phone_number);
            $results[$index] = $result;
            
            if ($result['success']) {
                $success_count++;
            } else {
                $failed_count++;
                $errors[] = "Row " . ($index + 1) . ": {$phone_number} - {$result['error']}";
            }
        }
        
        return [
            'success' => $success_count,
            'failed' => $failed_count,
            'results' => $results,
            'errors' => $errors
        ];
    }

    /**
     * Get supported countries list
     * 
     * @return array Country codes and their phone prefixes
     */
    public static function getSupportedCountries()
    {
        return self::$country_codes;
    }

    /**
     * Suggest corrections for malformed phone numbers
     * 
     * @param string $phone_number
     * @param string $country_code
     * @return array Suggested corrections
     */
    public static function suggestCorrections($phone_number, $country_code = null)
    {
        $suggestions = [];
        $country_code = $country_code ? strtoupper($country_code) : self::$default_country;
        
        // Clean the number
        $cleaned = preg_replace('/[^\d+]/', '', $phone_number);
        
        // Remove leading zeros
        $no_leading_zeros = ltrim($cleaned, '0');
        
        // Try different interpretations
        if ($country_code === 'US' || $country_code === 'CA') {
            // Try assuming it's missing country code
            if (strlen($cleaned) === 10) {
                $suggestions[] = [
                    'suggestion' => '+1' . $cleaned,
                    'description' => 'Added US/Canada country code (+1)'
                ];
            }
            
            // Try removing leading 1 if 11 digits
            if (strlen($cleaned) === 11 && substr($cleaned, 0, 1) === '1') {
                $without_one = substr($cleaned, 1);
                $suggestions[] = [
                    'suggestion' => '+1' . $without_one,
                    'description' => 'Interpreted leading 1 as country code'
                ];
            }
        }
        
        // Try with default country code
        if (!empty($no_leading_zeros) && isset(self::$country_codes[$country_code])) {
            $with_country = self::$country_codes[$country_code] . $no_leading_zeros;
            if (self::validateE164($with_country)['valid']) {
                $suggestions[] = [
                    'suggestion' => $with_country,
                    'description' => "Added {$country_code} country code"
                ];
            }
        }
        
        return $suggestions;
    }
}