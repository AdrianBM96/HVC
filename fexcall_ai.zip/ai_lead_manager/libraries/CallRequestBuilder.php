<?php

namespace modules\ai_lead_manager\libraries;

/**
 * Universal Call Request Builder for both Vapi AI and Bland AI
 * Provides a unified interface for creating call request configurations
 */
class CallRequestBuilder
{
    private $provider;
    private $config = [];
    private $leadData = [];
    private $companyInfo = [];

    public function __construct(string $provider)
    {
        $this->provider = $provider;
        $this->loadCompanyInfo();
        $this->reset();
    }

    /**
     * Factory method to create builder for specific provider
     */
    public static function forProvider(string $provider): self
    {
        return new self($provider);
    }

    /**
     * Reset builder to default state
     */
    public function reset(): self
    {
        $this->config = [];
        $this->leadData = [];
        
        // Set provider-specific defaults
        switch ($this->provider) {
            case 'vapi_ai':
                $this->setVapiDefaults();
                break;
            case 'bland_ai':
                $this->setBlandDefaults();
                break;
        }
        
        return $this;
    }

    /**
     * Set Vapi AI defaults
     */
    private function setVapiDefaults(): void
    {
        $this->config = [
            'phoneNumberId' => get_option('vapi_ai_phone_number_id'),
            'customer' => [
                'number' => '',
            ],
            'assistant' => []
        ];
    }

    /**
     * Set Bland AI defaults
     */
    private function setBlandDefaults(): void
    {
        $this->config = [
            'phone_number' => '',
            'task' => '',
            'voice' => get_option('bland_ai_agent_voice'),
            'reduce_latency' => false,
            'max_duration' => 12,
            'answered_by_enabled' => false,
            'record' => true,
            'amd' => true,
            'interruption_threshold' => 100,
            'voicemail_message' => '',
            'temperature' => 0.5,
            'pronunciation_guide' => [],
            'start_time' => null,
            'request_data' => [],
            'tools' => [],
            'webhook' => admin_url('ai_lead_manager/webhooks/bland_ai'),
            'analysis_schema' => []
        ];
    }

    /**
     * Load company information for placeholders
     */
    private function loadCompanyInfo(): void
    {
        $this->companyInfo = [
            'company_name' => get_option('invoice_company_name'),
            'address' => get_option('invoice_company_address'),
            'city' => get_option('invoice_company_city'),
            'state' => get_option('invoice_company_state'),
            'zip' => get_option('invoice_company_zip'),
            'country' => get_option('invoice_company_country')
        ];
    }

    /**
     * Set phone number for the call
     */
    public function setPhoneNumber(string $phoneNumber): self
    {
        switch ($this->provider) {
            case 'vapi_ai':
                $this->config['customer']['number'] = $phoneNumber;
                break;
            case 'bland_ai':
                $this->config['phone_number'] = $phoneNumber;
                break;
        }
        
        return $this;
    }

    /**
     * Set request data (lead information)
     */
    public function setRequestData(array $requestData): self
    {
        $this->leadData = $requestData;
        
        // Set customer information for both providers
        switch ($this->provider) {
            case 'vapi_ai':
                if (!isset($this->config['customer'])) {
                    $this->config['customer'] = [];
                }
                // Vapi uses customer object
                break;
            case 'bland_ai':
                // Bland AI uses request_data
                $this->config['request_data'] = $requestData;
                break;
        }
        
        return $this;
    }

    /**
     * Set customer/lead data
     */
    public function setCustomer(array $leadData): self
    {
        $this->leadData = $leadData;
        
        switch ($this->provider) {
            case 'vapi_ai':
                // Format phone number for E.164 format if needed
                $phoneNumber = $leadData['phonenumber'] ?? '';
                $this->config['customer']['number'] = $this->formatPhoneNumber($phoneNumber);
                break;
            case 'bland_ai':
                $this->config['phone_number'] = $leadData['phonenumber'] ?? '';
                $this->config['request_data'] = $this->buildRequestData($leadData);
                break;
        }
        
        return $this;
    }
    
    /**
     * Format phone number to E.164 format
     */
    private function formatPhoneNumber(string $phoneNumber): string
    {
        // Remove all non-numeric characters
        $cleaned = preg_replace('/[^0-9]/', '', $phoneNumber);
        
        // If it doesn't start with +, add country code
        if (!str_starts_with($phoneNumber, '+')) {
            // If it's 10 digits, assume US (+1)
            if (strlen($cleaned) === 10) {
                return '+1' . $cleaned;
            }
            // If it's 11 digits and starts with 1, it's already US format
            if (strlen($cleaned) === 11 && str_starts_with($cleaned, '1')) {
                return '+' . $cleaned;
            }
            // For other lengths, assume US if less than 12 digits
            if (strlen($cleaned) < 12) {
                return '+1' . $cleaned;
            }
        }
        
        return $phoneNumber;
    }

    /**
     * Build request data for Bland AI personalization
     */
    private function buildRequestData(array $leadData): array
    {
        return [
            'customer_name' => $leadData['name'] ?? 'there',
            'customer_phone' => $leadData['phonenumber'] ?? '',
            'customer_email' => $leadData['email'] ?? '',
            'customer_address' => $leadData['address'] ?? '',
            'customer_city' => $leadData['city'] ?? '',
            'customer_state' => $leadData['state'] ?? '',
            'customer_country' => $leadData['country'] ?? '',
            'lead_source' => $leadData['source'] ?? '',
            'lead_value' => $leadData['lead_value'] ?? '',
            'company_name' => $this->companyInfo['company_name'],
            'company_address' => $this->companyInfo['address'],
            'company_city' => $this->companyInfo['city']
        ];
    }

    /**
     * Set voice configuration
     */
    public function setVoiceSettings(array $voiceConfig): self
    {
        switch ($this->provider) {
            case 'vapi_ai':
                if (isset($voiceConfig['provider'])) {
                    $this->config['assistant']['voice'] = $voiceConfig;
                }
                break;
            case 'bland_ai':
                if (isset($voiceConfig['voice_id'])) {
                    $this->config['voice'] = $voiceConfig['voice_id'];
                }
                break;
        }
        
        return $this;
    }

    /**
     * Set model configuration
     */
    public function setModelConfiguration(array $modelConfig): self
    {
        switch ($this->provider) {
            case 'vapi_ai':
                // Ensure we have proper structure for Vapi AI model config
                if (!isset($this->config['assistant']['model'])) {
                    $this->config['assistant']['model'] = [];
                }
                
                // Only set valid Vapi model properties
                $validProperties = ['provider', 'model', 'temperature', 'maxTokens', 'messages'];
                foreach ($modelConfig as $key => $value) {
                    if (in_array($key, $validProperties)) {
                        $this->config['assistant']['model'][$key] = $value;
                    }
                }
                break;
            case 'bland_ai':
                if (isset($modelConfig['temperature'])) {
                    $this->config['temperature'] = $modelConfig['temperature'];
                }
                if (isset($modelConfig['max_duration'])) {
                    $this->config['max_duration'] = $modelConfig['max_duration'];
                }
                break;
        }
        
        return $this;
    }

    /**
     * Add tools to the call
     */
    public function addTools(array $toolIds): self
    {
        switch ($this->provider) {
            case 'vapi_ai':
                $this->config['assistant']['model']['toolIds'] = $toolIds;
                break;
            case 'bland_ai':
                $this->config['tools'] = $toolIds;
                break;
        }
        
        return $this;
    }

    public function addToolIds(array $toolIds): self
    {
        switch ($this->provider) {
            case 'vapi_ai':
                foreach($toolIds as $toolId) {
                    $this->config['assistant']['model']['toolIds'][] = $toolId;
                }
                break;
            case 'bland_ai':
                $this->config['tools'] = $toolIds;
                break;
        }
        
        return $this;
    }

    /**
     * Add knowledge bases
     */
    public function addKnowledgeBases(array $kbIds): self
    {
        switch ($this->provider) {
            case 'vapi_ai':
                $this->config['assistant']['model']['knowledgeBase'] = [
                    'topK' => 2,
                    'fileIds' => $kbIds,
                    'provider' => 'canonical'
                ];
                break;
            case 'bland_ai':
                // Bland AI handles knowledge base through tools
                $this->config['tools'] = array_merge($this->config['tools'], $kbIds);
                break;
        }
        
        return $this;
    }

    /**
     * Set webhook URL
     */
    public function setWebhookUrl(string $url): self
    {
        switch ($this->provider) {
            case 'vapi_ai':
                // For localhost development, skip webhook URL to avoid errors
                // In production, ensure the URL is accessible from external services
                if (strpos($url, 'localhost') !== false || strpos($url, '127.0.0.1') !== false) {
                    // Skip webhook for localhost - calls will still work but won't send webhook events
                    log_message('warning', 'Skipping Vapi AI webhook URL for localhost development: ' . $url);
                } else {
                    // Ensure HTTPS for production webhooks
                    $url = str_replace('http://', 'https://', $url);
                    $this->config['assistant']['serverUrl'] = $url;
                }
                break;
            case 'bland_ai':
                $this->config['webhook'] = $url;
                break;
        }
        
        return $this;
    }

    /**
     * Set call task/prompt
     */
    public function setTask(string $task): self
    {
        switch ($this->provider) {
            case 'vapi_ai':
                $this->config['assistant']['firstMessage'] = $task;
                break;
            case 'bland_ai':
                $this->config['task'] = $this->replacePlaceholders($task);
                break;
        }
        
        return $this;
    }

    /**
     * Set analysis schema
     */
    public function setAnalysisSchema(array $schema): self
    {
        switch ($this->provider) {
            case 'vapi_ai':
                // Vapi AI expects a proper JSON schema format
                $this->config['assistant']['analysisPlan']['structuredDataSchema'] = [
                    'type' => 'object',
                    'properties' => $this->convertToJsonSchemaProperties($schema),
                    'required' => []
                ];
                break;
            case 'bland_ai':
                $this->config['analysis_schema'] = $schema;
                break;
        }
        
        return $this;
    }
    
    /**
     * Convert simple schema to JSON Schema properties format
     */
    private function convertToJsonSchemaProperties(array $schema): array
    {
        $properties = [];
        foreach ($schema as $key => $type) {
            $properties[strtolower(str_replace(' ', '_', $key))] = [
                'type' => $this->mapToJsonSchemaType($type),
                'description' => $key
            ];
        }
        return $properties;
    }
    
    /**
     * Map simple types to JSON Schema types
     */
    private function mapToJsonSchemaType(string $type): string
    {
        $typeMap = [
            'string' => 'string',
            'integer' => 'integer', 
            'int' => 'integer',
            'boolean' => 'boolean',
            'bool' => 'boolean',
            'number' => 'number',
            'float' => 'number',
            'array' => 'array',
            'object' => 'object'
        ];
        
        return $typeMap[strtolower($type)] ?? 'string';
    }

    /**
     * Set call priority
     */
    public function setPriority(string $priority): self
    {
        switch ($this->provider) {
            case 'vapi_ai':
                $this->config['metadata']['priority'] = $priority;
                break;
            case 'bland_ai':
                $this->config['priority'] = $priority;
                break;
        }
        
        return $this;
    }

    /**
     * Set call type (inbound/outbound)
     */
    public function setCallType(string $type): self
    {
        // Note: Vapi AI doesn't use call_type property, it's determined by the call creation method
        if ($this->provider === 'bland_ai') {
            $this->config['call_type'] = $type;
        }
        
        // Apply type-specific configurations
        if ($type === 'outbound') {
            $this->configureForOutbound();
        } else {
            $this->configureForInbound();
        }
        
        return $this;
    }

    /**
     * Configure for outbound calls
     */
    private function configureForOutbound(): void
    {
        switch ($this->provider) {
            case 'vapi_ai':
                // Outbound-specific Vapi settings
                break;
            case 'bland_ai':
                $this->config['answered_by_enabled'] = true;
                $this->config['amd'] = true;
                break;
        }
    }

    /**
     * Configure for inbound calls
     */
    private function configureForInbound(): void
    {
        switch ($this->provider) {
            case 'vapi_ai':
                // Inbound-specific Vapi settings
                break;
            case 'bland_ai':
                $this->config['answered_by_enabled'] = false;
                $this->config['amd'] = false;
                break;
        }
    }

    /**
     * Set call metadata
     */
    public function setMetadata(array $metadata): self
    {
        if (!isset($this->config['metadata'])) {
            $this->config['metadata'] = [];
        }
        
        $this->config['metadata'] = array_merge($this->config['metadata'], $metadata);
        return $this;
    }

    /**
     * Add call tags
     */
    public function addTags(array $tags): self
    {
        // Vapi AI doesn't support tags at call level, store in metadata instead
        if ($this->provider === 'vapi_ai') {
            if (!isset($this->config['metadata'])) {
                $this->config['metadata'] = [];
            }
            $this->config['metadata']['tags'] = $tags;
        } else {
            if (!isset($this->config['tags'])) {
                $this->config['tags'] = [];
            }
            $this->config['tags'] = array_merge($this->config['tags'], $tags);
        }
        return $this;
    }

    /**
     * Set scheduled call time
     */
    public function scheduleFor(\DateTime $dateTime, string $timezone = 'UTC'): self
    {
        switch ($this->provider) {
            case 'vapi_ai':
                // Vapi doesn't support scheduled calls directly
                $this->config['metadata']['scheduled_for'] = $dateTime->format('Y-m-d H:i:s');
                break;
            case 'bland_ai':
                $this->config['start_time'] = $dateTime->format('Y-m-d H:i:s');
                $this->config['timezone'] = $timezone;
                break;
        }
        
        return $this;
    }

    /**
     * Enable/disable call recording
     */
    public function setRecording(bool $enabled): self
    {
        switch ($this->provider) {
            case 'vapi_ai':
                // Vapi recording is usually enabled at assistant level
                $this->config['metadata']['recording_enabled'] = $enabled;
                break;
            case 'bland_ai':
                $this->config['record'] = $enabled;
                break;
        }
        
        return $this;
    }

    /**
     * Set maximum call duration
     */
    public function setMaxDuration(int $minutes): self
    {
        switch ($this->provider) {
            case 'vapi_ai':
                $this->config['assistant']['maxDurationSeconds'] = $minutes * 60;
                break;
            case 'bland_ai':
                $this->config['max_duration'] = $minutes;
                break;
        }
        
        return $this;
    }

    /**
     * Replace placeholders in text
     */
    private function replacePlaceholders(string $text): string
    {
        $placeholders = array_merge($this->companyInfo, $this->leadData);
        
        foreach ($placeholders as $key => $value) {
            $text = str_replace('{' . $key . '}', (string)$value, $text);
        }
        
        return $text;
    }

    /**
     * Configure for lead generation calls
     */
    public function configureForLeadGeneration(): self
    {
        return $this->setCallType('outbound')
                    ->setMaxDuration(12)
                    ->setRecording(true)
                    ->addTags(['lead_generation'])
                    ->setAnalysisSchema([
                        'Name' => 'string',
                        'Email' => 'string', 
                        'Phone' => 'string',
                        'Address' => 'string',
                        'City' => 'string',
                        'State' => 'string',
                        'Country' => 'string',
                        'Zip Code' => 'string',
                        'Description' => 'string',
                        'Interest Level' => 'string'
                    ]);
    }

    /**
     * Configure for customer support calls
     */
    public function configureForSupport(): self
    {
        return $this->setCallType('inbound')
                    ->setMaxDuration(20)
                    ->setRecording(true)
                    ->addTags(['customer_support'])
                    ->setAnalysisSchema([
                        'Issue Category' => 'string',
                        'Issue Description' => 'string',
                        'Resolution Provided' => 'boolean',
                        'Customer Satisfaction' => 'integer',
                        'Follow-up Required' => 'boolean'
                    ]);
    }

    /**
     * Configure for sales calls
     */
    public function configureForSales(): self
    {
        return $this->setCallType('outbound')
                    ->setMaxDuration(15)
                    ->setRecording(true)
                    ->addTags(['sales'])
                    ->setPriority('high')
                    ->setAnalysisSchema([
                        'Interest Level' => 'string',
                        'Budget Range' => 'string',
                        'Decision Maker' => 'boolean',
                        'Next Steps' => 'string',
                        'Competitor Mentioned' => 'string'
                    ]);
    }

    /**
     * Set custom task for manual calls
     */
    public function setCustomTask(string $customTask): self
    {
        switch ($this->provider) {
            case 'vapi_ai':
                // For Vapi, append to the existing system prompt
                if (isset($this->config['assistant']['model']['messages'])) {
                    foreach ($this->config['assistant']['model']['messages'] as &$message) {
                        if ($message['role'] === 'system') {
                            $message['content'] .= "\n\nAdditional Task: " . $customTask;
                            break;
                        }
                    }
                } else {
                    $this->config['assistant']['model']['messages'][] = [
                        'role' => 'system',
                        'content' => 'Additional Task: ' . $customTask
                    ];
                }
                break;
            case 'bland_ai':
                // For Bland AI, append to the task
                if (isset($this->config['task'])) {
                    $this->config['task'] .= "\n\nAdditional Task: " . $customTask;
                } else {
                    $this->config['task'] = $customTask;
                }
                break;
        }
        
        return $this;
    }

    /**
     * Validate configuration before building
     */
    private function validate(): bool
    {
        switch ($this->provider) {
            case 'vapi_ai':
                return !empty($this->config['assistant']) && 
                       !empty($this->config['customer']['number']);
            case 'bland_ai':
                return !empty($this->config['phone_number']) && 
                       !empty($this->config['task']);
        }
        
        return false;
    }

    /**
     * Build and return the call request configuration
     */
    public function build(): array
    {
        if (!$this->validate()) {
            throw new \InvalidArgumentException("Invalid configuration for {$this->provider}");
        }
        
        // Apply final transformations
        if ($this->provider === 'bland_ai' && isset($this->config['task'])) {
            $this->config['task'] = $this->replacePlaceholders($this->config['task']);
        }
        
        return $this->config;
    }

    /**
     * Build for immediate call (no scheduling)
     */
    public function buildImmediate(): array
    {
        unset($this->config['start_time']);
        unset($this->config['timezone']);
        return $this->build();
    }

    /**
     * Build for batch processing
     */
    public function buildForBatch(string $batchId): array
    {
        $this->config['batch_id'] = $batchId;
        return $this->build();
    }
}