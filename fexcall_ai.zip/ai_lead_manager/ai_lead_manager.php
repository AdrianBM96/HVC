<?php

/**
 * Ensures that the module init file can't be accessed directly, only within the application.
 */

defined('BASEPATH') or exit('No direct script access allowed');

/*
Module Name: FexCall AI
Description: Automate lead generation and follow-ups with Vapi.ai and Bland.ai integration.
Author: My Perfex CRM
Author URI: https://myperfexcrm.com
Version: 1.5.0
Requires at least: 2.3.*
*/

define('AI_LEAD_MANAGER_MODULE_NAME', 'ai_lead_manager');

/**
 * Load the module helper
 */
get_instance()->load->helper(AI_LEAD_MANAGER_MODULE_NAME . '/ai_lead_manager');

/**
 * Register language files, must be registered if the module is using languages
 */
register_language_files(AI_LEAD_MANAGER_MODULE_NAME, [AI_LEAD_MANAGER_MODULE_NAME]);

hooks()->add_filter('module_ai_lead_manager_action_links', 'ai_lead_manager_action_links');
hooks()->add_action('admin_init', 'ai_lead_manager_module_init_menu_items');
hooks()->add_action('mobile_app_init', 'ai_lead_manager_module_init_menu_items');
hooks()->add_action('admin_init', 'ai_lead_manager_app_admin_assets_added');
hooks()->add_filter('before_settings_updated', "ai_lead_manager_before_setting_updated");
hooks()->add_action('after_lead_lead_tabs', 'ai_lead_manager_after_lead_lead_tabs');
hooks()->add_action('after_lead_tabs_content', 'ai_lead_manager_after_lead_tabs_content');
hooks()->add_action('app_admin_footer', 'ai_lead_manager_app_admin_footer');
hooks()->add_action('before_cron_run', 'ai_lead_manager_cronjob');

function ai_lead_manager_action_links(array $actions): array
{
    $actions[] = '<a href="' . admin_url('settings?group=ai_lead_manager') . '">' . _l('settings') . '</a>';
    return $actions;
}
/**
 * Registers permissions for FexCall AI.
 *
 * This function defines the capabilities related to call logs, including
 * view, create, edit, and delete permissions. It then registers these
 * capabilities using the 'register_staff_capabilities' function, if it
 * exists.
 */
function ai_lead_manager_call_logs_permissions()
{
    $capabilities = [];

    $capabilities['capabilities'] = [
        'view'   => _l('permission_view') . '(' . _l('permission_global') . ')',
        'create' => _l('permission_create'),
        'edit'   => _l('permission_edit'),
        'delete' => _l('permission_delete'),
    ];

    if (function_exists('register_staff_capabilities')) {
        register_staff_capabilities('alm_call_logs', $capabilities, _l('alm_call_logs'));
    }
}

/**
 * Initializes the menu items for FexCall AI.
 *
 * This function registers two menu items. The first menu item is added to the
 * sidebar menu, and it is visible only if the user has the 'view' permission for
 * call logs. This menu item links to the 'call_logs' page in the 'ai_lead_manager'
 * module.
 *
 * The second menu item is added to the settings page, and it is visible to all
 * users. This menu item links to the 'ai_lead_manager' page in the 'ai_lead_manager'
 * module.
 */
function ai_lead_manager_module_init_menu_items()
{
    $CI = &get_instance();

    if (has_permission('alm_call_logs', '', 'view')) {
        $CI->app_menu->add_sidebar_menu_item('ai-call-logs', [
            'slug'     => 'ai-call-logs',
            'name'     => _l('alm_call_logs'),
            'position' => 5,
            'icon'     => 'fa fa-phone',
            'href'     => admin_url('ai_lead_manager/call_logs')
        ]);

        $CI->app_menu->add_sidebar_menu_item('ai-campaigns', [
            'slug'     => 'ai-campaigns',
            'name'     => _l('alm_campaigns'),
            'position' => 6,
            'icon'     => 'fa fa-bullhorn',
            'href'     => admin_url('ai_lead_manager/campaigns')
        ]);

        if (function_exists('add_mobile_app_menu_item')) {
            add_mobile_app_menu_item('ai_call_logs', [
                'title'      => 'AI Call Logs',
                'routerLink' => 'modules/ai_lead_manager/call-logs',
                'icon'       => 'lead',
                'position'   => 6,
            ]);

            add_mobile_app_menu_item('ai_campaigns', [
                'title'      => 'AI Campaigns',
                'routerLink' => 'modules/ai_lead_manager/campaigns',
                'icon'       => 'bullhorn',
                'position'   => 7,
            ]);
        }
    }

    $CI->app_tabs->add_settings_tab('ai_lead_manager', [
        'icon' => 'fa-solid fa-phone',
        'name' => 'FexCall AI',
        'position' => 100,
        'view' => 'ai_lead_manager/ai_lead_manager',
    ]);
}

/**
 * Adds the necessary JavaScript and CSS files for the FexCall AI
 * module to the page.
 *
 * This function is triggered by the 'app_admin_assets_added' hook. It adds the
 * 'main.js' and 'main.css' files from the module's 'assets' directory to the page.
 *
 * @return void
 */
function ai_lead_manager_app_admin_assets_added()
{
    $CI = &get_instance();
    $CI->app_scripts->add(AI_LEAD_MANAGER_MODULE_NAME . '-main-js', base_url('modules/' . AI_LEAD_MANAGER_MODULE_NAME . '/assets/main.js'));
    $CI->app_scripts->add('vapi-web-sdk', 'https://cdn.jsdelivr.net/gh/VapiAI/html-script-tag@latest/dist/assets/index.js');
    $CI->app_scripts->add(AI_LEAD_MANAGER_MODULE_NAME . '-vapi-call-js', base_url('modules/' . AI_LEAD_MANAGER_MODULE_NAME . '/assets/js/vapi-call.js'), 'admin', ['vapi-web-sdk']);
    $CI->app_css->add(AI_LEAD_MANAGER_MODULE_NAME . '-main-css', base_url('modules/' . AI_LEAD_MANAGER_MODULE_NAME . '/assets/main.css'));
}

/**
 * Modifies the settings data before saving it based on the selected voice assistant.
 *
 * This function is triggered by the 'before_settings_updated' hook. It checks the
 * selected voice assistant and calls the corresponding function to modify the
 * settings data before saving it. If the selected voice assistant is 'vapi_ai', it
 * calls the 'before_setting_update_vapi_ai' function. If the selected voice
 * assistant is 'bland_ai', it calls the 'before_setting_update_bland_ai'
 * function.
 *
 * @param array $data An associative array containing the settings data to be
 *                    saved.
 * @return array The modified settings data.
 */
function ai_lead_manager_before_setting_updated($data)
{
    if (isset($data['settings']['alm_voice_assistant'])) {
        $data['settings']['vapi_ai_tools_inbound'] = json_encode(($data['settings']['vapi_ai_tools_inbound'] ?? []));
        $data['settings']['vapi_ai_tools_outbound'] = json_encode(($data['settings']['vapi_ai_tools_outbound'] ?? []));

        $data['settings']['vapi_ai_knowledgebase_inbound'] = json_encode(($data['settings']['vapi_ai_knowledgebase_inbound'] ?? []));
        $data['settings']['vapi_ai_knowledgebase_outbound'] = json_encode(($data['settings']['vapi_ai_knowledgebase_outbound'] ?? []));

        $data['settings']['bland_ai_knowledgebase_inbound'] = json_encode(($data['settings']['bland_ai_knowledgebase_inbound'] ?? []));
        $data['settings']['bland_ai_knowledgebase_outbound'] = json_encode(($data['settings']['bland_ai_knowledgebase_outbound'] ?? []));

        $alm_voice_assistant = $data['settings']['alm_voice_assistant'];

        if ($alm_voice_assistant == 'vapi_ai') {
            return before_setting_update_vapi_ai($data);
        } else if ($alm_voice_assistant == 'bland_ai') {
            return before_setting_update_bland_ai($data);
        }
    }

    return $data;
}

/**
 * Modifies the settings data before saving it based on the selected voice assistant.
 *
 * This function is triggered by the 'before_settings_updated' hook when the
 * selected voice assistant is 'bland_ai'. It checks if the Bland AI API key has
 * changed and, if so, updates the API key and creates a new encrypted key. It
 * also updates the list of inbound numbers and sets the call settings.
 *
 * @param array $data An associative array containing the settings data to be
 *                    saved.
 * @return array The modified settings data.
 */
function before_setting_update_bland_ai($data)
{
    $CI = &get_instance();

    // Only proceed if we have a Bland.ai API key
    if (empty($data["settings"]["bland_ai_api_key"])) {
        return $data;
    }

    $current_api_key = get_option('bland_ai_api_key');
    $new_api_key = $data["settings"]["bland_ai_api_key"];

    // Update API key if changed
    if (empty($current_api_key) || $new_api_key != $current_api_key) {
        update_option('bland_ai_api_key', $new_api_key);
        log_message('info', 'Bland.ai API key updated');
    }

    // Initialize Bland.ai library
    $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Bland_ai');
    $bland_ai = new Bland_ai();
    $bland_ai->set_auth_token($new_api_key);

    // Handle phone number selection and encrypted key auto-detection
    if (!empty($data["settings"]["bland_ai_selected_phone_number_id"])) {
        $selected_phone_number = $data["settings"]["bland_ai_selected_phone_number_id"];

        // Auto-detect and set encrypted key for BYOT numbers
        $auto_detection_result = alm_bland_ai_auto_set_encrypted_key($selected_phone_number);

        if ($auto_detection_result) {
            log_message('info', 'Auto-detected encrypted key for BYOT number: ' . $selected_phone_number);
            set_alert('success', 'BYOT encrypted key automatically configured for ' . $selected_phone_number);
        }
    }

    // Configure assistant settings only if we have essential data
    if (!empty($data["settings"]["bland_ai_agent_voice"]) &&
        !empty($data["settings"]["alm_system_prompt"]) &&
        !empty($data["settings"]["alm_first_sentence"])) {

        try {
            // Load the BlandAiCallBuilder for assistant configuration
            require_once FCPATH . 'modules/' . AI_LEAD_MANAGER_MODULE_NAME . '/libraries/bland_ai/BlandAiCallBuilder.php';

            // Build call configuration for inbound calls
            $call_builder = \modules\ai_lead_manager\libraries\bland_ai\BlandAiCallBuilder::createLeadGenerationCall()
                ->setModel('enhanced')
                ->setMaxDuration((int) ($data["settings"]["bland_ai_max_duration"] ?: 12))
                ->setFirstSentence($data["settings"]["alm_first_sentence"])
                ->setVoice($data["settings"]["bland_ai_agent_voice"])
                ->setTemperature((float) ($data["settings"]["bland_ai_temperature"] ?: 0.5))
                ->setPrompt($data["settings"]["alm_system_prompt"])
                ->setSummaryPrompt("Provide a complete summary of the call.")
                ->setWaitForGreeting(false)
                ->setWebhook(admin_url('ai_lead_manager/webhooks/bland_ai'))
                ->setWebhookEvents(['call', 'webhook'])
                ->setRecording(true);

            // Add knowledge bases if configured
            $inbound_kb = json_decode($data['settings']['bland_ai_knowledgebase_inbound'] ?? '[]', true);
            if (!empty($inbound_kb)) {
                $call_builder->addKnowledgeBaseTools($inbound_kb);
            }

            // Set encrypted key if available (for BYOT numbers)
            $current_encrypted_key = get_option('bland_ai_encrypted_key');
            if (!empty($current_encrypted_key)) {
                $call_builder->setEncryptedKey($current_encrypted_key);
            }

            // Replace company placeholders and build configuration
            $call_settings = $call_builder
                ->replaceCompanyPlaceholders()
                ->build();

            // Apply configuration to the selected phone number if it's a BYOT number
            $selected_phone_number = $data["settings"]["bland_ai_selected_phone_number_id"] ?? '';
            if (!empty($selected_phone_number)) {
                $response = $bland_ai->update_inbound_details($selected_phone_number, $call_settings);

                if (isset($response['error'])) {
                    set_alert('warning', 'Failed to update phone number configuration: ' . ($response['message'] ?? 'Unknown error'));
                } else {
                    log_message('info', 'Successfully updated Bland.ai inbound configuration for: ' . $selected_phone_number);
                }
            }

        } catch (Exception $e) {
            log_message('error', 'Bland.ai configuration update failed: ' . $e->getMessage());
            set_alert('warning', 'Assistant configuration could not be updated: ' . $e->getMessage());
        }
    }

    return $data;
}

function before_setting_update_vapi_ai($data)
{
    $CI = &get_instance();

    $vapi_ai_api_key = get_option('vapi_ai_api_key');
    $vapi_ai_assistant_id = get_option('vapi_ai_assistant_id');

    // Check if we have the required VAPI API key and a selected phone number
    $has_valid_phone_config = !empty($data["settings"]["vapi_ai_selected_phone_number_id"]);

    if (!empty($data["settings"]["vapi_ai_api_key"]) && $has_valid_phone_config) {
        if (empty($vapi_ai_api_key) || $data["settings"]["vapi_ai_api_key"] != $vapi_ai_api_key) {
            update_option('vapi_ai_api_key', $data["settings"]["vapi_ai_api_key"]);
        }

        $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Vapi_ai');
        $vapi_ai = new Vapi_ai();

        if (!empty($data["settings"]["vapi_ai_agent_voice"]) && $data["settings"]["alm_first_sentence"] != "" && $data["settings"]["alm_system_prompt"] != "") {
            $first_sentence = $data["settings"]["alm_first_sentence"];
            $first_sentence = str_replace('{company_name}', get_option('invoice_company_name'), $first_sentence);
            $first_sentence = str_replace('{address}', get_option('invoice_company_address'), $first_sentence);
            $first_sentence = str_replace('{city}', get_option('invoice_company_city'), $first_sentence);
            $first_sentence = str_replace('{state}', get_option('invoice_company_state'), $first_sentence);
            $first_sentence = str_replace('{zip}', get_option('invoice_company_zip'), $first_sentence);
            $first_sentence = str_replace('{country}', get_option('invoice_company_country'), $first_sentence);


            // Load the VapiAssistantBuilder
            require_once FCPATH . 'modules/' . AI_LEAD_MANAGER_MODULE_NAME . '/libraries/vapi_ai/VapiAssistantBuilder.php';
            $builder = new \modules\ai_lead_manager\libraries\vapi_ai\VapiAssistantBuilder();

            // Build comprehensive assistant configuration using the enhanced builder pattern
            $assistant_builder = $builder
                ->setName('FexCall Inbound Assistant')
                ->setFirstMessage($first_sentence)
                ->setTranscriber('deepgram', 'nova-2', 'en-US')
                ->setVoice(
                    $data['settings']['vapi_ai_voice_provider'],
                    ($data['settings']['vapi_ai_is_custom_voice_id'] == 1
                        ? $data['settings']['vapi_ai_agent_voice_id']
                        : $data['settings']['vapi_ai_agent_voice'])
                )
                ->setModel('openai', 'gpt-4o', (float) $data['settings']['vapi_ai_temperature'], (int) $data['settings']['vapi_ai_max_tokens'])
                ->setSystemPrompt($data["settings"]["alm_system_prompt"] . '\n\n DateTime Now: ' . date('Y-m-d H:i:s'))
                ->setEmotionRecognition($data['settings']['vapi_ai_detect_emotions'] == 1)
                ->setFillerInjection($data['settings']['filler_injection_enabled'] == 1)
                ->setBackChannelingEnabled($data['settings']['back_channeling_enabled'] == 1)
                ->setMaxDuration((int) (get_option('vapi_ai_max_duration') != 0 ? get_option('vapi_ai_max_duration') : 300))
                ->setEndCallFunctionEnabled($data['settings']['end_call_function_enabled'] == 1)
                ->setDialKeypadFunctionEnabled($data['settings']['dial_keypad_function_enabled'] == 1)
                ->setLeadGenerationSchema()
                ->setServerUrl(admin_url('ai_lead_manager/webhooks/vapi_ai_inbound'))
                ->setServerMessages(['end-of-call-report'])
                ->enableSmartEndpointing()
                ->configureStopSpeaking(2, 0.2, 1)
                ->setDefaultEndCallPhrases()
                ->replaceCompanyPlaceholders()
                ->configureForInbound();

            // Add tools if configured
            if (!empty($data['settings']['vapi_ai_tools_inbound'])) {
                $tools = array_filter(json_decode($data['settings']['vapi_ai_tools_inbound'], true));
                if ($tools) {
                    $assistant_builder->addToolIds($tools);
                }
            }

            // Add knowledge bases if configured - need to use the new flow based on MCP research
            if (!empty($data['settings']['vapi_ai_knowledgebase_inbound'])) {
                $kbIds = array_filter(json_decode($data['settings']['vapi_ai_knowledgebase_inbound'], true));
                if ($kbIds) {
                    $assistant_builder->addToolIds($kbIds);
                }
            }

            // Manage call forwarding tool based on settings
            $forwarding_enabled = !empty($data["settings"]["vapi_ai_enable_call_forwarding"]);
            $forwarding_number = $data["settings"]["vapi_ai_forwarding_number"] ?? '';
            $forwarding_message = $data["settings"]["vapi_ai_forwarding_message"] ?? '';

            $transfer_tool_response = alm_vapi_ai_manage_forwarding_tool(
                $forwarding_number,
                $forwarding_message,
                $forwarding_enabled
            );

            if ($transfer_tool_response) {
                $action = $transfer_tool_response['action'] ?? 'unknown';
                $tool_id = $transfer_tool_response['id'] ?? 'unknown';
                log_message('info', "VAPI Transfer Tool {$action}: {$tool_id}");
            }

            // Add transfer tool to assistant only if forwarding is enabled and tool exists
            if ($forwarding_enabled) {
                $existing_transfer_tool_id = get_option('vapi_ai_transfer_tool_id');
                if (!empty($existing_transfer_tool_id)) {
                    $assistant_builder->addToolIds([$existing_transfer_tool_id]);
                }
            }

            $assistant_settings = $assistant_builder->build();

            if (empty($vapi_ai_assistant_id)) {
                $response = $vapi_ai->create_assistant($assistant_settings);
                if (isset($response['id'])) {
                    update_option('vapi_ai_assistant_id', $response['id']);
                }
            } else {
                $response = $vapi_ai->get_assistant_by_id($vapi_ai_assistant_id);
                if (isset($response['id'])) {
                    $response = $vapi_ai->update_assistant($vapi_ai_assistant_id, $assistant_settings);
                } else {
                    $response = $vapi_ai->create_assistant($assistant_settings);
                    if (isset($response['id'])) {
                        update_option('vapi_ai_assistant_id', $response['id']);
                    }
                }
            }

            if (isset($response['id'])) {
                $assistant_id = $response['id'];

                // Assign selected phone number to assistant
                if (!empty($data["settings"]["vapi_ai_selected_phone_number_id"])) {
                    $selected_phone_id = $data["settings"]["vapi_ai_selected_phone_number_id"];

                    // Update the phone number to assign it to this assistant
                    $update_response = $vapi_ai->update_phone_number($selected_phone_id, [
                        'assistantId' => $assistant_id
                    ]);

                    if (isset($update_response['id']) || !isset($update_response['error'])) {
                        // Store the selected phone number ID as the active one
                        update_option('vapi_ai_phone_number_id', $selected_phone_id);
                        log_message('info', 'VAPI Phone Number Assigned to Assistant: ' . $assistant_id . ' -> Phone ID: ' . $selected_phone_id);
                    } else {
                        log_message('error', 'Failed to assign phone number to assistant: ' . json_encode($update_response));
                    }
                }
            } else {
                if (isset($response['response']['message'][0])) {
                    set_alert('danger', $response['response']['message'][0]);
                } else {
                    set_alert('danger', $response['response']['message']);
                }
            }
        }
    }

    return $data;
}

/**
 * Adds a new tab to the lead view containing call logs related to the lead.
 *
 * This function is triggered by the 'after_lead_lead_tabs' hook and adds a new
 * tab to the lead view, which contains a data table with call logs related to
 * the lead. The data table is initialized using the 'initDataTable' function and
 * retrieves data from the 'call_log_relations' function in the 'ai_lead_manager'
 * controller.
 *
 * @param object $lead A lead object containing information about the lead.
 */
function ai_lead_manager_after_lead_lead_tabs($lead)
{
    if ($lead) {
        echo '<li role="presentation">
            <a 
                href="#tab_ai_call_logs_leads" 
                onclick="initDataTable(\'.table-alm_call_logs-lead\', admin_url + \'ai_lead_manager/call_logs/call_log_relations/\' + ' . $lead->id . ' + \'/lead\',\'undefined\', \'undefined\',\'undefined\',[6,\'desc\']);" 
                aria-controls="tab_ai_call_logs_leads" 
                role="tab" 
                data-toggle="tab"
            >' . _l('alm_call_logs') . '
            </a>
        </li>';
    }
}


/**
 * Adds content to the lead view tab containing call logs related to the lead.
 *
 * This function is triggered by the 'after_lead_tabs_content' hook and adds
 * content to the lead view tab, which contains a data table with call logs
 * related to the lead. The data table is initialized using the 'initDataTable'
 * function and retrieves data from the 'call_log_relations' function in the
 * 'call_logs' controller.
 *
 * @param object $lead A lead object containing information about the lead.
 */
function ai_lead_manager_after_lead_tabs_content($lead)
{
    if ($lead) {
        $CI = &get_instance();
        $data = ['lead' => $lead];
        $CI->load->view(AI_LEAD_MANAGER_MODULE_NAME . '/lead/call_logs_tab_content', $data);
    }
}

/**
 * Register activation module hook
 */
register_activation_hook(AI_LEAD_MANAGER_MODULE_NAME, 'ai_lead_manager_module_activation_hook');
function ai_lead_manager_module_activation_hook()
{
    $CI = &get_instance();
    require_once(__DIR__ . '/install.php');
}

/**
 * Adds an empty div to the admin footer with the id "alm_call_log_div".
 * This div is used by the 'init_alm_call_log_modal' function to display a
 * modal with call log details when a link is clicked.
 */
function ai_lead_manager_app_admin_footer()
{
    echo '<div id="alm_call_log_div"></div>';

    // Add Make Call Modal
    echo '<div class="modal fade" id="make_call_modal" tabindex="-1" role="dialog" aria-labelledby="makeCallModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h4 class="modal-title" id="makeCallModalLabel">Make AI Call</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="custom_task">Additional Task Instructions (Optional)</label>
                        <textarea class="form-control" id="custom_task" name="custom_task" rows="4" 
                                  placeholder="Enter any specific instructions or tasks you want the AI to focus on during this call..."></textarea>
                        <small class="text-muted">These instructions will be added to the primary prompt and guide the AI during the call.</small>
                    </div>
                    <div id="call_status" class="alert" style="display: none;"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="confirm_make_call">
                        <i class="fa fa-phone"></i> Make Call
                    </button>
                </div>
            </div>
        </div>
    </div>';

    // File Upload Modal
    echo '<div class="modal fade" id="file_upload_modal" tabindex="-1" role="dialog" aria-labelledby="fileUploadModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    ' . form_open(admin_url('ai_lead_manager/upload_file/vapi'), ['method' => 'post', 'enctype' => 'multipart/form-data']) . '
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                        <h4 class="modal-title" id="fileUploadModalLabel">Upload File</h4>
                    </div>
                    <div class="modal-body">
                        ' . render_input('file', 'Upload File (PDF, DOC, DOCX, etc.)', '', 'file', ['required' => true, 'accept' => '.pdf,.doc,.docx,.txt,.md,.csv,.json,.xml,.log,.tsv,.yaml,.yml']) . '
                        <small class="text-muted">Supported formats: PDF, DOC, DOCX, TXT, MD, CSV, JSON, XML, LOG, TSV, YAML. Max size: 300KB</small>
                        <p class="text-info"><i class="fa fa-info-circle"></i> Upload files first, then create knowledge bases using these files.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Upload File</button>
                    </div>
                    ' . form_close() . '
                </div>
            </div>
        </div>
    ';

    // Knowledge Base Creation/Edit Modal  
    echo '<div class="modal fade" id="vapi_ai_kwnowledgebase_modal" tabindex="-1" role="dialog" aria-labelledby="knowledgeBaseModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form id="knowledgebase_form" method="post" action="">
                        ' . form_hidden(get_instance()->security->get_csrf_token_name(), get_instance()->security->get_csrf_hash()) . '
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                        <h4 class="modal-title" id="knowledgeBaseModalLabel">Create Knowledge Base</h4>
                    </div>
                    <div class="modal-body">
                        ' . form_hidden('kb_id', '') . '
                        ' . render_input('kb_name', 'Knowledge Base Name', '', 'text', ['required' => true, 'placeholder' => 'Enter knowledge base name']) . '
                        ' . render_textarea('kb_description', 'Description', '', ['placeholder' => 'Describe what this knowledge base contains and when it should be used']) . '
                        <div class="form-group">
                            <label for="selected_files">Select Files</label>
                            <div id="available_files_list" class="well" style="max-height: 200px; overflow-y: auto;">
                                <p class="text-muted">Loading available files...</p>
                            </div>
                        </div>
                        <small class="text-muted">Select the uploaded files to include in this knowledge base.</small>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="kb_submit_btn">Create Knowledge Base</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    ';
    echo '<div class="modal fade" id="bland_ai_kwnowledgebase_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    ' . form_open(admin_url('ai_lead_manager/add_knowledgebase/bland'), ['method' => 'post', 'enctype' => 'multipart/form-data']) . '
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                        <h4 class="modal-title" id="myModalLabel">Add knowledgebase</h4>
                    </div>
                    <div class="modal-body">
                        ' . render_input('name', 'name') . '
                        ' . render_textarea('description', 'description') . '
                        ' . render_input('file', 'file', '', 'file') . '
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Continue</button>
                    </div>
                    ' . form_close() . '
                </div>
            </div>
        </div>
    ';

    // Add Phone Number Creation Modal
    echo '<div class="modal fade" id="create_phone_number_modal" tabindex="-1" role="dialog" aria-labelledby="createPhoneNumberModalLabel">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                ' . form_open(admin_url('ai_lead_manager/create_phone_number/vapi'), ['id' => 'phone_number_form']) . '
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h4 class="modal-title" id="createPhoneNumberModalLabel">Add New Phone Number</h4>
                </div>
                <div class="modal-body">
                    <!-- Phone Number Type Selector -->
                    <div class="form-group">
                        <label>Phone Number Type</label>
                        <div class="radio radio-primary">
                            <input type="radio" name="phone_number_type" id="modal_phone_type_vapi_free" value="vapi_free" checked>
                            <label for="modal_phone_type_vapi_free">
                                <i class="fa fa-gift text-success"></i> <strong>Free VAPI Number</strong> - Get a free US phone number
                            </label>
                        </div>
                        <div class="radio radio-primary">
                            <input type="radio" name="phone_number_type" id="modal_phone_type_vapi_sip" value="vapi_sip">
                            <label for="modal_phone_type_vapi_sip">
                                <i class="fa fa-network-wired text-info"></i> <strong>Free VAPI SIP</strong> - Use SIP integration
                            </label>
                        </div>
                        <div class="radio radio-primary">
                            <input type="radio" name="phone_number_type" id="modal_phone_type_byo_sip" value="byo_sip_trunk">
                            <label for="modal_phone_type_byo_sip">
                                <i class="fa fa-server text-primary"></i> <strong>BYO SIP Trunk Number</strong> - Bring your own SIP trunk
                            </label>
                        </div>
                        <div class="radio radio-primary">
                            <input type="radio" name="phone_number_type" id="modal_phone_type_twilio" value="twilio">
                            <label for="modal_phone_type_twilio">
                                <i class="fa fa-cloud text-warning"></i> <strong>Twilio Integration</strong> - Import Twilio number
                            </label>
                        </div>
                    </div>

                    <!-- Free VAPI Number Section -->
                    <div id="modal_vapi_free_section" class="phone-config-section">
                        <div class="alert alert-info">
                            <i class="fa fa-info-circle"></i> <strong>Free VAPI Numbers:</strong> Limited to 10 free numbers per account and US national use only. You can optionally specify a preferred area code.
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="modal_area_code">Preferred Area Code (Optional)</label>
                                    <input type="text" class="form-control" id="modal_area_code" name="area_code" placeholder="984" maxlength="3" pattern="[0-9]{3}">
                                    <small class="text-muted">Leave empty for automatic assignment. Enter 3-digit US area code (e.g., 984, 212, 415).</small>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Free VAPI SIP Section -->
                    <div id="modal_vapi_sip_section" class="phone-config-section" style="display: none;">
                        <div class="alert alert-info">
                            <i class="fa fa-info-circle"></i> <strong>Free VAPI SIP:</strong> Get a free SIP endpoint from VAPI. Perfect for VoIP integrations and custom telephony solutions.
                        </div>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="modal_sip_identifier">SIP Identifier <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-addon">sip:</span>
                                        <input type="text" class="form-control" id="modal_sip_identifier" name="sip_identifier" placeholder="fexcall-test2" minlength="8" maxlength="50" pattern="[a-zA-Z0-9-_]+">
                                        <span class="input-group-addon">@sip.vapi.ai</span>
                                    </div>
                                    <small class="text-muted">Enter an identifier (minimum 8 characters). Only letters, numbers, hyphens, and underscores allowed.</small>
                                </div>
                            </div>
                        </div>
                        <div class="alert alert-success">
                            <i class="fa fa-magic"></i> <strong>Auto-Generated:</strong> VAPI will create a unique SIP endpoint like <code>sip:your-identifier@sip.vapi.ai</code> that you can use with any SIP-compatible system.
                        </div>
                    </div>

                    <!-- BYO SIP Trunk Section -->
                    <div id="modal_byo_sip_trunk_section" class="phone-config-section" style="display: none;">
                        <div class="alert alert-info">
                            <i class="fa fa-info-circle"></i> <strong>Bring Your Own SIP Trunk:</strong> Use your existing SIP trunk infrastructure with VAPI. Perfect for enterprises with existing telephony systems.
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="modal_byo_number">Phone Number <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="modal_byo_number" name="byo_number" placeholder="+1234567890">
                                    <small class="text-muted">Enter your SIP trunk phone number.</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="modal_byo_label">Label</label>
                                    <input type="text" class="form-control" id="modal_byo_label" name="byo_label" placeholder="Main Office Line">
                                    <small class="text-muted">Descriptive label for this phone number.</small>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="modal_byo_credential">SIP Trunk Credential</label>
                                    <select class="form-control" id="modal_byo_credential" name="byo_credential_id">
                                        <option value="">Select SIP Credential</option>';

    // Get BYO credentials and populate the dropdown
    $byo_credentials = alm_vapi_ai_get_byo_credentials();
    if (!empty($byo_credentials)) {
        foreach ($byo_credentials as $credential) {
            if (isset($credential['id']) && isset($credential['name'])) {
                echo '<option value="' . htmlspecialchars($credential['id']) . '">' . htmlspecialchars($credential['name']) . '</option>';
            }
        }
    } else {
        echo '<option value="" disabled>No BYO credentials found. Create one first.</option>';
    }

    echo '                          </select>
                                    <small class="text-muted">Choose the SIP trunk credential for authentication.</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group" style="padding-top: 25px;">
                                    <div class="checkbox checkbox-primary">
                                        <input type="checkbox" id="modal_byo_allow_non_e164" name="allow_non_e164" value="1">
                                        <label for="modal_byo_allow_non_e164">Allow non-E164 phone numbers</label>
                                    </div>
                                    <small class="text-muted">Check this box to disable E164 format validation and use custom phone number formats.</small>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Twilio Integration Section -->
                    <div id="modal_twilio_section" class="phone-config-section" style="display: none;">
                        <div class="alert alert-warning">
                            <i class="fa fa-warning"></i> <strong>Important:</strong> You need an active Twilio account with a purchased phone number.
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="modal_twilio_account_sid">Account SID</label>
                                    <input type="text" class="form-control" id="modal_twilio_account_sid" name="twilio_account_sid" placeholder="AC...">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="modal_twilio_auth_token">Auth Token</label>
                                    <input type="password" class="form-control" id="modal_twilio_auth_token" name="twilio_auth_token">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="modal_twilio_account_number">Phone Number</label>
                                    <input type="text" class="form-control" id="modal_twilio_account_number" name="twilio_account_number" placeholder="+1234567890">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success" id="create_phone_number_btn">
                        <i class="fa fa-plus"></i> Create Phone Number
                    </button>
                </div>
                ' . form_close() . '
            </div>
        </div>
    </div>';

    // Edit Phone Number Modal
    echo '<div class="modal fade" id="edit_phone_number_modal" tabindex="-1" role="dialog" aria-labelledby="editPhoneNumberModalLabel">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                ' . form_open(admin_url('ai_lead_manager/update_phone_number'), ['id' => 'edit_phone_number_form']) . '
                <input type="hidden" name="phone_id" id="edit_phone_id">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h4 class="modal-title" id="editPhoneNumberModalLabel">Edit Phone Number</h4>
                </div>
                <div class="modal-body">
                    <!-- Phone Number Info -->
                    <div class="alert alert-info" id="edit_phone_info">
                        <i class="fa fa-info-circle"></i> <span id="edit_phone_type_info"></span>
                    </div>

                    <!-- Assistant Assignment -->
                    <div class="form-group">
                        <label for="edit_assistant_id">AI Assistant</label>
                        <select class="form-control selectpicker" name="assistant_id" id="edit_assistant_id" data-live-search="true">
                            <option value="">No Assistant (Manual Operation)</option>';

    // Get available assistants
    $CI = get_instance();
    $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Vapi_ai', null, 'vapi_ai');

    $assistants_response = $CI->vapi_ai->get_assistants();
    if (!isset($assistants_response['error']) && is_array($assistants_response)) {
        foreach ($assistants_response as $assistant) {
            if (isset($assistant['id']) && isset($assistant['name'])) {
                echo '<option value="' . htmlspecialchars($assistant['id']) . '">' . htmlspecialchars($assistant['name']) . '</option>';
            }
        }
    }

    echo '          </select>
                        <small class="text-muted">Assign an AI assistant to handle calls on this phone number automatically.</small>
                    </div>

                    <!-- Phone Number Display (Read-only) -->
                    <div class="form-group">
                        <label>Phone Number / SIP URI</label>
                        <input type="text" class="form-control" id="edit_phone_display" readonly>
                        <small class="text-muted">Phone number details cannot be changed after creation.</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="update_phone_number_btn">
                        <i class="fa fa-save"></i> Update Phone Number
                    </button>
                </div>
                ' . form_close() . '
            </div>
        </div>
    </div>';
}

hooks()->add_filter('leads_table_columns', 'ai_lead_manager_leads_table_columns');
function ai_lead_manager_leads_table_columns($columns)
{
    array_splice($columns, 9, 0, [
        [
            'name'     => _l('leads_dt_last_call_ended_reason'),
            'th_attrs' => ['class' => 'toggleable', 'id' => 'th-last_call_ended_reason']
        ]
    ]);
    return $columns;
}

hooks()->add_filter('leads_table_sql_columns', 'ai_lead_manager_leads_table_sql_columns');
function ai_lead_manager_leads_table_sql_columns($columns)
{
    array_splice($columns, 9, 0, '(SELECT call_ended_by FROM ' . db_prefix() . 'alm_call_logs WHERE rel_type = "lead" AND rel_id = ' . db_prefix() . 'leads.id ORDER BY id DESC LIMIT 1) as last_call_ended_by');
    return $columns;
}

hooks()->add_filter('leads_table_row_data', 'ai_lead_manager_leads_table_row_data', 10, 2);
function ai_lead_manager_leads_table_row_data($row, $lead)
{
    array_splice($row, 9, 0, alm_format_call_log_status($lead['last_call_ended_by']));

    // Add Make Call button to existing row options in the name column
    if (!empty($lead['phonenumber']) && isset($row[2])) {
        $makeCallAction = ' | <a href="#" class="make-call-btn" data-lead-id="' . $lead['id'] . '" data-toggle="tooltip" title="Make AI Call" onclick="console.log(\'Make call button clicked for lead: ' . $lead['id'] . '\'); return false;"><i class="fa fa-phone"></i> Make Call</a>';

        // Insert the Make Call action before the closing </div> of row-options
        if (strpos($row[2], '</div>') !== false) {
            $row[2] = str_replace('</div>', $makeCallAction . '</div>', $row[2]);
        } else {
            // Fallback: if no row-options div exists, add one
            $row[2] .= '<div class="row-options">' . ltrim($makeCallAction, ' | ') . '</div>';
        }
    }

    return $row;
}

hooks()->add_action('app_init', 'ai_lead_manager_actLib');
function ai_lead_manager_actLib()
{
    $CI = &get_instance();
    $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Envatoapi');
    $envato_res = $CI->envatoapi->validatePurchase(AI_LEAD_MANAGER_MODULE_NAME);
    if (!$envato_res) {
        set_alert('danger', "One of your modules failed its verification and got deactivated. Please reactivate or contact support.");
        redirect(admin_url('modules'));
    }
}

hooks()->add_action('pre_activate_module', 'ai_lead_manager_sidecheck');
function ai_lead_manager_sidecheck($module_name)
{
    if ($module_name['system_name'] == AI_LEAD_MANAGER_MODULE_NAME) {
        if (!option_exists(AI_LEAD_MANAGER_MODULE_NAME . '_verified') && empty(get_option(AI_LEAD_MANAGER_MODULE_NAME . '_verified')) && !option_exists(AI_LEAD_MANAGER_MODULE_NAME . '_verification_id') && empty(get_option(AI_LEAD_MANAGER_MODULE_NAME . '_verification_id'))) {
            $CI = &get_instance();
            $data['submit_url'] = $module_name['system_name'] . '/env_ver/activate';
            $data['original_url'] = admin_url('modules/activate/' . AI_LEAD_MANAGER_MODULE_NAME);
            $data['module_name'] = AI_LEAD_MANAGER_MODULE_NAME;
            $data['title']       = $module_name['headers']['module_name'] . " module activation";
            echo $CI->load->view($module_name['system_name'] . '/activate', $data, true);
            exit();
        }
    }
}

hooks()->add_action('pre_deactivate_module', AI_LEAD_MANAGER_MODULE_NAME . '_deregister');
function ai_lead_manager_deregister($module_name)
{
    if ($module_name['system_name'] == AI_LEAD_MANAGER_MODULE_NAME) {
        $CI = &get_instance();
        $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Envatoapi');
        $CI->envatoapi->deactivateLicense(AI_LEAD_MANAGER_MODULE_NAME);
        delete_option(AI_LEAD_MANAGER_MODULE_NAME . "_verified");
        delete_option(AI_LEAD_MANAGER_MODULE_NAME . "_verification_id");
        delete_option(AI_LEAD_MANAGER_MODULE_NAME . "_last_verification");
        delete_option(AI_LEAD_MANAGER_MODULE_NAME . "_expire_verification");
        if (file_exists(__DIR__ . "/config/token.php")) {
            unlink(__DIR__ . "/config/token.php");
        }
    }
}

hooks()->add_action('register_custom_api_routes', function () {
    register_api_route('ai_lead_manager', 'call_logs', 'GET', function () {
        $CI = &get_instance();
        $CI->load->model(AI_LEAD_MANAGER_MODULE_NAME . '/Call_logs_model', 'call_logs');

        if (!empty($CI->input->get('filters'))) {
            $filters = json_decode($CI->input->get('filters'), true);

            if (!empty($filters['rel_type']) && !empty($filters['rel_id'])) {
                $CI->db->where('rel_type', $filters['rel_type']);
                $CI->db->where('rel_id', $filters['rel_id']);
            }
        }

        $call_logs = $CI->call_logs->get('', ['ai_provider' => get_option('alm_voice_assistant')]);
        foreach ($call_logs as &$call_log) {
            $call_log['transcripts'] = json_decode($call_log['transcripts']);
            $call_log['extra_information'] = json_decode($call_log['extra_information']);
        }

        api_response($call_logs);
    });
});

/**
 * Campaign processing cron job
 * Runs every time the system cron job runs to process pending campaigns
 */
function ai_lead_manager_cronjob()
{
    $CI = &get_instance();

    // Load required models
    $CI->load->model(AI_LEAD_MANAGER_MODULE_NAME . '/Campaigns_model', 'campaigns');

    log_message('info', '[AI Lead Manager Cron] Starting campaign processing');

    try {
        // 1. Process scheduled campaigns that are due
        $ready_campaigns = $CI->campaigns->get_ready_campaigns();

        if (!empty($ready_campaigns)) {
            log_message('info', '[AI Lead Manager Cron] Found ' . count($ready_campaigns) . ' scheduled campaigns ready to start');

            foreach ($ready_campaigns as $campaign) {
                try {
                    // Update status to running
                    $CI->campaigns->update_campaign_status($campaign['id'], 'running');
                    log_message('info', '[AI Lead Manager Cron] Started scheduled campaign: ' . $campaign['name'] . ' (ID: ' . $campaign['id'] . ')');
                } catch (Exception $e) {
                    log_message('error', '[AI Lead Manager Cron] Failed to start scheduled campaign ID ' . $campaign['id'] . ': ' . $e->getMessage());
                }
            }
        }

        // 2. Process running campaigns - make calls for pending numbers
        $running_campaigns = $CI->campaigns->get('', ['status' => 'running']);

        if (!empty($running_campaigns)) {
            log_message('info', '[AI Lead Manager Cron] Processing ' . count($running_campaigns) . ' running campaigns');

            foreach ($running_campaigns as $campaign) {
                try {
                    // Process next call for this campaign
                    ai_lead_manager_process_campaign_calls($campaign);
                } catch (Exception $e) {
                    log_message('error', '[AI Lead Manager Cron] Failed to process campaign ID ' . $campaign['id'] . ': ' . $e->getMessage());
                }
            }
        }

        log_message('info', '[AI Lead Manager Cron] Campaign processing completed successfully');
    } catch (Exception $e) {
        log_message('error', '[AI Lead Manager Cron] Critical error in campaign processing: ' . $e->getMessage());
    }
}

/**
 * Process calls for a specific campaign
 * Handles rate limiting and call processing logic
 */
function ai_lead_manager_process_campaign_calls($campaign)
{
    $CI = &get_instance();

    // Get next pending number for this campaign
    $next_number = $CI->campaigns->get_next_pending_number($campaign['id']);

    if (!$next_number) {
        // No more numbers to process - check if campaign should be completed
        $total_numbers = $CI->campaigns->get_campaign_numbers($campaign['id']);
        $pending_numbers = $CI->campaigns->get_campaign_numbers($campaign['id'], 'pending');

        if (empty($pending_numbers)) {
            // All numbers processed - mark campaign as completed
            $CI->campaigns->update_campaign_status($campaign['id'], 'completed');
            log_message('info', '[AI Lead Manager Cron] Campaign completed: ' . $campaign['name'] . ' (ID: ' . $campaign['id'] . ')');
        }
        return;
    }

    // Check if we should respect rate limiting (e.g., max calls per minute)
    $max_calls_per_minute = get_option('alm_max_calls_per_minute') ?: 10;
    $campaign_id = $campaign['id'];

    // Check recent call activity for rate limiting
    $CI->db->where('campaign_id', $campaign_id);
    $CI->db->where('last_attempt_at >=', date('Y-m-d H:i:s', strtotime('-1 minute')));
    $recent_calls = $CI->db->count_all_results(db_prefix() . 'alm_campaign_numbers');

    if ($recent_calls >= $max_calls_per_minute) {
        log_message('info', '[AI Lead Manager Cron] Rate limit reached for campaign ID ' . $campaign_id . '. Skipping this round.');
        return;
    }

    // Make the call
    try {
        ai_lead_manager_make_campaign_call($campaign, $next_number);
        log_message('info', '[AI Lead Manager Cron] Initiated call for campaign ' . $campaign['name'] . ' to ' . $next_number['phone_number']);
    } catch (Exception $e) {
        // Mark number as failed and log error
        $CI->campaigns->update_campaign_number($next_number['id'], [
            'status' => 'failed',
            'error_message' => $e->getMessage(),
            'last_attempt_at' => date('Y-m-d H:i:s')
        ]);

        log_message('error', '[AI Lead Manager Cron] Failed to make call for campaign ID ' . $campaign_id . ' to ' . $next_number['phone_number'] . ': ' . $e->getMessage());
    }
}

/**
 * Make a campaign call using the appropriate AI provider
 */
function ai_lead_manager_make_campaign_call($campaign, $number_data)
{
    $CI = &get_instance();

    // Mark number as calling
    $CI->campaigns->update_campaign_number($number_data['id'], [
        'status' => 'calling',
        'attempts' => $number_data['attempts'] + 1,
        'last_attempt_at' => date('Y-m-d H:i:s')
    ]);

    // Get current AI provider
    $ai_provider = get_option('alm_voice_assistant');

    // Parse extra data for lead context
    $extra_data = [];
    if (!empty($number_data['extra_data'])) {
        $extra_data = json_decode($number_data['extra_data'], true) ?: [];
    }

    // Prepare lead data
    $lead_data = [
        'name' => $number_data['customer_name'] ?: 'Campaign Lead',
        'email' => $number_data['customer_email'] ?: '',
        'phonenumber' => $number_data['phone_number'],
        'company' => $extra_data['company'] ?? '',
        'address' => $extra_data['address'] ?? '',
        'city' => $extra_data['city'] ?? '',
        'state' => $extra_data['state'] ?? '',
        'country' => $extra_data['country'] ?? '',
        'zip_code' => $extra_data['zip_code'] ?? '',
        'description' => $extra_data['description'] ?? ''
    ];

    // Make the call based on provider
    if ($ai_provider === 'vapi_ai') {
        ai_lead_manager_make_vapi_campaign_call($campaign, $lead_data, $number_data);
    } else {
        ai_lead_manager_make_bland_campaign_call($campaign, $lead_data, $number_data);
    }
}

/**
 * Make VAPI AI campaign call using proper Vapi structure
 */
function ai_lead_manager_make_vapi_campaign_call($campaign, $lead_data, $number_data)
{
    $CI = &get_instance();
    $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Vapi_ai');

    try {
        // Load the VapiAssistantBuilder - proper way to build Vapi assistants
        require_once FCPATH . 'modules/' . AI_LEAD_MANAGER_MODULE_NAME . '/libraries/vapi_ai/VapiAssistantBuilder.php';
        $builder = new \modules\ai_lead_manager\libraries\vapi_ai\VapiAssistantBuilder();

        // Build custom system prompt with campaign context and lead description
        $system_prompt = $campaign['assistant_prompt'] ?: get_option('alm_system_prompt_outbound');

        if (!empty($lead_data)) {
            $system_prompt .= "\n\nLead Information: " . json_encode($lead_data);
        }

        // Add campaign-specific context
        $system_prompt .= "\n\nThis is a campaign call. Campaign: " . $campaign['name'];
        $system_prompt .= "\nDateTime Now: " . date('Y-m-d H:i:s');

        // Prepare first message
        $first_message = $campaign['first_message'] ?: get_option('alm_first_sentence_outbound');

        // Replace placeholders in first message
        $first_message = str_replace(
            ['{name}', '{company}', '{lead_name}', '[name]', '[company]', '[lead_name]'],
            [$lead_data['name'], get_option('invoice_company_name'), $lead_data['name'], $lead_data['name'], get_option('invoice_company_name'), $lead_data['name']],
            $first_message
        );

        // Build assistant configuration using proper VapiAssistantBuilder
        $builder_instance = $builder
            ->setName('Campaign Assistant')
            ->setFirstMessage($first_message)
            ->setTranscriber('deepgram', 'nova-2', 'en-US')
            ->setVoice(
                get_option('vapi_ai_voice_provider'),
                get_option('vapi_ai_agent_voice')
            )
            ->setModel('openai', 'gpt-4o-mini', (float) get_option('vapi_ai_temperature'), (int) get_option('vapi_ai_max_tokens'))
            ->setSystemPrompt($system_prompt)
            ->setEmotionRecognition(get_option('vapi_ai_detect_emotions') == 1)
            ->setFillerInjection(get_option('filler_injection_enabled') == 1)
            ->setBackChannelingEnabled(get_option('back_channeling_enabled') == 1)
            ->setMaxDuration((int) (get_option('vapi_ai_max_duration') ?: 300))
            ->setEndCallFunctionEnabled(get_option('end_call_function_enabled') == 1)
            ->setDialKeypadFunctionEnabled(get_option('dial_keypad_function_enabled') == 1)
            ->setServerUrl(admin_url('ai_lead_manager/webhooks/vapi_ai_campaign'))
            ->setServerMessages(['end-of-call-report'])
            ->setLeadGenerationSchema()
            ->replaceCompanyPlaceholders();

        // Add evaluation settings if enabled - these are part of assistant config, not metadata
        if ($campaign['evaluation_enabled'] && !empty($campaign['evaluation_prompt'])) {
            $builder_instance->setSuccessEvaluationPrompt($campaign['evaluation_prompt']);
        }

        // Add campaign knowledge bases if available
        if (!empty($campaign['knowledge_bases'])) {
            $campaign_kbs = json_decode($campaign['knowledge_bases'], true);
            if ($campaign_kbs && is_array($campaign_kbs)) {
                $builder_instance->addToolIds($campaign_kbs);
            }
        }

        // Build assistant configuration for outbound campaign call
        $assistant_config = $builder_instance->buildForCallType('outbound');

        // Add essential metadata for webhook processing - this is critical for campaign tracking
        $assistant_config['metadata'] = [
            'campaign_id' => $campaign['id'],
            'campaign_number_id' => $number_data['id'],
            'staff_id' => get_staff_user_id(),
            'rel_type' => 'campaign',
            'rel_id' => $campaign['id'],
            'lead_name' => $lead_data['name'],
            'lead_phone' => $lead_data['phonenumber']
        ];

        // Build proper Vapi call request structure
        $call_request_data = [
            'phoneNumberId' => get_option('vapi_ai_selected_phone_number_id'),
            'customer' => [
                'number' => $lead_data['phonenumber']
            ],
            'assistant' => $assistant_config
        ];

        // Make the call using proper Vapi structure
        $response = $CI->vapi_ai->create_call('Campaign Call', $call_request_data);

        if (isset($response['id'])) {
            // Update number with call ID
            $CI->campaigns->update_campaign_number($number_data['id'], [
                'call_id' => $response['id']
            ]);

            log_message('info', '[AI Lead Manager] VAPI campaign call initiated successfully. Call ID: ' . $response['id']);
        } else {
            // Include the request JSON in the error for debugging
            $error_message = 'VAPI campaign call failed. Response: ' . json_encode($response) . ' | Request sent: ' . json_encode($call_request_data);

            $CI->campaigns->update_campaign_number($number_data['id'], [
                'status' => 'failed',
                'error_message' => $error_message
            ]);
            throw new Exception($error_message);
        }
    } catch (Exception $e) {
        // Mark as failed and include JSON request in error message for debugging
        $error_with_json = $e->getMessage();

        // If the error doesn't already contain the request JSON, add it
        if (strpos($error_with_json, 'Request sent:') === false && isset($call_request_data)) {
            $error_with_json .= ' | Request sent: ' . json_encode($call_request_data);
        }

        $CI->campaigns->update_campaign_number($number_data['id'], [
            'status' => 'failed',
            'error_message' => $error_with_json
        ]);

        log_message('error', '[AI Lead Manager] VAPI campaign call failed: ' . $error_with_json);
        throw $e;
    }
}

/**
 * Make Bland AI campaign call
 */
function ai_lead_manager_make_bland_campaign_call($campaign, $lead_data, $number_data)
{
    $CI = &get_instance();
    $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Bland_ai');

    try {
        // Load the CallRequestBuilder
        require_once FCPATH . 'modules/' . AI_LEAD_MANAGER_MODULE_NAME . '/libraries/CallRequestBuilder.php';

        // Build custom task with campaign context and lead description
        $task = $campaign['assistant_prompt'] ?: get_option('alm_system_prompt');

        // Add lead description context if available
        if (!empty($lead_data['description'])) {
            $task .= "\n\nLead Context: " . $lead_data['description'];
        }

        // Add campaign context
        $task .= "\n\nThis is a campaign call for: " . $campaign['name'];
        $task .= "\nDateTime Now: " . date('Y-m-d H:i:s');

        // Prepare first sentence
        $first_sentence = $campaign['first_message'] ?: get_option('alm_first_sentence');
        $first_sentence = str_replace(
            ['{name}', '{company}', '{lead_name}'],
            [$lead_data['name'], get_option('invoice_company_name'), $lead_data['name']],
            $first_sentence
        );

        // Use CallRequestBuilder to build the request
        $builder = \modules\ai_lead_manager\libraries\CallRequestBuilder::forProvider('bland_ai');

        $call_data = $builder
            ->setCustomer($lead_data)
            ->setTask($task)
            ->setModelConfiguration([
                'temperature' => (float) (get_option('bland_ai_temperature') ?: 0.6),
                'max_duration' => (int) (get_option('bland_ai_max_duration') ?: 5)
            ])
            ->setVoiceSettings([
                'voice_id' => get_option('bland_ai_agent_voice')
            ])
            ->setWebhookUrl(admin_url('ai_lead_manager/webhooks/bland_ai_campaign'))
            ->setMetadata([
                'campaign_id' => $campaign['id'],
                'campaign_number_id' => $number_data['id'],
                'lead_data' => json_encode($lead_data),
                'rel_type' => 'campaign',
                'rel_id' => $campaign['id'],
                'first_sentence' => $first_sentence
            ])
            ->configureForLeadGeneration()
            ->addTags(['campaign', 'outbound', $campaign['name']])
            ->setRecording(true)
            ->build();

        // Add first sentence to call data (Bland AI specific)
        $call_data['first_sentence'] = $first_sentence;

        // Make the call
        $response = $CI->bland_ai->send_call($call_data);

        if (isset($response['call_id'])) {
            // Update number with call ID
            $CI->campaigns->update_campaign_number($number_data['id'], [
                'call_id' => $response['call_id']
            ]);

            log_message('info', '[AI Lead Manager] Bland AI call initiated successfully. Call ID: ' . $response['call_id']);
        } else {
            throw new Exception('Bland AI call failed: ' . json_encode($response));
        }
    } catch (Exception $e) {
        // Mark as failed
        $CI->campaigns->update_campaign_number($number_data['id'], [
            'status' => 'failed',
            'error_message' => $e->getMessage()
        ]);

        throw $e;
    }
}
