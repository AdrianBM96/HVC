<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Ai_lead_manager extends AdminController
{
    public function __construct()
    {
        parent::__construct();

        $this->load->library('/Bland_ai');
        $this->load->library('/Vapi_ai');
    }

    /**
     * Retrieves and outputs a list of Bland AI voices in JSON format.
     *
     * This function loads the Bland AI library and fetches the available voices.
     * The voices are then output as a JSON-encoded array.
     */
    public function get_bland_voices()
    {
        $voices = $this->bland_ai->get_voices();
        echo json_encode($voices);
    }

    /**
     * Returns a list of Vapi voices for the given provider.
     *
     * @param string $provider_id The ID of the voice provider.
     */
    public function get_vapi_voices($provider_id)
    {

        $voices = $this->vapi_ai->get_voices($provider_id);
        echo json_encode($voices);
    }

    public function add_knowledgebase($provider = 'bland')
    {
        // Check for file upload errors
        if (!isset($_FILES['file'])) {
            set_alert('danger', 'No file was uploaded');
            redirect(admin_url('settings?group=ai_lead_manager'));
            return;
        }

        $upload_error = $_FILES['file']['error'];

        // Handle different upload errors
        switch ($upload_error) {
            case UPLOAD_ERR_OK:
                break;
            case UPLOAD_ERR_NO_FILE:
                set_alert('danger', 'No file was selected');
                redirect(admin_url('settings?group=ai_lead_manager'));
                return;
            default:
                set_alert('danger', 'File upload failed with error code: ' . $upload_error);
                redirect(admin_url('settings?group=ai_lead_manager'));
                return;
        }

        if (empty($_FILES['file']['tmp_name'])) {
            set_alert('warning', 'No file selected');
            redirect(admin_url('settings?group=ai_lead_manager'));
            return;
        }

        $file_path = $_FILES['file']['tmp_name'];
        $file_name = $_FILES['file']['name'];

        // Validate file type (based on Vapi supported formats)
        $allowed_extensions = ['pdf', 'doc', 'docx', 'txt', 'md', 'csv', 'json', 'xml', 'log', 'tsv', 'yaml', 'yml'];
        $file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (!in_array($file_extension, $allowed_extensions)) {
            set_alert('warning', 'File type not supported. Allowed types: ' . implode(', ', $allowed_extensions));
            redirect(admin_url('settings?group=ai_lead_manager'));
            return;
        }

        if ($provider == 'vapi') {
            $kb_name = $this->input->post('name');
            if (empty($kb_name)) {
                set_alert('warning', 'Knowledge base name is required');
                redirect(admin_url('settings?group=ai_lead_manager'));
                return;
            }

            // Load the VapiKnowledgeBaseBuilder
            require_once FCPATH . 'modules/' . AI_LEAD_MANAGER_MODULE_NAME . '/libraries/vapi_ai/VapiKnowledgeBaseBuilder.php';

            // Step 1: Create knowledge base using builder
            $kb_builder = \modules\ai_lead_manager\libraries\vapi_ai\VapiKnowledgeBaseBuilder::createCustomerSupportKB($kb_name);
            $kb_data = $kb_builder->buildKnowledgeBase();

            $kb_response = $this->vapi_ai->create_knowledgebase($kb_data);

            if (isset($kb_response['error'])) {
                set_alert('danger', 'Failed to create knowledge base: ' . $kb_response['response']['message']);
                redirect(admin_url('settings?group=ai_lead_manager'));
                return;
            }

            if (!isset($kb_response['id'])) {
                set_alert('danger', 'Knowledge base creation failed - no ID returned');
                redirect(admin_url('settings?group=ai_lead_manager'));
                return;
            }

            $kb_id = $kb_response['id'];

            // Step 2: Upload file to Vapi files API first
            $file_response = $this->vapi_ai->upload_file($file_path, $file_name);

            if (isset($file_response['error'])) {
                // Clean up - delete the knowledge base if file upload failed
                $this->vapi_ai->delete_knowledgebase($kb_id);
                set_alert('danger', 'Failed to upload file: ' . $file_response['error']);
                redirect(admin_url('settings?group=ai_lead_manager'));
                return;
            }

            if (!isset($file_response['id'])) {
                $this->vapi_ai->delete_knowledgebase($kb_id);
                set_alert('danger', 'File upload failed - no file ID returned');
                redirect(admin_url('settings?group=ai_lead_manager'));
                return;
            }

            // Step 3: Associate file with knowledge base
            $file_id = $file_response['id'];
            $update_data = ['fileIds' => [$file_id]];

            $update_response = $this->vapi_ai->update_knowledgebase($kb_id, $update_data);

            if (isset($update_response['error'])) {
                // Clean up both KB and file if association fails
                $this->vapi_ai->delete_knowledgebase($kb_id);
                $this->vapi_ai->delete_file($file_id);
                set_alert('danger', 'Failed to associate file with knowledge base: ' . $update_response['error']);
                redirect(admin_url('settings?group=ai_lead_manager'));
                return;
            }

            // Step 4: Create query tool for assistant usage (optional, stored for later use)
            $query_tool = $kb_builder->buildQueryTool([$file_id], "Use this knowledge base when users ask questions related to {$kb_name}");

            // You can store the query tool data for later use with assistants
            // For now, we'll just log it for reference
            log_message('info', 'Created query tool for KB ' . $kb_id . ': ' . json_encode($query_tool));

            $response = ['knowledgeBase' => $kb_response, 'file' => $file_response, 'queryTool' => $query_tool];
        } else if ($provider == 'bland') {
            $response = $this->bland_ai->upload_knowledgebase($file_path, $file_name, $this->input->post('name'), $this->input->post('description'));
        }

        set_alert('success', 'Knowledge base created and file uploaded successfully');
        redirect(admin_url('settings?group=ai_lead_manager'));
    }

    /**
     * Deletes a knowledgebase with the given ID for the given provider.
     *
     * @param string $provider The provider of the knowledgebase. Either 'bland_ai' or 'vapi_ai'.
     * @param int $id The ID of the knowledgebase.
     * @return void
     */
    public function delete_knowledgebase(string $provider, string $id): void
    {
        if ($provider == 'vapi_ai') {
            $response = $this->vapi_ai->delete_tool($id);

            if (isset($response['error'])) {
                set_alert('danger', 'Failed to delete knowledge base: ' . ($response['response']['message'] ?? 'Unknown error'));
            } else {
                set_alert('success', 'Knowledge base deleted successfully');
            }
        } else {
            $this->{$provider}->delete_knowledgebase($id);
            set_alert('success', 'Knowledge base deleted successfully');
        }

        redirect(admin_url('settings?group=ai_lead_manager'));
    }

    /**
     * Upload a file to Vapi for later use in knowledge bases
     */
    public function upload_file(string $provider = 'vapi')
    {
        if (!isset($_FILES['file'])) {
            set_alert('danger', 'No file was uploaded');
            redirect(admin_url('settings?group=ai_lead_manager'));
            return;
        }

        $upload_error = $_FILES['file']['error'];

        if ($upload_error !== UPLOAD_ERR_OK) {
            set_alert('danger', 'File upload failed with error code: ' . $upload_error);
            redirect(admin_url('settings?group=ai_lead_manager'));
            return;
        }

        if (empty($_FILES['file']['tmp_name'])) {
            set_alert('warning', 'No file selected');
            redirect(admin_url('settings?group=ai_lead_manager'));
            return;
        }

        $file_path = $_FILES['file']['tmp_name'];
        $file_name = $_FILES['file']['name'];

        // Validate file type
        $allowed_extensions = ['pdf', 'doc', 'docx', 'txt', 'md', 'csv', 'json', 'xml', 'log', 'tsv', 'yaml', 'yml'];
        $file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (!in_array($file_extension, $allowed_extensions)) {
            set_alert('warning', 'File type not supported. Allowed types: ' . implode(', ', $allowed_extensions));
            redirect(admin_url('settings?group=ai_lead_manager'));
            return;
        }


        if ($provider == 'vapi') {
            $response = $this->vapi_ai->upload_file($file_path, $file_name);

            if (isset($response['error'])) {
                set_alert('danger', 'Failed to upload file: ' . $response['response']['message']);
            } else {
                set_alert('success', 'File "' . $file_name . '" uploaded successfully');
            }
        } else {
            set_alert('danger', 'Unsupported provider for file upload');
        }

        redirect(admin_url('settings?group=ai_lead_manager'));
    }

    /**
     * Create a knowledge base (actually creates a query tool)
     */
    public function create_knowledgebase(string $provider = 'vapi')
    {
        $name = $this->input->post('kb_name');
        $description = $this->input->post('kb_description');
        $selected_files = $this->input->post('selected_files');

        if (empty($name)) {
            set_alert('danger', 'Knowledge base name is required');
            redirect(admin_url('settings?group=ai_lead_manager'));
            return;
        }

        // Validate name format
        if (!preg_match('/^[a-zA-Z][a-zA-Z0-9_]*$/', $name)) {
            set_alert('danger', 'Name must start with a letter and can only contain letters, numbers, and underscore');
            redirect(admin_url('settings?group=ai_lead_manager'));
            return;
        }

        if (empty($selected_files) || !is_array($selected_files)) {
            set_alert('danger', 'Please select at least one file for the knowledge base');
            redirect(admin_url('settings?group=ai_lead_manager'));
            return;
        }

        if ($provider == 'vapi') {
            // Create query tool data structure
            $query_tool = [
                'type' => 'query',
                'function' => [
                    'name' => str_replace(' ', '_', strtolower($name))
                ],
                'knowledgeBases' => [
                    [
                        'provider' => 'google',
                        'name' => str_replace(' ', '-', strtolower($name)) . '-kb',
                        'description' => $description ?: "Use this knowledge base when users ask about {$name}",
                        'fileIds' => $selected_files
                    ]
                ]
            ];

            // Store the tool using Vapi AI library
            $response = $this->vapi_ai->create_tool($query_tool);

            if (isset($response['error'])) {
                set_alert('danger', 'Failed to create knowledge base: ' . $response['response']['message']);
            } else {
                set_alert('success', 'Knowledge base "' . $name . '" created successfully');
            }
        } else {
            set_alert('danger', 'Unsupported provider for knowledge base creation');
        }

        redirect(admin_url('settings?group=ai_lead_manager'));
    }

    /**
     * Update an existing knowledge base (actually updates a query tool)
     */
    public function update_knowledgebase(string $provider = 'vapi')
    {
        $id = $this->input->post('kb_id');
        $name = $this->input->post('kb_name');
        $description = $this->input->post('kb_description');
        $selected_files = $this->input->post('selected_files');

        if (empty($id)) {
            set_alert('danger', 'Knowledge base ID is required');
            redirect(admin_url('settings?group=ai_lead_manager'));
            return;
        }

        if (empty($name)) {
            set_alert('danger', 'Knowledge base name is required');
            redirect(admin_url('settings?group=ai_lead_manager'));
            return;
        }

        // Validate name format
        if (!preg_match('/^[a-zA-Z][a-zA-Z0-9_]*$/', $name)) {
            set_alert('danger', 'Name must start with a letter and can only contain letters, numbers, and underscore');
            redirect(admin_url('settings?group=ai_lead_manager'));
            return;
        }

        if (empty($selected_files) || !is_array($selected_files)) {
            set_alert('danger', 'Please select at least one file for the knowledge base');
            redirect(admin_url('settings?group=ai_lead_manager'));
            return;
        }

        if ($provider == 'vapi') {
            // Create updated query tool data structure
            $query_tool = [
                'type' => 'query',
                'function' => [
                    'name' => str_replace(' ', '_', strtolower($name))
                ],
                'knowledgeBases' => [
                    [
                        'provider' => 'google',
                        'name' => str_replace(' ', '-', strtolower($name)) . '-kb',
                        'description' => $description ?: "Use this knowledge base when users ask about {$name}",
                        'fileIds' => $selected_files
                    ]
                ]
            ];

            // Get current tool to see its structure first
            $current_tool = $this->vapi_ai->get_tool_by_id($id);
            
            // Update the tool using Vapi AI library
            $response = $this->vapi_ai->update_tool($id, $query_tool);

            if (isset($response['error'])) {
                $error_message = 'Unknown error';
                
                // Handle different error response structures
                if (is_string($response['error'])) {
                    $error_message = $response['error'];
                } elseif (isset($response['response']['message'])) {
                    $error_message = $response['response']['message'];
                } elseif (isset($response['response']) && is_array($response['response'])) {
                    $error_message = json_encode($response['response']);
                } else {
                    $error_message = json_encode($response);
                }
                
                // Add debug info
                $debug_info = "Current tool structure: " . json_encode($current_tool) . " | Update data: " . json_encode($query_tool);
                log_message('error', 'VAPI Knowledge Base Update Error: ' . $error_message . ' | ' . $debug_info);
                
                set_alert('danger', 'Failed to update knowledge base: ' . $error_message);
            } else {
                set_alert('success', 'Knowledge base "' . $name . '" updated successfully');
            }
        } else {
            set_alert('danger', 'Unsupported provider for knowledge base update');
        }

        redirect(admin_url('settings?group=ai_lead_manager'));
    }

    /**
     * Get available files for knowledge base creation
     */
    public function get_available_files(string $provider = 'vapi')
    {
        if ($provider == 'vapi') {
            $files = $this->vapi_ai->list_files();

            if (isset($files['error'])) {
                echo json_encode(['error' => 'Failed to load files']);
                return;
            }

            echo json_encode(['success' => true, 'files' => $files]);
        } else {
            echo json_encode(['error' => 'Unsupported provider']);
        }
    }

    /**
     * Delete an uploaded file
     */
    public function delete_file(string $provider, string $id): void
    {
        if ($provider == 'vapi') {
            $response = $this->vapi_ai->delete_file($id);

            if (isset($response['error'])) {
                set_alert('danger', 'Failed to delete file: ' . $response['response']['message']);
            } else {
                set_alert('success', 'File deleted successfully');
            }
        } else {
            set_alert('danger', 'Unsupported provider for file deletion');
        }

        redirect(admin_url('settings?group=ai_lead_manager'));
    }

    /**
     * Make a manual call to a lead with custom task
     */
    public function make_call()
    {
        if ($this->input->is_ajax_request()) {
            $lead_id = $this->input->post('lead_id');
            $custom_task = $this->input->post('custom_task');

            if (!$lead_id) {
                echo json_encode(['success' => false, 'message' => 'Lead ID is required']);
                return;
            }

            $this->load->model('leads_model');
            $lead = $this->leads_model->get($lead_id);

            if (!$lead) {
                echo json_encode(['success' => false, 'message' => 'Lead not found']);
                return;
            }

            if (empty($lead->phonenumber)) {
                echo json_encode(['success' => false, 'message' => 'Lead has no phone number']);
                return;
            }

            // Get the selected voice assistant
            $alm_voice_assistant = get_option('alm_voice_assistant');

            try {
                if ($alm_voice_assistant == 'vapi_ai') {
                    $result = alm_vapi_ai_make_call_manual($lead, $custom_task);
                } else {
                    $result = alm_bland_ai_make_call_manual($lead, $custom_task);
                }


                if (!isset($result['error'])) {
                    echo json_encode(['success' => true, 'message' => 'Call initiated successfully']);
                } else {
                    echo json_encode(['success' => false, 'message' => $result['response']['message']]);
                }
            } catch (Exception $e) {
                echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
            }
        } else {
            show_404();
        }
    }

    /**
     * Get VAPI public key for client-side Web SDK usage
     * VAPI has separate public and private keys - public keys are safe for client-side use
     */
    public function get_vapi_public_key()
    {
        // Only allow AJAX requests
        if (!$this->input->is_ajax_request()) {
            show_404();
            return;
        }

        try {
            // Check if we have a separate public key configured
            $public_key = get_option('vapi_ai_public_key');
            $private_key = get_option('vapi_ai_api_key');

            if (!empty($public_key)) {
                // Use the configured public key (preferred method)
                echo json_encode([
                    'success' => true,
                    'public_key' => $public_key,
                    'key_type' => 'public'
                ]);
                return;
            }

            if (empty($private_key)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'VAPI keys not configured. Please set your public key for web calls or private key for server operations in settings.'
                ]);
                return;
            }

            // Fallback: Try to use private key and warn user
            echo json_encode([
                'success' => true,
                'public_key' => $private_key,
                'key_type' => 'private_fallback',
                'warning' => 'Using private key as fallback. For security, please configure a separate public key for web calls in your VAPI dashboard.'
            ]);
        } catch (Exception $e) {
            echo json_encode([
                'success' => false,
                'message' => 'Error retrieving VAPI key: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Create a new phone number using VAPI
     *
     * @param string $provider The provider type (vapi, etc.)
     */
    public function create_phone_number($provider = 'vapi')
    {
        // Set JSON content type for AJAX responses
        $is_ajax = $this->input->is_ajax_request();
        if ($is_ajax) {
            $this->output->set_content_type('application/json');
        }

        // Only allow POST requests
        if (!$this->input->post()) {
            if ($is_ajax) {
                echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
                return;
            }
            set_alert('danger', 'Invalid request method.');
            redirect(admin_url('settings?group=ai_lead_manager&tab=vapi-phone-numbers'));
            return;
        }

        // Check if user has permission
        if (!is_admin()) {
            if ($is_ajax) {
                echo json_encode(['success' => false, 'message' => 'You do not have permission to create phone numbers.']);
                return;
            }
            set_alert('danger', 'You do not have permission to create phone numbers.');
            redirect(admin_url('settings?group=ai_lead_manager&tab=vapi-phone-numbers'));
            return;
        }

        $phone_number_type = $this->input->post('phone_number_type');

        try {
            $this->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Vapi_ai');
            $vapi_ai = new Vapi_ai();

            $response = null;
            $phone_config = [];

            switch ($phone_number_type) {
                case 'vapi_free':
                    // For free VAPI numbers, provider and area code are required
                    $area_code = $this->input->post('area_code');
                    $phone_config = [
                        'provider' => 'vapi'
                    ];

                    if (!empty($area_code)) {
                        $phone_config['numberDesiredAreaCode'] = $area_code;
                    }

                    // Debug logging
                    log_message('debug', 'VAPI Phone Number Creation Config: ' . json_encode($phone_config));

                    $response = $vapi_ai->create_phone_number($phone_config);
                    break;

                case 'vapi_sip':
                    $sip_identifier = $this->input->post('sip_identifier');

                    if (empty($sip_identifier)) {
                        if ($is_ajax) {
                            echo json_encode(['success' => false, 'message' => 'Please enter a SIP identifier.']);
                            return;
                        }
                        set_alert('danger', 'Please enter a SIP identifier.');
                        redirect(admin_url('settings?group=ai_lead_manager&tab=vapi-phone-numbers'));
                        return;
                    }

                    // Validate identifier length (minimum 8 characters)
                    if (strlen($sip_identifier) < 8) {
                        if ($is_ajax) {
                            echo json_encode(['success' => false, 'message' => 'SIP identifier must be at least 8 characters long.']);
                            return;
                        }
                        set_alert('danger', 'SIP identifier must be at least 8 characters long.');
                        redirect(admin_url('settings?group=ai_lead_manager&tab=vapi-phone-numbers'));
                        return;
                    }

                    // Create the full SIP URI
                    $sip_uri = 'sip:' . $sip_identifier . '@sip.vapi.ai';

                    $phone_config = [
                        'provider' => 'vapi',
                        'sipUri' => $sip_uri
                    ];

                    // Debug logging
                    log_message('debug', 'VAPI SIP Phone Number Creation Config: ' . json_encode($phone_config));

                    $response = $vapi_ai->create_phone_number($phone_config);
                    break;

                case 'byo_sip_trunk':
                    $byo_number = $this->input->post('byo_number');
                    $byo_label = $this->input->post('byo_label');
                    $byo_credential_id = $this->input->post('byo_credential_id');
                    $allow_non_e164 = $this->input->post('allow_non_e164');

                    if (empty($byo_number)) {
                        if ($is_ajax) {
                            echo json_encode(['success' => false, 'message' => 'Please enter a phone number.']);
                            return;
                        }
                        set_alert('danger', 'Please enter a phone number.');
                        redirect(admin_url('settings?group=ai_lead_manager&tab=vapi-phone-numbers'));
                        return;
                    }

                    $phone_config = [
                        'provider' => 'byo-phone-number',
                        'number' => $byo_number,
                        'numberE164CheckEnabled' => empty($allow_non_e164), // Invert logic: unchecked = E164 enabled
                        'name' => !empty($byo_label) ? $byo_label : 'BYO SIP Trunk'
                    ];

                    // Add credential ID if provided
                    if (!empty($byo_credential_id)) {
                        $phone_config['credentialId'] = $byo_credential_id;
                    }

                    // Debug logging
                    log_message('debug', 'BYO SIP Trunk Phone Number Creation Config: ' . json_encode($phone_config));

                    $response = $vapi_ai->create_phone_number($phone_config);
                    break;

                case 'twilio':
                    $twilio_sid = $this->input->post('twilio_account_sid');
                    $twilio_token = $this->input->post('twilio_auth_token');
                    $twilio_number = $this->input->post('twilio_account_number');

                    if (empty($twilio_sid) || empty($twilio_token) || empty($twilio_number)) {
                        if ($is_ajax) {
                            echo json_encode(['success' => false, 'message' => 'Please fill in all Twilio credentials (Account SID, Auth Token, and Phone Number).']);
                            return;
                        }
                        set_alert('danger', 'Please fill in all Twilio credentials (Account SID, Auth Token, and Phone Number).');
                        redirect(admin_url('settings?group=ai_lead_manager&tab=vapi-phone-numbers'));
                        return;
                    }

                    $phone_config = [
                        'provider' => 'twilio',
                        'number' => $twilio_number,
                        'twilioAccountSid' => $twilio_sid,
                        'twilioAuthToken' => $twilio_token,
                        'name' => 'FexCall AI Twilio'
                    ];

                    // Add assistant ID if available
                    $assistant_id = get_option('vapi_ai_assistant_id');
                    if (!empty($assistant_id)) {
                        $phone_config['assistantId'] = $assistant_id;
                    }

                    $response = $vapi_ai->create_phone_number($phone_config);
                    break;

                default:
                    if ($is_ajax) {
                        echo json_encode(['success' => false, 'message' => 'Invalid phone number type selected.']);
                        return;
                    }
                    set_alert('danger', 'Invalid phone number type selected.');
                    redirect(admin_url('settings?group=ai_lead_manager&tab=vapi-phone-numbers'));
                    return;
            }

            // Check if phone number was created successfully
            if (isset($response['id'])) {
                // Store the phone number ID for future reference
                $phone_number_id = $response['id'];

                // Update stored phone number ID if this is the first one
                if (empty(get_option('vapi_ai_phone_number_id'))) {
                    update_option('vapi_ai_phone_number_id', $phone_number_id);
                }

                // Store the actual phone number if provided
                if (isset($response['number'])) {
                    update_option('vapi_phone_number', $response['number']);
                }

                $phone_number = $response['number'] ?? $response['sipUri'] ?? 'Unknown';
                if (isset($response['sipUri'])) {
                    $success_message = "SIP endpoint '{$phone_number}' created successfully!";
                } else {
                    $success_message = "Phone number '{$phone_number}' created successfully!";
                }

                log_message('info', 'VAPI Phone Number Created: ' . json_encode([
                    'type' => $phone_number_type,
                    'phone_id' => $phone_number_id,
                    'number' => $phone_number
                ]));

                if ($is_ajax) {
                    echo json_encode([
                        'success' => true,
                        'message' => $success_message,
                        'phone_number' => $phone_number,
                        'phone_id' => $phone_number_id,
                        'response' => $response
                    ]);
                    return;
                } else {
                    set_alert('success', $success_message);
                }
            } else {
                // Handle API errors
                $error_message = 'Failed to create phone number.';
                if (isset($response['error'])) {
                    $error_message .= ' Error: ' . $response['error'];
                } elseif (isset($response['message'])) {
                    $error_message .= ' Message: ' . $response['message'];
                }

                log_message('error', 'VAPI Phone Number Creation Failed: ' . json_encode($response));

                if ($is_ajax) {
                    echo json_encode([
                        'success' => false,
                        'message' => $error_message,
                        'response' => $response
                    ]);
                    return;
                } else {
                    set_alert('danger', $error_message);
                }
            }

        } catch (Exception $e) {
            $error_message = 'An error occurred while creating the phone number: ' . $e->getMessage();
            log_message('error', 'VAPI Phone Number Creation Exception: ' . $e->getMessage());

            if ($is_ajax) {
                echo json_encode([
                    'success' => false,
                    'message' => $error_message
                ]);
                return;
            } else {
                set_alert('danger', $error_message);
            }
        }

        if (!$is_ajax) {
            redirect(admin_url('settings?group=ai_lead_manager&tab=vapi-phone-numbers'));
        }
    }

    /**
     * Delete a phone number
     */
    public function delete_phone_number($phone_id = null)
    {
        if (!$phone_id) {
            show_404();
        }

        $is_ajax = $this->input->is_ajax_request();

        try {
            // Load VAPI AI library
            $this->load->library('Vapi_ai', null, 'vapi_ai');

            $response = $this->vapi_ai->delete_phone_number($phone_id);

            // Check if the deletion was successful (API returns empty response for successful deletes)
            if (empty($response['error'])) {
                $success_message = 'Phone number deleted successfully.';

                if ($is_ajax) {
                    echo json_encode([
                        'success' => true,
                        'message' => $success_message
                    ]);
                    return;
                } else {
                    set_alert('success', $success_message);
                }
            } else {
                // Handle API errors
                $error_message = 'Failed to delete phone number.';
                if (isset($response['error'])) {
                    $error_message .= ' Error: ' . $response['error'];
                } elseif (isset($response['message'])) {
                    $error_message .= ' Message: ' . $response['message'];
                }

                log_message('error', 'VAPI Phone Number Deletion Failed: ' . json_encode($response));

                if ($is_ajax) {
                    echo json_encode([
                        'success' => false,
                        'message' => $error_message,
                        'response' => $response
                    ]);
                    return;
                } else {
                    set_alert('danger', $error_message);
                }
            }

        } catch (Exception $e) {
            $error_message = 'An error occurred while deleting the phone number: ' . $e->getMessage();
            log_message('error', 'VAPI Phone Number Deletion Exception: ' . $e->getMessage());

            if ($is_ajax) {
                echo json_encode([
                    'success' => false,
                    'message' => $error_message
                ]);
                return;
            } else {
                set_alert('danger', $error_message);
            }
        }

        if (!$is_ajax) {
            redirect(admin_url('settings?group=ai_lead_manager&tab=vapi-phone-numbers'));
        }
    }

    /**
     * Update a phone number
     */
    public function update_phone_number()
    {
        $phone_id = $this->input->post('phone_id');
        $assistant_id = $this->input->post('assistant_id');

        if (!$phone_id) {
            show_404();
        }

        $is_ajax = $this->input->is_ajax_request();

        try {
            // Load VAPI AI library
            $this->load->library('Vapi_ai', null, 'vapi_ai');

            $update_data = [];

            // Handle assistant assignment/removal
            if (!empty($assistant_id)) {
                $update_data['assistantId'] = $assistant_id;
            } else {
                // Remove assistant assignment by setting to null
                $update_data['assistantId'] = null;
            }

            $response = $this->vapi_ai->update_phone_number($phone_id, $update_data);

            // Check if the update was successful
            if (empty($response['error'])) {
                $success_message = 'Phone number updated successfully.';

                if ($is_ajax) {
                    echo json_encode([
                        'success' => true,
                        'message' => $success_message
                    ]);
                    return;
                } else {
                    set_alert('success', $success_message);
                }
            } else {
                // Handle API errors
                $error_message = 'Failed to update phone number.';
                if (isset($response['error'])) {
                    $error_message .= ' Error: ' . $response['error'];
                } elseif (isset($response['message'])) {
                    $error_message .= ' Message: ' . $response['message'];
                }

                log_message('error', 'VAPI Phone Number Update Failed: ' . json_encode($response));

                if ($is_ajax) {
                    echo json_encode([
                        'success' => false,
                        'message' => $error_message,
                        'response' => $response
                    ]);
                    return;
                } else {
                    set_alert('danger', $error_message);
                }
            }

        } catch (Exception $e) {
            $error_message = 'An error occurred while updating the phone number: ' . $e->getMessage();
            log_message('error', 'VAPI Phone Number Update Exception: ' . $e->getMessage());

            if ($is_ajax) {
                echo json_encode([
                    'success' => false,
                    'message' => $error_message
                ]);
                return;
            } else {
                set_alert('danger', $error_message);
            }
        }

        if (!$is_ajax) {
            redirect(admin_url('settings?group=ai_lead_manager&tab=vapi-phone-numbers'));
        }
    }
}
