<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Webhooks extends App_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model(AI_LEAD_MANAGER_MODULE_NAME . '/Call_logs_model', 'call_logs');
        $this->load->model('leads_model');
    }

    /**
     * Handle Bland AI webhook
     *
     * @return void
     */
    public function bland_ai()
    {
        $data = file_get_contents('php://input');
        $data = json_decode($data, TRUE);

        if (empty($data) || empty($data['completed'])) {
            return false;
        }

        $call_log_data = [
            'call_id' => $data['call_id'],
            'to_number' => $data['to'],
            'from_number' => $data['from'],
            'status' => $data['status'],
            'call_length' => $data['call_length'],
            'recording_url' => $data['recording_url'],
            'transcripts' => json_encode($data['transcripts']),
            'summary' => $data['summary'],
            'call_ended_by' => $data['call_ended_by'],
            'direction' => $data['inbound'] ? 0 : 1,
            'price' => $data['price'],
            'rel_type' => $data['metadata']['rel_type'],
            'rel_id' => $data['metadata']['rel_id'],
            'campaign_id' => $data['metadata']['campaign_id'] ?? null, // Support campaign calls
            'staff_id' => $data['metadata']['staff_id'] ?? null,
            'sid' => $data['sid'],
            'twilio_account_sid' => $data['twilio_account_sid'],
            'started_at' => $data['started_at'],
            'ended_at' => $data['end_at'],
            'created_at' => $data['created_at'],
            'ai_provider' => 'bland_ai'
        ];

        foreach ($call_log_data as $key => $value) {
            unset($data[$key]);
        }
        unset($data['metadata'], $data['end_at'], $data['inbound'], $data['from'], $data['to'], $data['type']);

        $call_log_data['extra_information'] = json_encode($data);

        $call_log_id = $this->call_logs->add($call_log_data);

        if ($call_log_id) {
            if ($call_log_data['rel_type'] == 'lead' && $call_log_data['rel_id']) {
                $this->leads_model->update_lead_status([
                    'leadid' => $call_log_data['rel_id'],
                    'status' => get_option('alm_call_completed_status')
                ]);
            }
        }
    }

    /**
     * Handle VAPI.ai webhook for inbound calls
     *
     * @return void
     */
    public function vapi_ai_inbound()
    {
        $data = file_get_contents('php://input');
        $data = json_decode($data, TRUE);

        if (!empty($data) && !empty($data['message']['type'])) {
            if ($data['message']['type'] == 'end-of-call-report') {
                // Load the WebhookDataBuilder
                require_once FCPATH . 'modules/' . AI_LEAD_MANAGER_MODULE_NAME . '/libraries/WebhookDataBuilder.php';

                // Build transformed data using the builder pattern
                $transformedData = \modules\ai_lead_manager\libraries\WebhookDataBuilder::forProvider('vapi_ai')
                    ->fromWebhookPayload($data)
                    ->mapCallData()
                    ->mapLeadData()
                    ->filterEmptyData()
                    ->build();

                // Only proceed if we have valid lead data
                if ($transformedData['isValid']) {
                    // Enhance lead data with system-specific settings
                    $leadData = $transformedData['lead'];
                    $leadData['status'] = get_option('alm_call_completed_status');
                    $leadData['source'] = get_option('alm_lead_source');
                    $leadData['assigned'] = 0;

                    $lead_id = $this->leads_model->add($leadData);

                    if ($lead_id) {
                        // Get call log data and enhance with additional fields
                        $callLogData = $transformedData['callLog'];
                        $callLogData['rel_type'] = 'lead';
                        $callLogData['rel_id'] = $lead_id;
                        $callLogData['direction'] = $data['message']['call']['type'] == 'inboundPhoneCall' ? 0 : 1;
                        $callLogData['sid'] = $data['message']['call']['phoneCallProviderId'] ?? '';
                        $callLogData['twilio_account_sid'] = $data['message']['phoneNumber']['twilioAccountSid'] ?? '';
                        $callLogData['to_number'] = $data['message']['phoneNumber']['number'] ?? '';
                        $callLogData['from_number'] = $data['message']['customer']['number'] ?? '';
                        $callLogData['started_at'] = $data['message']['startedAt'] ?? null;
                        $callLogData['ended_at'] = $data['message']['endedAt'] ?? null;
                        $timestamp = $data['message']['timestamp'] ?? time() * 1000;
                        $callLogData['created_at'] = date('Y-m-d H:i:s', (int) ($timestamp / 1000));
                        $callLogData['ai_provider'] = 'vapi_ai';

                        // Store additional metadata
                        $extraInfo = $data['message'];
                        foreach (['call', 'phoneNumber', 'customer', 'summary', 'cost', 'recordingUrl', 'timestamp', 'endedReason', 'messages', 'durationMinutes', 'startedAt', 'endedAt', 'analysis'] as $key) {
                            unset($extraInfo[$key]);
                        }

                        $callLogData['extra_information'] = json_encode($extraInfo);
                        $call_log_id = $this->call_logs->add($callLogData);
                    }
                }
            }
        }
    }

    /**
     * Handle VAPI.ai webhook for outbound calls
     *
     * @return void
     */
    public function vapi_ai_outbound()
    {
        $data = file_get_contents('php://input');
        $data = json_decode($data, TRUE);

        if (!empty($data) && !empty($data['message']['type'])) {
            if ($data['message']['type'] == 'end-of-call-report') {
                $_data = $data['message'];
                $meta_data = $_data['assistant']['metadata'];

                $call_log_data = [
                    'call_id' => $_data['call']['id'],
                    'to_number' => $_data['customer']['number'],
                    'from_number' => $_data['phoneNumber']['number'],
                    //    'status' => $data['status'],
                    'call_length' => $_data['durationMinutes'],
                    'recording_url' => $_data['recordingUrl'],
                    'transcripts' => json_encode($_data['messages']),
                    'summary' => $_data['summary'],
                    'call_ended_by' => $_data['endedReason'],
                    'direction' => $_data['call']['type'] == 'inboundPhoneCall' ? 0 : 1,
                    'price' => $_data['cost'],
                    'rel_type' => $meta_data['rel_type'],
                    'rel_id' => $meta_data['rel_id'],
                    'campaign_id' => $meta_data['campaign_id'] ?? null, // Support campaign calls
                    'staff_id' => $meta_data['staff_id'],
                    'sid' => $_data['call']['phoneCallProviderId'],
                    'twilio_account_sid' => $_data['phoneNumber']['twilioAccountSid'],
                    'started_at' => $_data['startedAt'],
                    'ended_at' => $_data['endedAt'],
                    'created_at' => date('Y-m-d H:i:s', (int) ($_data['timestamp'] / 1000)),
                    'ai_provider' => 'vapi_ai',
                ];

                foreach (['call', 'phoneNumber', 'customer', 'summary', 'cost', 'recordingUrl', 'timestamp', 'endedReason', 'messages', 'durationMinutes', 'startedAt', 'endedAt'] as $key => $value) {
                    unset($_data[$key]);
                }

                $call_log_data['extra_information'] = json_encode($_data);
                $call_log_id = $this->call_logs->add($call_log_data);

                if ($call_log_id) {
                    if ($call_log_data['rel_type'] == 'lead' && $call_log_data['rel_id']) {
                        $this->leads_model->update_lead_status([
                            'leadid' => $call_log_data['rel_id'],
                            'status' => get_option('alm_call_completed_status')
                        ]);
                    }
                }
            }
        }
    }

    /**
     * Handle VAPI.ai webhook for campaign calls (unified method with all features)
     * Supports evaluation, no-answer handling, retries, and lead qualification
     *
     * @return void
     */
    public function vapi_ai_campaign()
    {
        $data = file_get_contents('php://input');
        $data = json_decode($data, TRUE);

        if (!empty($data) && !empty($data['message']['type'])) {
            if ($data['message']['type'] == 'end-of-call-report') {
                $this->load->model(AI_LEAD_MANAGER_MODULE_NAME . '/campaigns_model', 'campaigns');

                $metadata = $data['message']['assistant']['metadata'] ?? [];
                $campaign_id = $metadata['campaign_id'] ?? null;
                $campaign_number_id = $metadata['campaign_number_id'] ?? null;

                if ($campaign_id && $campaign_number_id) {
                    // Get campaign settings
                    $campaign = $this->campaigns->get($campaign_id);
                    if (!$campaign) {
                        log_message('error', 'Campaign not found: ' . $campaign_id);
                        return;
                    }

                    // Check the call outcome first
                    $endedReason = $data['message']['endedReason'] ?? '';
                    $call_answered = !in_array($endedReason, [
                        'customer-did-not-answer',
                        'customer-busy',
                        'voicemail',
                        'no-answer',
                        'failed'
                    ]);

                    log_message('info', "Campaign call webhook - Call ID: " . ($data['message']['call']['id'] ?? 'unknown') . ", Ended reason: {$endedReason}, Answered: " . ($call_answered ? 'yes' : 'no'));

                    $call_successful = false;
                    $lead_id = null;
                    $evaluation_passed = false;

                    // Only try to create lead if call was answered
                    if ($call_answered) {
                        // Load the WebhookDataBuilder
                        require_once FCPATH . 'modules/' . AI_LEAD_MANAGER_MODULE_NAME . '/libraries/WebhookDataBuilder.php';

                        // Build transformed data using the builder pattern
                        $transformedData = \modules\ai_lead_manager\libraries\WebhookDataBuilder::forProvider('vapi_ai')
                            ->fromWebhookPayload($data)
                            ->mapCallData()
                            ->mapLeadData()
                            ->build();

                        // Handle lead creation based on campaign settings and VAPI's analysis
                        if ($transformedData['isValid']) {
                            // Use VAPI's built-in analysis for evaluation if enabled
                            if ($campaign['evaluation_enabled']) {
                                // Check VAPI's analysis results
                                $vapiAnalysis = $data['message']['analysis'] ?? [];
                                $summary = $data['message']['summary'] ?? '';
                                $callDuration = $data['message']['durationMinutes'] ?? 0;

                                // Use VAPI's sentiment and analysis data for evaluation
                                $evaluation_passed = $this->evaluate_with_vapi_analysis(
                                    $vapiAnalysis,
                                    $summary,
                                    $callDuration,
                                    $campaign['evaluation_prompt']
                                );

                                log_message('info', "Campaign {$campaign_id} VAPI evaluation result: " . ($evaluation_passed ? 'QUALIFIED' : 'NOT_QUALIFIED'));
                            } else {
                                // No evaluation required - all calls create leads
                                $evaluation_passed = true;
                            }

                            // Create lead only if evaluation passed
                            if ($evaluation_passed) {
                                $leadData = $transformedData['lead'];
                                $leadData['status'] = get_option('alm_call_completed_status');
                                $leadData['source'] = get_option('alm_lead_source');
                                $leadData['assigned'] = 0;

                                // Add campaign context and evaluation info to lead description
                                $leadData['description'] = 'Generated from AI Campaign: ' . $campaign['name'];
                                if ($campaign['evaluation_enabled']) {
                                    $leadData['description'] .= ' (VAPI Qualified Lead)';
                                }
                                if (!empty($summary)) {
                                    $leadData['description'] .= "\n\nCall Summary: " . $summary;
                                }
                                $leadData['description'] .= "\n\n" . ($leadData['description'] ?? '');

                                $lead_id = $this->leads_model->add($leadData);
                                $call_successful = (bool) $lead_id;
                            } else {
                                $call_successful = false;
                                log_message('info', "Lead not created for campaign {$campaign_id} - did not pass VAPI evaluation criteria");
                            }
                        }
                    } else {
                        // For unanswered calls, create minimal data structure for call log
                        $transformedData = [
                            'isValid' => false,
                            'callLog' => [
                                'call_id' => $data['message']['call']['id'] ?? '',
                                'call_length' => 0,
                                'recording_url' => null,
                                'transcripts' => null,
                                'summary' => null,
                                'call_ended_by' => $endedReason,
                                'price' => $data['message']['cost'] ?? 0
                            ]
                        ];
                    }

                    // Create call log with enhanced data
                    $callLogData = $transformedData['callLog'];
                    
                    // NEW STRUCTURE: Always set campaign_id for campaign calls
                    $callLogData['campaign_id'] = $campaign_id;
                    
                    // Only set rel_type/rel_id if a lead was actually created
                    if ($lead_id) {
                        $callLogData['rel_type'] = 'lead';
                        $callLogData['rel_id'] = $lead_id;
                    } else {
                        $callLogData['rel_type'] = null;
                        $callLogData['rel_id'] = null;
                    }
                    
                    $callLogData['direction'] = 1; // Outbound
                    $callLogData['sid'] = $data['message']['call']['phoneCallProviderId'] ?? '';
                    $callLogData['twilio_account_sid'] = $data['message']['phoneNumber']['twilioAccountSid'] ?? '';
                    $callLogData['to_number'] = $data['message']['customer']['number'] ?? '';
                    $callLogData['from_number'] = $data['message']['phoneNumber']['number'] ?? '';
                    $callLogData['started_at'] = $data['message']['startedAt'] ?? null;
                    $callLogData['ended_at'] = $data['message']['endedAt'] ?? null;
                    $timestamp = $data['message']['timestamp'] ?? time() * 1000;
                    $callLogData['created_at'] = date('Y-m-d H:i:s', (int) ($timestamp / 1000));
                    $callLogData['ai_provider'] = 'vapi_ai';
                    $callLogData['staff_id'] = $metadata['staff_id'] ?? null;

                    // Store enhanced metadata including evaluation results
                    $extraInfo = $data['message'];
                    $extraInfo['campaign_info'] = [
                        'campaign_id' => $campaign_id,
                        'campaign_name' => $campaign['name'],
                        'campaign_number_id' => $campaign_number_id,
                        'evaluation_enabled' => $campaign['evaluation_enabled'],
                        'evaluation_passed' => $evaluation_passed,
                        'lead_created' => (bool) $lead_id,
                        'custom_prompt_used' => !empty($campaign['assistant_prompt']),
                        'call_answered' => $call_answered,
                        'ended_reason' => $endedReason
                    ];

                    foreach (['call', 'phoneNumber', 'customer', 'summary', 'cost', 'recordingUrl', 'timestamp', 'endedReason', 'messages', 'durationMinutes', 'startedAt', 'endedAt', 'analysis'] as $key) {
                        unset($extraInfo[$key]);
                    }

                    $callLogData['extra_information'] = json_encode($extraInfo);
                    $call_log_id = $this->call_logs->add($callLogData);


                    // Update campaign number status based on call outcome
                    $this->db->where('id', $campaign_number_id);
                    $campaign_number = $this->db->get(db_prefix() . 'alm_campaign_numbers')->row_array();
                    $current_attempts = $campaign_number ? $campaign_number['attempts'] : 0;
                    $max_attempts = $campaign['max_attempts'] ?? 3;

                    $update_data = [
                        'attempts' => $current_attempts + 1,
                        'last_attempt_at' => date('Y-m-d H:i:s'),
                        'call_log_id' => $call_log_id
                    ];

                    if ($call_successful) {
                        // Call was answered and lead was created successfully
                        $update_data['status'] = 'completed';
                        $update_data['completed_at'] = date('Y-m-d H:i:s');
                        $update_data['lead_id'] = $lead_id;
                    } elseif (!$call_answered) {
                        // Customer didn't answer - decide if we should retry
                        if ($current_attempts + 1 >= $max_attempts) {
                            $update_data['status'] = 'failed';
                            $update_data['completed_at'] = date('Y-m-d H:i:s');
                            $update_data['error_message'] = ucfirst(str_replace('-', ' ', $endedReason)) . " after {$max_attempts} attempts";
                        } else {
                            $update_data['status'] = 'pending';
                            $update_data['error_message'] = ucfirst(str_replace('-', ' ', $endedReason)) . " (attempt " . ($current_attempts + 1) . " of {$max_attempts})";
                        }
                    } else {
                        // Call was answered but lead creation failed
                        if ($current_attempts + 1 >= $max_attempts) {
                            $update_data['status'] = 'failed';
                            $update_data['completed_at'] = date('Y-m-d H:i:s');
                            if ($campaign['evaluation_enabled'] && !$evaluation_passed) {
                                $update_data['error_message'] = 'Did not meet lead qualification criteria after ' . $max_attempts . ' attempts';
                            } else {
                                $update_data['error_message'] = 'Failed to create lead from call data after ' . $max_attempts . ' attempts';
                            }
                        } else {
                            $update_data['status'] = 'pending';
                            if ($campaign['evaluation_enabled'] && !$evaluation_passed) {
                                $update_data['error_message'] = 'Did not meet lead qualification criteria (attempt ' . ($current_attempts + 1) . ' of ' . $max_attempts . ')';
                            } else {
                                $update_data['error_message'] = 'Failed to create lead from call data (attempt ' . ($current_attempts + 1) . ' of ' . $max_attempts . ')';
                            }
                        }
                    }

                    $this->campaigns->update_campaign_number($campaign_number_id, $update_data);

                    // Update campaign progress and handle completion
                    $this->update_campaign_progress($campaign_id);
                }
            }
        }
    }


    /**
     * Evaluate call using VAPI's built-in analysis features
     *
     * @param array $vapiAnalysis VAPI's analysis data
     * @param string $summary Call summary
     * @param float $callDuration Duration in minutes
     * @param string $evaluationPrompt Custom evaluation criteria
     * @return bool
     */
    private function evaluate_with_vapi_analysis($vapiAnalysis, $summary, $callDuration, $evaluationPrompt)
    {
        $qualificationScore = 0;

        // 1. Use VAPI's sentiment analysis if available
        if (isset($vapiAnalysis['sentiment'])) {
            $sentiment = strtolower($vapiAnalysis['sentiment']);
            switch ($sentiment) {
                case 'positive':
                    $qualificationScore += 3;
                    break;
                case 'neutral':
                    $qualificationScore += 1;
                    break;
                case 'negative':
                    $qualificationScore -= 2;
                    break;
            }
        }

        // 2. Check VAPI's intent recognition if available
        if (isset($vapiAnalysis['intent'])) {
            $intent = strtolower($vapiAnalysis['intent']);
            $positiveIntents = ['interested', 'purchase', 'inquiry', 'follow_up', 'meeting'];
            $negativeIntents = ['not_interested', 'busy', 'decline', 'remove'];

            if (in_array($intent, $positiveIntents)) {
                $qualificationScore += 2;
            } elseif (in_array($intent, $negativeIntents)) {
                $qualificationScore -= 3;
            }
        }

        // 3. Use VAPI's engagement score if available
        if (isset($vapiAnalysis['engagement_score'])) {
            $engagement = (float) $vapiAnalysis['engagement_score'];
            if ($engagement >= 0.7) {
                $qualificationScore += 2;
            } elseif ($engagement >= 0.4) {
                $qualificationScore += 1;
            } else {
                $qualificationScore -= 1;
            }
        }

        // 4. Check call duration (longer calls usually indicate interest)
        if ($callDuration >= 3) {
            $qualificationScore += 2;
        } elseif ($callDuration >= 1.5) {
            $qualificationScore += 1;
        } elseif ($callDuration < 0.5) {
            $qualificationScore -= 2; // Very short calls are usually not interested
        }

        // 5. Analyze summary for positive/negative indicators
        $summaryText = strtolower($summary);
        $positiveKeywords = [
            'interested',
            'yes',
            'tell me more',
            'sounds good',
            'when can',
            'how much',
            'budget',
            'price',
            'cost',
            'meeting',
            'appointment',
            'follow up',
            'contact',
            'schedule',
            'demo',
            'trial',
            'information'
        ];

        $negativeKeywords = [
            'not interested',
            'no thanks',
            'remove me',
            'stop calling',
            'not now',
            'busy',
            'hang up',
            'goodbye',
            'no money',
            'cant afford',
            'too expensive'
        ];

        foreach ($positiveKeywords as $keyword) {
            if (strpos($summaryText, $keyword) !== false) {
                $qualificationScore += 1;
                break; // Only count once per category
            }
        }

        foreach ($negativeKeywords as $keyword) {
            if (strpos($summaryText, $keyword) !== false) {
                $qualificationScore -= 2;
                break; // Only count once per category
            }
        }

        // 6. Check custom evaluation criteria if provided
        if (!empty($evaluationPrompt)) {
            $criteriaText = strtolower($evaluationPrompt);
            // Check for specific requirements in the evaluation prompt
            if (strpos($criteriaText, 'budget') !== false && strpos($summaryText, 'budget') === false) {
                $qualificationScore -= 1;
            }
            if (strpos($criteriaText, 'meeting') !== false && strpos($summaryText, 'meeting') === false) {
                $qualificationScore -= 1;
            }
            if (strpos($criteriaText, 'interest') !== false && strpos($summaryText, 'interest') === false) {
                $qualificationScore -= 1;
            }
        }

        // 7. Use VAPI's structured analysis if available
        if (isset($vapiAnalysis['qualification'])) {
            $vapiQualification = $vapiAnalysis['qualification'];
            if (isset($vapiQualification['qualified']) && $vapiQualification['qualified'] === true) {
                $qualificationScore += 3;
            } elseif (isset($vapiQualification['qualified']) && $vapiQualification['qualified'] === false) {
                $qualificationScore -= 2;
            }
        }

        log_message('info', "VAPI Evaluation - Score: {$qualificationScore}, Duration: {$callDuration}min, Sentiment: " . ($vapiAnalysis['sentiment'] ?? 'unknown'));

        // Qualification threshold - need positive score to qualify
        return $qualificationScore > 0;
    }


    /**
     * Update campaign progress and handle completion
     *
     * @param int $campaign_id
     */
    private function update_campaign_progress($campaign_id)
    {
        $campaign = $this->campaigns->get($campaign_id);
        if ($campaign && $campaign['status'] === 'running') {
            $stats = $this->campaigns->get_campaign_stats($campaign_id);

            // Update campaign statistics
            $this->campaigns->update($campaign_id, [
                'completed_calls' => $stats['completed'],
                'successful_calls' => $stats['completed'],
                'failed_calls' => $stats['failed']
            ]);

            // Check if campaign is complete (all numbers processed or max attempts reached)
            $total_processed = $stats['completed'] + $stats['failed'];
            $remaining_pending = $stats['pending'];

            if ($total_processed >= $campaign['total_numbers'] || $remaining_pending == 0) {
                $this->campaigns->update_campaign_status($campaign_id, 'completed');
                log_message('info', "Campaign {$campaign_id} completed - Total: {$campaign['total_numbers']}, Processed: {$total_processed}");
            } else {
                // Trigger next call if there are pending numbers
                $this->trigger_next_campaign_call($campaign_id);
            }
        }
    }

    /**
     * Trigger next call in campaign
     */
    private function trigger_next_campaign_call($campaign_id)
    {
        // This could be done via:
        // 1. Direct HTTP call to campaigns/process_next_call
        // 2. Queue system
        // 3. Cron job
        // 
        // For now, we'll make a simple HTTP request

        $webhook_url = admin_url('ai_lead_manager/campaigns/process_next_call/' . $campaign_id);

        // Use cURL to make async request
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $webhook_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 1); // Quick timeout for async
        curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
        curl_exec($ch);
        curl_close($ch);
    }
}
