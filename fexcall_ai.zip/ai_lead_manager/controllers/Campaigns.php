<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Campaigns extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('campaigns_model', 'campaigns');
        $this->load->model('leads_model');
    }

    /**
     * List all campaigns
     */
    public function index()
    {
        if (!has_permission('alm_call_logs', '', 'view')) {
            access_denied('ai_campaign');
        }

        $data['title'] = _l('alm_campaigns');
        $data['campaigns'] = $this->campaigns->get();

        // Get statistics for each campaign
        foreach ($data['campaigns'] as &$campaign) {
            $campaign['stats'] = $this->campaigns->get_campaign_stats($campaign['id']);
            $campaign['progress'] = $campaign['total_numbers'] > 0
                ? round(($campaign['stats']['completed'] + $campaign['stats']['failed']) / $campaign['total_numbers'] * 100, 1)
                : 0;
        }

        $this->load->view('campaigns/manage', $data);
    }

    /**
     * Create new campaign
     */
    public function create()
    {
        if (!has_permission('alm_call_logs', '', 'create')) {
            access_denied('ai_campaign');
        }

        if ($this->input->post()) {
            $this->handle_campaign_creation();
            return;
        }

        $data['title'] = _l('alm_new_campaign');
        $data['ai_provider'] = $this->campaigns->get_current_ai_provider();

        $this->load->view('campaigns/create', $data);
    }

    /**
     * Handle campaign creation from POST data
     */
    private function handle_campaign_creation()
    {
        $campaign_name = $this->input->post('campaign_name');
        $schedule_type = $this->input->post('schedule_type');

        // Validate required fields
        if (empty($campaign_name)) {
            set_alert('danger', 'Campaign name is required');
            redirect(admin_url('ai_lead_manager/campaigns/create'));
            return;
        }

        // Check for CSV file upload
        if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
            set_alert('danger', 'Please upload a valid CSV file with phone numbers');
            redirect(admin_url('ai_lead_manager/campaigns/create'));
            return;
        }

        // Parse CSV file with phone number formatting
        $default_country = $this->input->post('default_country') ?: 'US'; // Allow user to specify default country
        $csv_result = $this->campaigns->parse_csv_file($_FILES['csv_file']['tmp_name'], $default_country);

        if (isset($csv_result['error'])) {
            set_alert('danger', $csv_result['error']);
            redirect(admin_url('ai_lead_manager/campaigns/create'));
            return;
        }
        
        // Show warnings if any
        if (isset($csv_result['warnings']) && !empty($csv_result['warnings'])) {
            $warning_message = 'Import completed with notes: ' . implode('; ', array_slice($csv_result['warnings'], 0, 3));
            if (count($csv_result['warnings']) > 3) {
                $warning_message .= ' and more...';
            }
            set_alert('warning', $warning_message);
        }
        
        // Show phone formatting summary if numbers were formatted
        if (isset($csv_result['phone_formatting_applied']) && $csv_result['phone_formatting_applied'] > 0) {
            set_alert('info', $csv_result['phone_formatting_applied'] . ' phone numbers were automatically formatted to E.164 standard for VAPI compatibility.');
        }

        // Create campaign
        $campaign_data = [
            'name' => $campaign_name,
            'status' => $schedule_type === 'send_now' ? 'running' : 'scheduled',
            'schedule_type' => $schedule_type,
            'total_numbers' => $csv_result['count'],
            'assistant_prompt' => trim($this->input->post('assistant_prompt')) ?: null,
            'first_message' => trim($this->input->post('first_message')) ?: null,
            'max_attempts' => (int) $this->input->post('max_attempts') ?: 3,
            'evaluation_enabled' => (int) $this->input->post('evaluation_enabled') ?: 0,
            'evaluation_prompt' => trim($this->input->post('evaluation_prompt')) ?: null,
            'knowledge_bases' => $this->input->post('knowledge_bases') ? json_encode($this->input->post('knowledge_bases')) : null
        ];

        // Validate evaluation settings
        if ($campaign_data['evaluation_enabled'] && empty($campaign_data['evaluation_prompt'])) {
            set_alert('danger', 'Evaluation prompt is required when lead qualification is enabled');
            redirect(admin_url('ai_lead_manager/campaigns/create'));
            return;
        }

        if ($schedule_type === 'scheduled') {
            $scheduled_date = $this->input->post('scheduled_date');
            $scheduled_time = $this->input->post('scheduled_time');

            if (empty($scheduled_date) || empty($scheduled_time)) {
                set_alert('danger', 'Please provide scheduled date and time');
                redirect(admin_url('ai_lead_manager/campaigns/create'));
                return;
            }

            $campaign_data['scheduled_at'] = $scheduled_date . ' ' . $scheduled_time;
        }

        // Start transaction
        $this->db->trans_start();

        try {
            $campaign_id = $this->campaigns->add($campaign_data);

            if (!$campaign_id) {
                throw new Exception('Failed to create campaign in database');
            }

            log_message('info', 'Campaign created with ID: ' . $campaign_id);

            // Add phone numbers to campaign
            $numbers_added = $this->campaigns->add_campaign_numbers($campaign_id, $csv_result['data']);

            if (!$numbers_added) {
                throw new Exception('Failed to add phone numbers to campaign');
            }

            log_message('info', 'Added ' . $csv_result['count'] . ' numbers to campaign ID: ' . $campaign_id);

            $this->db->trans_commit();

            // Set success message and redirect
            if ($schedule_type === 'send_now') {
                set_alert('success', 'Campaign created successfully with ' . $csv_result['count'] . ' numbers. Status set to running - you can manually process calls from the campaign view.');
            } else {
                set_alert('success', 'Campaign scheduled successfully with ' . $csv_result['count'] . ' numbers.');
            }
            redirect(admin_url('ai_lead_manager/campaigns/view/' . $campaign_id));
        } catch (Exception $e) {
            $this->db->trans_rollback();
            log_message('error', 'Campaign creation failed: ' . $e->getMessage());
            set_alert('danger', 'Campaign creation failed: ' . $e->getMessage());
            redirect(admin_url('ai_lead_manager/campaigns/create'));
        }
    }

    /**
     * Campaigns table - AJAX handler
     */
    public function table()
    {
        if (!has_permission('alm_call_logs', '', 'view')) {
            access_denied('ai_campaign');
        }

        $this->app->get_table_data(module_views_path(AI_LEAD_MANAGER_MODULE_NAME, 'admin/tables/campaigns'));
    }

    /**
     * Campaign numbers table - AJAX handler
     */
    public function campaign_numbers_table($campaign_id)
    {
        if (!has_permission('alm_call_logs', '', 'view')) {
            access_denied('ai_campaign');
        }

        $this->app->get_table_data(module_views_path(AI_LEAD_MANAGER_MODULE_NAME, 'admin/tables/campaign_numbers'), ['campaign_id' => $campaign_id]);
    }

    /**
     * Campaign call logs table - AJAX handler
     */
    public function campaign_call_logs_table($campaign_id)
    {
        if (!has_permission('alm_call_logs', '', 'view')) {
            access_denied('ai_campaign');
        }

        $this->app->get_table_data(module_views_path(AI_LEAD_MANAGER_MODULE_NAME, 'admin/tables/campaign_call_logs'), ['campaign_id' => $campaign_id]);
    }

    /**
     * Complete campaign call logs table - AJAX handler (like main call logs page)
     */
    public function campaign_call_logs_complete_table($campaign_id)
    {
        if (!has_permission('alm_call_logs', '', 'view')) {
            access_denied('ai_campaign');
        }

        $this->app->get_table_data(module_views_path(AI_LEAD_MANAGER_MODULE_NAME, 'admin/tables/campaign_call_logs_complete'), ['campaign_id' => $campaign_id]);
    }

    /**
     * View campaign details
     */
    public function view($id)
    {
        if (!has_permission('alm_call_logs', '', 'view')) {
            access_denied('ai_campaign');
        }

        $data['campaign'] = $this->campaigns->get($id);

        if (!$data['campaign']) {
            show_404();
        }

        $data['title'] = $data['campaign']['name'];
        $data['campaign']['stats'] = $this->campaigns->get_campaign_stats($id);
        $data['campaign']['numbers'] = $this->campaigns->get_campaign_numbers($id);

        // Calculate progress
        $data['campaign']['progress'] = $data['campaign']['total_numbers'] > 0
            ? round(($data['campaign']['stats']['completed'] + $data['campaign']['stats']['failed']) / $data['campaign']['total_numbers'] * 100, 1)
            : 0;

        $this->load->view('campaigns/view', $data);
    }

    /**
     * Start/Resume campaign
     */
    public function start($id)
    {
        if (!has_permission('alm_call_logs', '', 'edit')) {
            access_denied('ai_campaign');
        }

        $campaign = $this->campaigns->get($id);

        if (!$campaign || !in_array($campaign['status'], ['draft', 'paused', 'scheduled'])) {
            set_alert('danger', 'Campaign cannot be started');
            redirect(admin_url('ai_lead_manager/campaigns'));
            return;
        }

        $this->campaigns->update_campaign_status($id, 'running');
        $this->start_campaign_processing($id);

        set_alert('success', 'Campaign started successfully');
        redirect(admin_url('ai_lead_manager/campaigns/view/' . $id));
    }

    /**
     * Pause campaign
     */
    public function pause($id)
    {
        if (!has_permission('alm_call_logs', '', 'edit')) {
            access_denied('ai_campaign');
        }

        $campaign = $this->campaigns->get($id);

        if (!$campaign || $campaign['status'] !== 'running') {
            set_alert('danger', 'Campaign cannot be paused');
            redirect(admin_url('ai_lead_manager/campaigns'));
            return;
        }

        $this->campaigns->update_campaign_status($id, 'paused');

        set_alert('success', 'Campaign paused successfully');
        redirect(admin_url('ai_lead_manager/campaigns/view/' . $id));
    }

    /**
     * Cancel campaign
     */
    public function cancel($id)
    {
        if (!has_permission('alm_call_logs', '', 'delete')) {
            access_denied('ai_campaign');
        }

        $campaign = $this->campaigns->get($id);

        if (!$campaign) {
            set_alert('danger', 'Campaign not found');
            redirect(admin_url('ai_lead_manager/campaigns'));
            return;
        }

        $this->campaigns->update_campaign_status($id, 'cancelled');

        set_alert('success', 'Campaign cancelled successfully');
        redirect(admin_url('ai_lead_manager/campaigns'));
    }

    /**
     * Delete campaign
     */
    public function delete($id)
    {
        if (!has_permission('alm_call_logs', '', 'delete')) {
            access_denied('ai_campaign');
        }

        if ($this->campaigns->delete($id)) {
            set_alert('success', 'Campaign deleted successfully');
        } else {
            set_alert('danger', 'Failed to delete campaign');
        }

        redirect(admin_url('ai_lead_manager/campaigns'));
    }

    /**
     * Process next call in campaign (called via webhook/cron)
     */
    public function process_next_call($campaign_id)
    {
        $campaign = $this->campaigns->get($campaign_id);

        if (!$campaign || $campaign['status'] !== 'running') {
            return;
        }

        $next_number = $this->campaigns->get_next_pending_number($campaign_id);

        if (!$next_number) {
            // No more numbers to process - mark campaign as completed
            $this->campaigns->update_campaign_status($campaign_id, 'completed');
            return;
        }

        // Mark number as calling
        $this->campaigns->update_campaign_number($next_number['id'], [
            'status' => 'calling',
            'attempts' => $next_number['attempts'] + 1,
            'last_attempt_at' => date('Y-m-d H:i:s')
        ]);

        // Make the call based on provider
        $this->make_campaign_call($campaign, $next_number);
    }

    /**
     * Make a call for a campaign number
     */
    private function make_campaign_call($campaign, $number_data)
    {
        // Get current AI provider from options (real-time)
        $ai_provider = $this->campaigns->get_current_ai_provider();

        // Load appropriate AI library
        if ($ai_provider === 'vapi_ai') {
            $this->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Vapi_ai');
            $ai_instance = $this->vapi_ai;
        } else {
            $this->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Bland_ai');
            $ai_instance = $this->bland_ai;
        }

        // Prepare lead data from campaign number
        $lead_data = [
            'name' => $number_data['customer_name'] ?? 'Campaign Lead',
            'email' => $number_data['customer_email'] ?? '',
            'phonenumber' => $number_data['phone_number']
        ];

        // Add extra data if available
        if (!empty($number_data['extra_data'])) {
            $extra_data = json_decode($number_data['extra_data'], true);
            $lead_data = array_merge($lead_data, $extra_data);
        }

        try {
            if ($ai_provider === 'vapi_ai') {
                ai_lead_manager_make_vapi_campaign_call($campaign, $lead_data, $number_data);
            } else {
                $this->make_bland_campaign_call($campaign, $number_data, $lead_data);
            }
        } catch (Exception $e) {
            // Mark as failed
            $this->campaigns->update_campaign_number($number_data['id'], [
                'status' => 'failed',
                'error_message' => $e->getMessage(),
                'completed_at' => date('Y-m-d H:i:s')
            ]);

            log_message('error', 'Campaign call failed: ' . $e->getMessage());
        }
    }

    /**
     * Make Bland AI campaign call
     */
    private function make_bland_campaign_call($campaign, $number_data, $lead_data)
    {
        // Similar implementation for Bland AI
        // This would use BlandAiCallBuilder
        throw new Exception('Bland AI campaign calls not yet implemented');
    }

    /**
     * Start campaign processing (trigger first call)
     */
    private function start_campaign_processing($campaign_id)
    {
        // In a production environment, you might want to:
        // 1. Add to a queue system
        // 2. Use a cron job to process calls
        // 3. Use webhooks to chain calls

        // For now, start the first call immediately
        $this->process_next_call($campaign_id);
    }


    /**
     * Download CSV template
     */
    public function download_template()
    {
        $filename = 'campaign_template.csv';

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        $output = fopen('php://output', 'w');

        // CSV headers
        fputcsv($output, ['phone_number', 'customer_name', 'email', 'company', 'address', 'city', 'state', 'country', 'zip_code', 'description']);

        // Sample data with various phone number formats to demonstrate auto-formatting
        fputcsv($output, ['+1234567890', 'John Doe', 'john@example.com', 'Example Corp', '123 Main St', 'New York', 'NY', 'USA', '10001', 'Interested in our premium services']);
        fputcsv($output, ['(555) 123-4567', 'Jane Smith', 'jane@example.com', 'Test Company', '456 Oak Ave', 'Los Angeles', 'CA', 'USA', '90210', 'Follow-up on previous inquiry about partnership']);
        fputcsv($output, ['555-987-6543', 'Bob Wilson', 'bob@company.com', 'Wilson Inc', '789 Pine St', 'Chicago', 'IL', 'USA', '60601', 'Potential partnership opportunity']);
        
        // Add a comment row explaining phone format flexibility
        fputcsv($output, ['# Phone numbers can be in any format - they will be automatically formatted to E.164 standard for VAPI', '', '', '', '', '', '', '', '', '']);
        fputcsv($output, ['# Supported formats: +1234567890, (555) 123-4567, 555-123-4567, 555.123.4567, etc.', '', '', '', '', '', '', '', '', '']);
        fputcsv($output, ['# If country column is provided, it will be used for formatting. Otherwise, default country is used.', '', '', '', '', '', '', '', '', '']);

        fclose($output);
    }

    /**
     * Get knowledge bases details for display
     */
    public function get_knowledge_bases_details()
    {
        $kb_ids = $this->input->post('kb_ids');
        
        // If no specific IDs provided, return all available knowledge bases
        if (empty($kb_ids)) {
            try {
                // Get all available knowledge bases
                $available_kbs = function_exists('alm_vapi_ai_get_knowledge_base_tools') ? alm_vapi_ai_get_knowledge_base_tools() : [];
                
                $result_kbs = [];
                
                foreach ($available_kbs as $kb) {
                    $kb_info = [
                        'id' => $kb['id'],
                        'name' => $kb['name'] ?? 'Unnamed Knowledge Base',
                        'description' => $kb['knowledgeBases'][0]['description'] ?? '',
                        'file_count' => count($kb['knowledgeBases'][0]['fileIds'] ?? [])
                    ];
                    $result_kbs[] = $kb_info;
                }
                
                echo json_encode([
                    'success' => true, 
                    'data' => $result_kbs
                ]);
                return;
                
            } catch (Exception $e) {
                echo json_encode([
                    'success' => false, 
                    'message' => 'Error fetching all knowledge bases: ' . $e->getMessage()
                ]);
                return;
            }
        }

        // Handle specific KB IDs (existing functionality)
        if (!is_array($kb_ids)) {
            echo json_encode(['success' => false, 'message' => 'Invalid knowledge base IDs provided']);
            return;
        }

        try {
            // Get available knowledge bases
            $available_kbs = function_exists('alm_vapi_ai_get_knowledge_base_tools') ? alm_vapi_ai_get_knowledge_base_tools() : [];
            
            $result_kbs = [];
            
            foreach ($kb_ids as $kb_id) {
                foreach ($available_kbs as $kb) {
                    if ($kb['id'] === $kb_id) {
                        $kb_info = [
                            'id' => $kb['id'],
                            'name' => $kb['name'],
                            'description' => $kb['knowledgeBases'][0]['description'] ?? '',
                            'file_count' => count($kb['knowledgeBases'][0]['fileIds'] ?? [])
                        ];
                        $result_kbs[] = $kb_info;
                        break;
                    }
                }
            }
            
            echo json_encode([
                'success' => true, 
                'knowledge_bases' => $result_kbs
            ]);
            
        } catch (Exception $e) {
            echo json_encode([
                'success' => false, 
                'message' => 'Error fetching knowledge base details: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Retry a specific campaign number
     */
    public function retry_campaign_number()
    {
        if (!has_permission('alm_call_logs', '', 'create')) {
            echo json_encode(['success' => false, 'message' => 'Access denied']);
            return;
        }

        $campaign_number_id = $this->input->post('campaign_number_id');
        
        if (!$campaign_number_id) {
            echo json_encode(['success' => false, 'message' => 'Campaign number ID is required']);
            return;
        }

        try {
            // Get the campaign number details
            $this->db->where('id', $campaign_number_id);
            $campaign_number = $this->db->get(db_prefix() . 'alm_campaign_numbers')->row_array();
            
            if (!$campaign_number) {
                echo json_encode(['success' => false, 'message' => 'Campaign number not found']);
                return;
            }

            // Get the campaign details
            $campaign = $this->campaigns->get($campaign_number['campaign_id']);
            
            if (!$campaign) {
                echo json_encode(['success' => false, 'message' => 'Campaign not found']);
                return;
            }

            // Check if campaign is active
            if (!in_array($campaign['status'], ['running', 'paused'])) {
                echo json_encode(['success' => false, 'message' => 'Campaign must be running or paused to retry numbers']);
                return;
            }

            // Check if number is in a retryable state
            if (!in_array($campaign_number['status'], ['failed', 'pending', 'calling'])) {
                echo json_encode(['success' => false, 'message' => 'Only failed, pending, or calling numbers can be retried']);
                return;
            }

            // Check if max attempts would be exceeded
            $max_attempts = $campaign['max_attempts'] ?? 3;
            if ($campaign_number['attempts'] >= $max_attempts) {
                echo json_encode(['success' => false, 'message' => "This number has already reached the maximum attempts ({$max_attempts})"]);
                return;
            }

            // Reset the campaign number to pending status for retry
            $update_data = [
                'status' => 'pending',
                'error_message' => null,
                'call_id' => null,
                'call_log_id' => null,
                'updated_at' => date('Y-m-d H:i:s')
            ];

            $this->campaigns->update_campaign_number($campaign_number_id, $update_data);

            // Trigger the next call processing if campaign is running
            // Commenting this out for now to isolate the retry issue
            // if ($campaign['status'] === 'running') {
            //     $this->process_next_call($campaign['id']);
            // }

            log_message('info', '[AI Lead Manager] Campaign number ' . $campaign_number_id . ' marked for retry by user ' . get_staff_user_id());

            echo json_encode([
                'success' => true, 
                'message' => 'Campaign number has been reset for retry. ' . 
                    ($campaign['status'] === 'running' ? 'Call will be attempted automatically.' : 'Start the campaign to process the retry.')
            ]);

        } catch (Exception $e) {
            log_message('error', '[AI Lead Manager] Error retrying campaign number: ' . $e->getMessage());
            echo json_encode([
                'success' => false, 
                'message' => 'An error occurred while retrying the campaign number: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Update a campaign number's phone number and customer name
     */
    public function update_campaign_number()
    {
        if (!has_permission('alm_call_logs', '', 'edit')) {
            echo json_encode(['success' => false, 'message' => 'Access denied']);
            return;
        }

        $campaign_number_id = $this->input->post('campaign_number_id');
        $phone_number = $this->input->post('phone_number');
        $customer_name = $this->input->post('customer_name');
        $customer_email = $this->input->post('customer_email');
        $status = $this->input->post('status');
        $attempts = (int)$this->input->post('attempts');
        
        // Extra data fields
        $company = $this->input->post('company');
        $address = $this->input->post('address');
        $city = $this->input->post('city');
        $state = $this->input->post('state');
        $country = $this->input->post('country');
        $zip_code = $this->input->post('zip_code');
        $description = $this->input->post('description');

        if (!$campaign_number_id) {
            echo json_encode(['success' => false, 'message' => 'Campaign number ID is required']);
            return;
        }

        if (!$phone_number) {
            echo json_encode(['success' => false, 'message' => 'Phone number is required']);
            return;
        }

        if (!$customer_name) {
            echo json_encode(['success' => false, 'message' => 'Customer name is required']);
            return;
        }

        // Validate status
        $valid_statuses = ['pending', 'calling', 'completed', 'failed', 'skipped'];
        if ($status && !in_array($status, $valid_statuses)) {
            echo json_encode(['success' => false, 'message' => 'Invalid status value']);
            return;
        }

        // Validate attempts
        if ($attempts < 0 || $attempts > 10) {
            echo json_encode(['success' => false, 'message' => 'Attempts must be between 0 and 10']);
            return;
        }

        try {
            // Load phone number formatter
            $this->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/PhoneNumberFormatter');
            
            // Format phone number to E.164 standard
            $phone_number = trim($phone_number);
            $format_result = PhoneNumberFormatter::formatToE164($phone_number);
            
            if (!$format_result['success']) {
                // Try to get suggestions for correction
                $suggestions = PhoneNumberFormatter::suggestCorrections($phone_number);
                $error_msg = "Invalid phone number format: {$format_result['error']}";
                
                if (!empty($suggestions)) {
                    $error_msg .= " | Try: " . implode(' or ', array_column(array_slice($suggestions, 0, 2), 'suggestion'));
                }
                
                echo json_encode(['success' => false, 'message' => $error_msg]);
                return;
            }
            
            $phone_number = $format_result['formatted'];

            // Validate email if provided
            if ($customer_email && !filter_var($customer_email, FILTER_VALIDATE_EMAIL)) {
                echo json_encode(['success' => false, 'message' => 'Invalid email format']);
                return;
            }

            // Get the campaign number details to verify it exists
            $this->db->where('id', $campaign_number_id);
            $existing_number = $this->db->get(db_prefix() . 'alm_campaign_numbers')->row_array();

            if (!$existing_number) {
                echo json_encode(['success' => false, 'message' => 'Campaign number not found']);
                return;
            }

            // Check if the new phone number already exists in the same campaign
            $this->db->where('campaign_id', $existing_number['campaign_id']);
            $this->db->where('phone_number', $phone_number);
            $this->db->where('id !=', $campaign_number_id);
            $duplicate_check = $this->db->get(db_prefix() . 'alm_campaign_numbers')->row_array();

            if ($duplicate_check) {
                echo json_encode(['success' => false, 'message' => 'This phone number already exists in the campaign']);
                return;
            }

            // Prepare extra_data JSON
            $current_extra_data = json_decode($existing_number['extra_data'], true) ?: [];
            $new_extra_data = array_merge($current_extra_data, array_filter([
                'company' => trim($company),
                'address' => trim($address),
                'city' => trim($city),
                'state' => trim($state),
                'country' => trim($country),
                'zip_code' => trim($zip_code),
                'description' => trim($description)
            ], function($value) {
                return $value !== '';
            }));

            // Update the campaign number
            $update_data = [
                'phone_number' => $phone_number,
                'customer_name' => trim($customer_name),
                'customer_email' => trim($customer_email) ?: null,
                'status' => $status ?: $existing_number['status'],
                'attempts' => $attempts,
                'extra_data' => json_encode($new_extra_data),
                'updated_at' => date('Y-m-d H:i:s')
            ];

            $this->db->where('id', $campaign_number_id);
            $result = $this->db->update(db_prefix() . 'alm_campaign_numbers', $update_data);

            if ($result) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Campaign number updated successfully'
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to update campaign number'
                ]);
            }

        } catch (Exception $e) {
            log_message('error', '[AI Lead Manager] Error updating campaign number: ' . $e->getMessage());
            echo json_encode([
                'success' => false,
                'message' => 'An error occurred while updating the campaign number: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Update campaign details
     */
    public function update_campaign()
    {
        if (!has_permission('alm_call_logs', '', 'edit')) {
            echo json_encode(['success' => false, 'message' => 'Access denied']);
            return;
        }

        $campaign_id = $this->input->post('campaign_id');
        $name = $this->input->post('name');
        $status = $this->input->post('status');
        $max_attempts = (int)$this->input->post('max_attempts');
        $assistant_prompt = $this->input->post('assistant_prompt');
        $first_message = $this->input->post('first_message');
        $knowledge_bases = $this->input->post('knowledge_bases');
        $evaluation_enabled = (int)$this->input->post('evaluation_enabled');
        $evaluation_prompt = $this->input->post('evaluation_prompt');

        if (!$campaign_id) {
            echo json_encode(['success' => false, 'message' => 'Campaign ID is required']);
            return;
        }

        if (!$name) {
            echo json_encode(['success' => false, 'message' => 'Campaign name is required']);
            return;
        }

        // Validate status
        $valid_statuses = ['draft', 'scheduled', 'running', 'paused', 'completed', 'cancelled'];
        if ($status && !in_array($status, $valid_statuses)) {
            echo json_encode(['success' => false, 'message' => 'Invalid status value']);
            return;
        }

        // Validate max_attempts
        if ($max_attempts < 1 || $max_attempts > 10) {
            echo json_encode(['success' => false, 'message' => 'Max attempts must be between 1 and 10']);
            return;
        }

        try {
            // Get existing campaign to verify it exists
            $existing_campaign = $this->campaigns->get($campaign_id);
            if (!$existing_campaign) {
                echo json_encode(['success' => false, 'message' => 'Campaign not found']);
                return;
            }

            // Check if name is already taken by another campaign
            $this->db->where('name', $name);
            $this->db->where('id !=', $campaign_id);
            $name_check = $this->db->get(db_prefix() . 'alm_campaigns')->row_array();
            
            if ($name_check) {
                echo json_encode(['success' => false, 'message' => 'Campaign name already exists']);
                return;
            }

            // Prepare update data
            $update_data = [
                'name' => trim($name),
                'status' => $status ?: $existing_campaign['status'],
                'max_attempts' => $max_attempts,
                'assistant_prompt' => trim($assistant_prompt),
                'first_message' => trim($first_message),
                'knowledge_bases' => $knowledge_bases ?: '[]',
                'evaluation_enabled' => $evaluation_enabled,
                'evaluation_prompt' => trim($evaluation_prompt),
                'updated_at' => date('Y-m-d H:i:s')
            ];

            // Update the campaign
            $this->db->where('id', $campaign_id);
            $result = $this->db->update(db_prefix() . 'alm_campaigns', $update_data);

            if ($result) {
                // Log the update for audit purposes
                log_message('info', '[AI Lead Manager] Campaign updated: ' . $name . ' (ID: ' . $campaign_id . ') by staff ID: ' . get_staff_user_id());
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Campaign "' . $name . '" updated successfully'
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Failed to update campaign'
                ]);
            }

        } catch (Exception $e) {
            log_message('error', '[AI Lead Manager] Error updating campaign: ' . $e->getMessage());
            echo json_encode([
                'success' => false,
                'message' => 'An error occurred while updating the campaign: ' . $e->getMessage()
            ]);
        }
    }
}
