<?php
defined('BASEPATH') or exit('No direct script access allowed');

if (!$CI->db->table_exists(db_prefix() . 'alm_call_logs')) {
    $CI->db->query("CREATE TABLE `" . db_prefix() . "alm_call_logs` (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        call_id CHAR(36) NOT NULL COMMENT 'UUID of the call',
        to_number VARCHAR(15) NOT NULL,
        from_number VARCHAR(15) NOT NULL,
        status VARCHAR(20) NOT NULL,
        call_length FLOAT,
        recording_url TEXT,
        transcripts JSON,
        summary TEXT,
        call_ended_by VARCHAR(50),
        direction TINYINT(1) NOT NULL COMMENT '0 = Inbound, 1 = Outbound',
        price DECIMAL(10, 2) DEFAULT 0.00 COMMENT 'Price of the call in currency',
        extra_information JSON,
        rel_type VARCHAR(50),
        rel_id BIGINT,
        staff_id BIGINT DEFAULT NULL COMMENT 'Staff ID',
        sid VARCHAR(255) DEFAULT NULL,
        twilio_account_sid VARCHAR(255) DEFAULT NULL,
        started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        ended_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        ai_provider VARCHAR(50) NOT NULL COMMENT 'Name of the AI provider (e.g., bland_ai, vapi_ai)'
    );");
}

if (!option_exists('alm_voice_assistant')) {
    add_option('alm_voice_assistant', 'vapi_ai');
}

if (!option_exists('bland_ai_max_duration')) {
    add_option('bland_ai_max_duration', 5);
}

if (!option_exists('bland_ai_agent_voice')) {
    add_option('bland_ai_agent_voice', 'e1289219-0ea2-4f22-a994-c542c2a48a0f');
}

if (!option_exists('bland_ai_temperature')) {
    add_option('bland_ai_temperature', 0.6);
}

if (!option_exists('vapi_ai_max_duration')) {
    add_option('vapi_ai_max_duration', 300);
}

if (!option_exists('vapi_ai_voice_provider')) {
    add_option('vapi_ai_voice_provider', 'openai');
}

if (!option_exists('vapi_ai_agent_voice')) {
    add_option('vapi_ai_agent_voice', 'alloy');
}

if (!option_exists('vapi_ai_temperature')) {
    add_option('vapi_ai_temperature', 1.0);
}

if (!option_exists('vapi_ai_max_tokens')) {
    add_option('vapi_ai_max_tokens', 250);
}

if (!option_exists('vapi_ai_detect_emotions')) {
    add_option('vapi_ai_detect_emotions', 0);
}

if (!option_exists('filler_injection_enabled')) {
    add_option('filler_injection_enabled', 0);
}

if (!option_exists('back_channeling_enabled')) {
    add_option('back_channeling_enabled', 0);
}

if (!option_exists('dial_keypad_function_enabled')) {
    add_option('dial_keypad_function_enabled', 0);
}

if (!option_exists('end_call_function_enabled')) {
    add_option('end_call_function_enabled', 0);
}

if (!option_exists('alm_first_sentence')) {
    add_option('alm_first_sentence', 'Hello, I am AI Lead Manager. How can I help you?');
}

if (!option_exists('vapi_ai_knowledgebase_inbound')) {
    add_option('vapi_ai_knowledgebase_inbound', '[]');
}

if (!option_exists('vapi_ai_knowledgebase_outbound')) {
    add_option('vapi_ai_knowledgebase_outbound', '[]');
}

if (!option_exists('bland_ai_knowledgebase_inbound')) {
    add_option('bland_ai_knowledgebase_inbound', '[]');
}

if (!option_exists('bland_ai_knowledgebase_outbound')) {
    add_option('bland_ai_knowledgebase_outbound', '[]');
}

if (!option_exists('alm_max_calls_per_minute')) {
    add_option('alm_max_calls_per_minute', 10);
}

if (!option_exists('alm_call_completed_status')) {
    add_option('alm_call_completed_status', '');
}

if (!option_exists('vapi_ai_enable_call_forwarding')) {
    add_option('vapi_ai_enable_call_forwarding', 0);
}

// Create campaigns table
if (!$CI->db->table_exists(db_prefix() . 'alm_campaigns')) {
    $CI->db->query("CREATE TABLE `" . db_prefix() . "alm_campaigns` (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        status ENUM('draft', 'scheduled', 'running', 'paused', 'completed', 'cancelled') NOT NULL DEFAULT 'draft',
        total_numbers INT DEFAULT 0,
        completed_calls INT DEFAULT 0,
        successful_calls INT DEFAULT 0,
        failed_calls INT DEFAULT 0,
        schedule_type ENUM('send_now', 'scheduled') NOT NULL DEFAULT 'send_now',
        scheduled_at TIMESTAMP NULL,
        started_at TIMESTAMP NULL,
        completed_at TIMESTAMP NULL,
        assistant_prompt TEXT NULL COMMENT 'Custom assistant prompt for this campaign',
        first_message TEXT NULL COMMENT 'Custom first message to start the conversation',
        max_attempts INT DEFAULT 3 COMMENT 'Maximum call attempts per number',
        evaluation_enabled TINYINT(1) DEFAULT 0 COMMENT 'Enable evaluation before creating leads',
        evaluation_prompt TEXT NULL COMMENT 'Evaluation prompt for qualifying leads',
        knowledge_bases JSON NULL COMMENT 'Selected knowledge base IDs for campaign',
        created_by INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_status (status),
        INDEX idx_created_by (created_by)
    );");
}

// Add new columns to existing campaigns table if they don't exist
if (!$CI->db->field_exists('assistant_prompt', db_prefix() . 'alm_campaigns')) {
    $CI->db->query("ALTER TABLE `" . db_prefix() . "alm_campaigns` 
        ADD COLUMN assistant_prompt TEXT NULL COMMENT 'Custom assistant prompt for this campaign' AFTER completed_at,
        ADD COLUMN first_message TEXT NULL COMMENT 'Custom first message to start the conversation' AFTER assistant_prompt,
        ADD COLUMN max_attempts INT DEFAULT 3 COMMENT 'Maximum call attempts per number' AFTER first_message,
        ADD COLUMN evaluation_enabled TINYINT(1) DEFAULT 0 COMMENT 'Enable evaluation before creating leads' AFTER max_attempts,
        ADD COLUMN evaluation_prompt TEXT NULL COMMENT 'Evaluation prompt for qualifying leads' AFTER evaluation_enabled
    ");
}

// Add knowledge_bases column if it doesn't exist
if (!$CI->db->field_exists('knowledge_bases', db_prefix() . 'alm_campaigns')) {
    $CI->db->query("ALTER TABLE `" . db_prefix() . "alm_campaigns` 
        ADD COLUMN knowledge_bases JSON NULL COMMENT 'Selected knowledge base IDs for campaign' AFTER evaluation_prompt
    ");
}

// Add campaign_id column to call logs table if it doesn't exist
if (!$CI->db->field_exists('campaign_id', db_prefix() . 'alm_call_logs')) {
    $CI->db->query("ALTER TABLE `" . db_prefix() . "alm_call_logs` 
        ADD COLUMN campaign_id BIGINT NULL COMMENT 'Campaign ID for campaign calls' AFTER rel_id,
        ADD INDEX idx_campaign_id (campaign_id)
    ");
}

// Create campaign numbers table
if (!$CI->db->table_exists(db_prefix() . 'alm_campaign_numbers')) {
    $CI->db->query("CREATE TABLE `" . db_prefix() . "alm_campaign_numbers` (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        campaign_id BIGINT NOT NULL,
        phone_number VARCHAR(20) NOT NULL,
        customer_name VARCHAR(255) DEFAULT NULL,
        customer_email VARCHAR(255) DEFAULT NULL,
        status ENUM('pending', 'calling', 'completed', 'failed', 'skipped') NOT NULL DEFAULT 'pending',
        call_id VARCHAR(255) DEFAULT NULL COMMENT 'Provider call ID when call is made',
        call_log_id BIGINT DEFAULT NULL COMMENT 'Reference to alm_call_logs table',
        lead_id BIGINT DEFAULT NULL COMMENT 'Reference to leads table if lead created',
        attempts INT DEFAULT 0,
        last_attempt_at TIMESTAMP NULL,
        completed_at TIMESTAMP NULL,
        error_message TEXT DEFAULT NULL,
        extra_data JSON DEFAULT NULL COMMENT 'Additional customer data from CSV',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (campaign_id) REFERENCES " . db_prefix() . "alm_campaigns(id) ON DELETE CASCADE,
        INDEX idx_campaign_status (campaign_id, status),
        INDEX idx_phone_number (phone_number),
        INDEX idx_status (status)
    );");
}