<?php

/**
 * Retrieve a list of voices from Bland AI.
 *
 * @return array An array of voices, where each voice is an associative array containing the keys 'id' and 'name'.
 */
function alm_bland_ai_get_voices()
{
    $CI = &get_instance();
    $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/bland_ai');
    $response = $CI->bland_ai->get_voices();


    $voices = [];
    if (isset($response['voices'])) {
        foreach ($response['voices'] as $voice) {
            if (!$voice['tags']) continue;

            if (in_array('Bland Curated', $voice['tags'])) {
                if (substr($voice['name'], 0, 6) == 'Public') continue;

                $voice['name'] = ucfirst($voice['name']);
                $voices[] = $voice;
            }
        }
    }


    return $voices;
}

/**
 * Retrieve a list of voice providers.
 *
 * @return array An array of voice providers, where each provider is an associative array containing the keys 'id' and 'name'.
 */
function alm_vapi_ai_get_voice_providers()
{
    $CI = &get_instance();
    $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/vapi_ai');
    return $CI->vapi_ai->get_voice_providers();
}

/**
 * Retrieve a list of voices from Vapi AI.
 *
 * @param string $provider The provider to retrieve voices for. Defaults to 'openai'.
 * @return array An array of voices, where each voice is an associative array containing the keys 'id' and 'name'.
 */
function alm_vapi_ai_get_voices($provider = 'openai')
{
    $CI = &get_instance();
    $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/vapi_ai');
    $response = $CI->vapi_ai->get_voices($provider);

    $voices = [];

    if (!isset($response['error'])) {
        foreach ($response as $voice) {
            $voice['name'] = ucfirst($voice['name']);
            $voices[] = $voice;
        }
    }

    return $voices;
}

/**
 * Retrieve the number of call logs where the specified column equals the specified value.
 *
 * @param string $col_name The column name to query.
 * @param mixed $value The value to query against.
 * @return int The number of call logs matching the specified query.
 */
function get_alm_call_logs_counts($col_name, $value)
{
    $CI = &get_instance();
    return $CI->db->where($col_name, $value)->where('ai_provider', get_option('alm_voice_assistant'))->count_all_results(db_prefix() . 'alm_call_logs');
}

/**
 * Retrieve the number of call logs for the current day or yesterday.
 *
 * If $yesterday is true, the function will return the number of call logs for yesterday.
 * Otherwise, it will return the number of call logs for today.
 *
 * @param bool $yesterday Whether to retrieve the count for yesterday (true) or today (false).
 * @return int The number of call logs for the specified day.
 */
function get_alm_call_logs_total($yesterday = false)
{
    $CI = &get_instance();
    $yesterday_count = $yesterday ? '- INTERVAL 1 DAY' : '';
    return $CI->db->query("SELECT * FROM " . db_prefix() . 'alm_call_logs' . " WHERE DATE(`started_at`) = CURDATE() $yesterday_count AND ai_provider = '" . get_option('alm_voice_assistant') . "'")->num_rows();
}

/**
 * Convert a duration in minutes to a human-readable format.
 *
 * If the duration is less than an hour, the result will be in the format "Xm Ys".
 * If the duration is an hour or more, the result will be in the format "Xh Ym Zs".
 *
 * @param float $duration A duration in minutes to convert.
 * @return string The duration in a human-readable format.
 */
function convert_duration($duration)
{
    // Ensure the input is in minutes (not hours).
    $minutes = floor($duration);  // Get the whole number part (minutes)
    $seconds = round(($duration - $minutes) * 60);  // Get the remaining seconds

    // Format the result.
    if ($minutes >= 60) {
        $hours = floor($minutes / 60);
        $minutes = $minutes % 60;
        return $hours . 'h ' . $minutes . 'm ' . $seconds . 's';
    }

    // If less than an hour, just show minutes and seconds
    return $minutes . 'm ' . $seconds . 's';
}


function alm_bland_ai_get_knowledgebase()
{
    $CI = &get_instance();
    $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/bland_ai');

    $bland_ai = new Bland_ai();

    $response = $bland_ai->list_knowledgebase();

    return (!empty($response['data']['vectors']) ? $response['data']['vectors'] : []);
}

function alm_vapi_ai_get_knowledgebase()
{
    $CI = &get_instance();
    $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/vapi_ai');

    $vapi_ai = new Vapi_ai();

    $response = $vapi_ai->list_knowledgebase();

    return (!isset($response['error']) ? $response : []);
}

function alm_vapi_ai_get_files()
{
    // Keep this for backward compatibility - returns raw files
    return alm_vapi_ai_get_raw_files();
}

function alm_vapi_ai_get_knowledgebase_list()
{
    $CI = &get_instance();
    $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/vapi_ai');

    $vapi_ai = new Vapi_ai();

    // Get knowledge bases for dropdown selections
    $response = $vapi_ai->list_knowledgebase();

    return (!isset($response['error']) ? $response : []);
}

function alm_vapi_ai_get_raw_files()
{
    $CI = &get_instance();
    $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/vapi_ai');

    $vapi_ai = new Vapi_ai();

    // Get raw files for display purposes
    $response = $vapi_ai->list_files();

    return (!isset($response['error']) ? $response : []);
}

function alm_vapi_ai_get_knowledgebase_files($knowledge_base_id)
{
    $CI = &get_instance();
    $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/vapi_ai');

    $vapi_ai = new Vapi_ai();

    $response = $vapi_ai->list_knowledgebase_files($knowledge_base_id);

    return (!isset($response['error']) ? $response : []);
}

function alm_vapi_ai_get_tools()
{
    $CI = &get_instance();
    $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/vapi_ai');

    $vapi_ai = new Vapi_ai();

    $response = $vapi_ai->get_tools();

    if (!isset($response['error'])) {
        $filtered_tools = [];
        foreach ($response as $tool) {
            // Filter out query tools (knowledge base tools)
            if (isset($tool['type']) && ($tool['type'] === 'query' || $tool['type'] === 'transferCall')) {
                continue; // Skip query tools
            }

            if (isset($tool['function']['name'])) {
                $tool['name'] = $tool['function']['name'];
            }
            $filtered_tools[] = $tool;
        }
        return $filtered_tools;
    }

    return [];
}

function alm_vapi_ai_get_knowledge_base_tools()
{
    $CI = &get_instance();
    $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/vapi_ai');

    $vapi_ai = new Vapi_ai();

    $response = $vapi_ai->get_tools();

    if (!isset($response['error'])) {
        $knowledge_base_tools = [];
        foreach ($response as $tool) {
            // Only include query tools (knowledge base tools)
            if (isset($tool['type']) && $tool['type'] === 'query') {
                // Extract knowledge base name from the tool
                if (isset($tool['knowledgeBases'][0]['name'])) {
                    $tool['name'] = $tool['knowledgeBases'][0]['name'];
                } else if (isset($tool['function']['name'])) {
                    $tool['name'] = str_replace('_query', '', $tool['function']['name']);
                }
                $knowledge_base_tools[] = $tool;
            }
        }
        return $knowledge_base_tools;
    }

    return [];
}

function alm_format_bytes($bytes, $precision = 2)
{
    // Define the units of measurement
    $units = ['Bytes', 'KB', 'MB', 'GB', 'TB'];

    // Handle zero bytes
    if ($bytes == 0) {
        return '0 Bytes';
    }

    // Calculate the power to determine the unit
    $power = floor(log($bytes, 1024));
    $power = min($power, count($units) - 1); // Ensure it doesn't exceed the available units

    // Convert bytes to the chosen unit
    $convertedValue = $bytes / pow(1024, $power);

    // Return the formatted string with the appropriate unit
    return round($convertedValue, $precision) . ' ' . $units[$power];
}

function alm_format_call_log_status($reason, $classes = '', $label = true)
{
    if (empty($reason)) return '';

    $statuses = [
        'customer-ended-call' => [
            'name' => 'Customer Ended Call',
            'class' => 'success'
        ],
        'assistant-ended-call' => [
            'name' => 'Assistant Ended Call',
            'class' => 'info'
        ],
        'assistant-said-end-call-phrase' => [
            'name' => 'Assistant Said End Call Phrase',
            'class' => 'default'
        ],
        'assistant-forwarded-call' => [
            'name' => 'Assistant Forwarded Call',
            'class' => 'default'
        ],
        'customer-busy' => [
            'name' => 'Customer Busy',
            'class' => 'warning'
        ],
        'customer-did-not-answer' => [
            'name' => 'Customer Did Not Answer',
            'class' => 'warning'
        ],
        'silence-timed-out' => [
            'name' => 'Silence Timed Out',
            'class' => 'warning'
        ],
        'voicemail' => [
            'name' => 'Voicemail',
            'class' => 'warning'
        ],
        'max-duration-exceeded' => [
            'name' => 'Max Duration Exceeded',
            'class' => 'warning'
        ],
        'customer-did-not-give-microphone-permission' => [
            'name' => 'No Microphone Permission',
            'class' => 'danger'
        ],
        'twilio-failed-to-connect-call' => [
            'name' => 'Twilio Connection Failed',
            'class' => 'danger'
        ],
        'unknown-error' => [
            'name' => 'Unknown Error',
            'class' => 'danger'
        ]
    ];

    if ($label == true) {
        return '<span class="label label-' . $statuses[$reason]['class'] . ' ' . $classes . ' s-status">' . $statuses[$reason]['name'] . '</span>';
    }

    return $statuses[$reason]['name'];
}

/**
 * Make a manual Bland AI call with custom task
 */
function alm_bland_ai_make_call_manual($lead, $custom_task = '')
{
    $CI = &get_instance();
    $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Bland_ai');
    $bland_ai = new Bland_ai();

    if (empty($lead->phonenumber)) {
        return false;
    }

    $request_data = [
        'customer_name' => $lead->name,
        'customer_email' => $lead->email,
        'customer_address' => $lead->address,
        'customer_city' => $lead->city,
        'customer_state' => $lead->state,
        'customer_zip' => $lead->zip,
        'customer_country' => $lead->country,
        'lead_id' => $lead->id,
        'custom_task' => $custom_task
    ];

    // Build outbound call request using simpler approach
    $call_request = [
        'phone_number' => $lead->phonenumber,
        'webhook' => admin_url('ai_lead_manager/webhooks/bland_ai'),
        'request_data' => $request_data,
        'task' => get_option('alm_system_prompt_outbound')
    ];

    // Append custom task if provided
    if (!empty($custom_task)) {
        $call_request['task'] .= "\n\nAdditional Task: " . $custom_task;
    }

    $response = $bland_ai->create_call($call_request);

    return isset($response['call_id']);
}

/**
 * Make a manual Vapi AI call with custom task
 */
function alm_vapi_ai_make_call_manual($lead, $custom_task = '')
{
    $CI = &get_instance();
    $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Vapi_ai');
    $vapi_ai = new Vapi_ai();

    if (empty($lead->phonenumber)) {
        return false;
    }

    // Build outbound call request using VapiAssistantBuilder
    require_once(FCPATH . 'modules/' . AI_LEAD_MANAGER_MODULE_NAME . '/libraries/vapi_ai/VapiAssistantBuilder.php');
    $builder = new \modules\ai_lead_manager\libraries\vapi_ai\VapiAssistantBuilder();

    // Build system prompt with custom task
    $systemPrompt = get_option('alm_system_prompt_outbound');
    if (!empty($custom_task)) {
        $systemPrompt .= "\n\nPrimary Task: " . $custom_task;
    }

    // Build assistant configuration
    $builder_instance = $builder
        ->setName('Outbound AI Assistant - ' . $lead->name)
        ->setFirstMessage(get_option('alm_first_sentence_outbound'))
        ->setTranscriber('deepgram', 'nova-2', 'en-US')
        ->setVoice(
            get_option('vapi_ai_voice_provider'),
            get_option('vapi_ai_agent_voice')
        )
        ->setModel('openai', 'gpt-4o', (float) get_option('vapi_ai_temperature'), (int) get_option('vapi_ai_max_tokens'))
        ->setSystemPrompt($systemPrompt . '\n\n DateTime Now: ' . date('Y-m-d H:i:s'))
        ->setEmotionRecognition(get_option('vapi_ai_detect_emotions') == 1)
        ->setFillerInjection(get_option('filler_injection_enabled') == 1)
        ->setBackChannelingEnabled(get_option('back_channeling_enabled') == 1)
        ->setMaxDuration((int) get_option('vapi_ai_max_duration'))
        ->setEndCallFunctionEnabled(get_option('end_call_function_enabled') == 1)
        ->setDialKeypadFunctionEnabled(get_option('dial_keypad_function_enabled') == 1)
        // ->setServerUrl(admin_url('ai_lead_manager/webhooks/vapi_ai_outbound'))
        ->setServerUrl('https://webhook.site/0d7cec5c-f0f6-4cdd-aaf2-6da59a89858e')
        ->setServerMessages(['end-of-call-report'])
        ->setLeadGenerationSchema()
        ->replaceCompanyPlaceholders();

    // Add outbound knowledge bases if configured
    $outbound_kbs = get_option('vapi_ai_knowledgebase_outbound');
    if (!empty($outbound_kbs)) {
        $kbIds = json_decode($outbound_kbs, true);
        if ($kbIds && is_array($kbIds)) {
            $builder_instance->addToolIds($kbIds);
        }
    }

    // Add outbound tools if configured
    $outbound_tools = get_option('vapi_ai_tools_outbound');
    if (!empty($outbound_tools)) {
        $toolIds = json_decode($outbound_tools, true);
        if ($toolIds && is_array($toolIds)) {
            $builder_instance->addToolIds($toolIds);
        }
    }

    // Add transfer tool if call forwarding is enabled
    if (get_option('vapi_ai_enable_call_forwarding')) {
        $transfer_tool_id = get_option('vapi_ai_transfer_tool_id');
        if (!empty($transfer_tool_id)) {
            $builder_instance->addToolIds([$transfer_tool_id]);
        }
    }

    $call_request_data = [
        'customer' => [
            'number' => $lead->phonenumber
        ],
        'assistant' => $builder_instance,
        'phoneNumberId' => get_option('vapi_ai_selected_phone_number_id')
    ];

    $response = $vapi_ai->create_call('FexCall AI - OutBound Call', $call_request_data);

    return $response;
}

/**
 * Get VAPI AI phone numbers
 *
 * @return array List of phone numbers from VAPI
 */
function alm_vapi_ai_get_phone_numbers()
{
    $CI = &get_instance();

    // Check if API key is available
    $api_key = get_option('vapi_ai_api_key');
    if (empty($api_key)) {
        return [];
    }

    try {
        $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Vapi_ai');
        $vapi_ai = new Vapi_ai();

        $response = $vapi_ai->get_phone_numbers();

        // Check if response is valid and has phone numbers
        if (isset($response['results']) && is_array($response['results'])) {
            return $response['results'];
        } elseif (is_array($response) && !isset($response['error'])) {
            // Handle case where results are directly in response
            return $response;
        } else {
            log_message('error', 'VAPI Phone Numbers API Error: ' . json_encode($response));
            return [];
        }
    } catch (Exception $e) {
        log_message('error', 'VAPI Phone Numbers Exception: ' . $e->getMessage());
        return [];
    }
}

/**
 * Get VAPI AI BYO phone number credentials
 *
 * @return array List of BYO phone number credentials from VAPI
 */
function alm_vapi_ai_get_byo_credentials()
{
    $CI = &get_instance();

    // Check if API key is available
    $api_key = get_option('vapi_ai_api_key');
    if (empty($api_key)) {
        return [];
    }

    try {
        $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Vapi_ai');
        $vapi_ai = new Vapi_ai();

        $response = $vapi_ai->get_byo_phone_credentials();

        // Check if response is valid
        if (is_array($response) && !isset($response['error'])) {
            return $response;
        } else {
            log_message('error', 'VAPI BYO Credentials API Error: ' . json_encode($response));
            return [];
        }
    } catch (Exception $e) {
        log_message('error', 'VAPI BYO Credentials Exception: ' . $e->getMessage());
        return [];
    }
}

/**
 * Get the currently selected phone number details
 *
 * @return array|null Phone number details or null if not found
 */
function alm_vapi_ai_get_selected_phone_number()
{
    $selected_phone_id = get_option('vapi_ai_selected_phone_number_id');
    if (empty($selected_phone_id)) {
        return null;
    }

    $CI = &get_instance();
    $api_key = get_option('vapi_ai_api_key');
    if (empty($api_key)) {
        return null;
    }

    try {
        $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Vapi_ai');
        $vapi_ai = new Vapi_ai();

        $response = $vapi_ai->get_phone_number_by_id($selected_phone_id);

        // Check if response is valid
        if (is_array($response) && !isset($response['error'])) {
            return $response;
        } else {
            log_message('error', 'VAPI Selected Phone Number API Error: ' . json_encode($response));
            return null;
        }
    } catch (Exception $e) {
        log_message('error', 'VAPI Selected Phone Number Exception: ' . $e->getMessage());
        return null;
    }
}

/**
 * Get the current assistant details with status information
 *
 * @return array Assistant details with status information
 */
function alm_vapi_ai_get_assistant_info()
{
    $assistant_id = get_option('vapi_ai_assistant_id');
    $api_key = get_option('vapi_ai_api_key');

    // If no assistant ID, it's a fresh installation
    if (empty($assistant_id)) {
        return [
            'status' => 'no_assistant',
            'message' => 'Save settings to create your AI assistant automatically',
            'id' => null,
            'name' => null
        ];
    }

    // If no API key, can't verify
    if (empty($api_key)) {
        return [
            'status' => 'no_api_key',
            'message' => 'API key required to verify assistant',
            'id' => $assistant_id,
            'name' => null
        ];
    }

    $CI = &get_instance();

    try {
        $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Vapi_ai');
        $vapi_ai = new Vapi_ai();

        $response = $vapi_ai->get_assistant_by_id($assistant_id);

        // Check if assistant was found
        if (is_array($response) && !isset($response['error']) && isset($response['id'])) {
            return [
                'status' => 'found',
                'message' => 'Assistant active and verified',
                'id' => $response['id'],
                'name' => $response['name'] ?? 'Unnamed Assistant',
                'model' => $response['model']['provider'] ?? 'Unknown',
                'createdAt' => $response['createdAt'] ?? null
            ];
        } else {
            // Assistant not found in VAPI
            return [
                'status' => 'not_found',
                'message' => 'Save settings to recreate your AI assistant automatically',
                'id' => $assistant_id,
                'name' => null,
                'error' => $response['error'] ?? 'Assistant not found'
            ];
        }
    } catch (Exception $e) {
        log_message('error', 'VAPI Assistant Info Exception: ' . $e->getMessage());
        return [
            'status' => 'error',
            'message' => 'Error connecting to VAPI',
            'id' => $assistant_id,
            'name' => null,
            'error' => $e->getMessage()
        ];
    }
}

/**
 * Create or update VAPI AI call forwarding tool
 *
 * @param string $forwarding_number Phone number to forward calls to
 * @param string $forwarding_message Message to say before transfer
 * @param bool $is_enabled Whether call forwarding is enabled
 * @return array|false Tool creation/update response or false on failure
 */
function alm_vapi_ai_manage_forwarding_tool($forwarding_number, $forwarding_message = '', $is_enabled = true)
{
    $CI = &get_instance();

    // Check if API key is available
    $api_key = get_option('vapi_ai_api_key');
    if (empty($api_key)) {
        return false;
    }

    try {
        $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Vapi_ai');
        $vapi_ai = new Vapi_ai();

        $existing_tool_id = get_option('vapi_ai_transfer_tool_id');

        // If call forwarding is disabled, delete the existing tool
        if (!$is_enabled) {
            if (!empty($existing_tool_id)) {
                $delete_response = $vapi_ai->delete_tool($existing_tool_id);
                if (!isset($delete_response['error'])) {
                    delete_option('vapi_ai_transfer_tool_id');
                    log_message('info', 'VAPI Transfer Tool Deleted: ' . $existing_tool_id);
                    return ['action' => 'deleted', 'id' => $existing_tool_id];
                } else {
                    log_message('error', 'VAPI Transfer Tool Deletion Failed: ' . json_encode($delete_response));
                }
            }
            return ['action' => 'disabled'];
        }

        // If forwarding is enabled but no number provided, return error
        if (empty($forwarding_number)) {
            log_message('error', 'VAPI Transfer Tool: Forwarding number is required when enabled');
            return false;
        }

        // Default message if not provided
        if (empty($forwarding_message)) {
            $forwarding_message = 'Let me transfer you to our specialist who can better assist you.';
        }

        // Create transfer call tool data
        $tool_data = [
            'destinations' => [
                [
                    'type' => 'number',
                    'number' => $forwarding_number,
                    'message' => $forwarding_message
                ]
            ]
        ];

        // If tool exists, update it; otherwise create new one
        if (!empty($existing_tool_id)) {
            // Update existing tool
            $response = $vapi_ai->update_tool($existing_tool_id, $tool_data);

            if (isset($response['id']) || !isset($response['error'])) {
                log_message('info', 'VAPI Transfer Tool Updated: ' . $existing_tool_id);
                return ['action' => 'updated', 'id' => $existing_tool_id, 'response' => $response];
            } else {
                log_message('error', 'VAPI Transfer Tool Update Failed: ' . json_encode($response));
                // If update failed, try to create a new one
                delete_option('vapi_ai_transfer_tool_id');
                set_alert('danger', 'VAPI Transfer Tool Update Failed: ' . json_encode($response['response']['message']));
                $existing_tool_id = null;
            }
        }

        // Create new tool (either first time or if update failed)
        if (empty($existing_tool_id)) {

            $tool_data['type'] = 'transferCall';
            $response = $vapi_ai->create_tool($tool_data);

            if (isset($response['id'])) {
                // Store the transfer tool ID for future reference
                update_option('vapi_ai_transfer_tool_id', $response['id']);
                log_message('info', 'VAPI Transfer Tool Created: ' . $response['id']);
                return ['action' => 'created', 'id' => $response['id'], 'response' => $response];
            } else {
                log_message('error', 'VAPI Transfer Tool Creation Failed: ' . json_encode($response));
                return false;
            }
        }
    } catch (Exception $e) {
        log_message('error', 'VAPI Transfer Tool Management Exception: ' . $e->getMessage());
        return false;
    }

    return false;
}

/**
 * Get list of phone numbers from Bland.ai
 *
 * @return array List of phone numbers from Bland.ai (both regular and BYOT)
 */
function alm_bland_ai_get_phone_numbers()
{
    $CI = &get_instance();

    // Check if we have API key
    $api_key = get_option('bland_ai_api_key');
    if (empty($api_key)) {
        return [];
    }

    $all_numbers = [];

    try {
        $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Bland_ai');
        $bland_ai = new Bland_ai();

        // Get regular Bland.ai inbound numbers
        $inbound_response = $bland_ai->get_inbound_numbers();

        if (isset($inbound_response['inboundNumbers']) && is_array($inbound_response['inboundNumbers'])) {
            foreach ($inbound_response['inboundNumbers'] as $number) {
                $number['type'] = 'bland_ai';  // Mark as regular Bland.ai number
                $all_numbers[] = $number;
            }
        }

        // Get BYOT numbers if encrypted key exists
        $byot_response = $bland_ai->get_byot_numbers();
        if (isset($byot_response['data']) && is_array($byot_response['data'])) {

            // Get all BYOT phone numbers for status check
            $byot_phone_numbers = [];
            foreach ($byot_response['data'] as $number) {
                if (!empty($number['phone_number'])) {
                    $byot_phone_numbers[] = $number['phone_number'];
                }
            }

            // Check status of all BYOT numbers at once
            $status_results = [];
            if (!empty($byot_phone_numbers)) {
                $status_response = $bland_ai->check_byot_numbers($byot_phone_numbers);
                if (isset($status_response['data']['results']) && is_array($status_response['data']['results'])) {
                    foreach ($status_response['data']['results'] as $result) {
                        $status_results[$result['phone_number']] = $result;
                    }
                }
            }

            foreach ($byot_response['data'] as $number) {
                // BYOT numbers have different structure
                $phone_number = $number['phone_number'] ?? '';
                $status_info = $status_results[$phone_number] ?? null;

                $formatted_number = [
                    'phone_number' => $phone_number,
                    'created_at' => $number['created_at'] ?? '',
                    'type' => 'byot',  // Mark as BYOT number
                    'name' => 'BYOT Number',
                    'id' => $number['id'] ?? '',
                    'label' => $number['label'] ?? '',
                    // Copy other relevant fields
                    'prompt' => $number['prompt'] ?? '',
                    'pathway_id' => $number['pathway_id'] ?? '',
                    // Add status information
                    'status_check' => $status_info,
                    'exists_in_twilio' => $status_info['exists'] ?? false,
                    'status_error' => $status_info['error'] ?? null,
                    'status_message' => $status_info['message'] ?? null,
                ];

                if (!empty($formatted_number['phone_number'])) {
                    $all_numbers[] = $formatted_number;
                }
            }
        }

        return $all_numbers;
    } catch (Exception $e) {
        log_message('error', 'Bland.ai get phone numbers exception: ' . $e->getMessage());
        return [];
    }
}

/**
 * Get selected phone number details from Bland.ai
 *
 * @return array|null Phone number details or null if not found
 */
function alm_bland_ai_get_selected_phone_number()
{
    $selected_phone_id = get_option('bland_ai_selected_phone_number_id');
    if (empty($selected_phone_id)) {
        return null;
    }

    $phone_numbers = alm_bland_ai_get_phone_numbers();

    foreach ($phone_numbers as $phone) {
        // Check by phone number (which is the main identifier for Bland.ai)
        if (isset($phone['phone_number']) && $phone['phone_number'] == $selected_phone_id) {
            return $phone;
        }
        // Also check other possible identifier fields
        if (isset($phone['number']) && $phone['number'] == $selected_phone_id) {
            return $phone;
        }
    }

    return null;
}

/**
 * Check BYOT phone numbers status in Twilio account
 *
 * @param array $phone_numbers Array of phone numbers to check
 * @return array Check results
 */
function alm_bland_ai_check_byot_numbers($phone_numbers)
{
    $CI = &get_instance();

    // Check if we have API key and encrypted key
    $api_key = get_option('bland_ai_api_key');
    $encrypted_key = get_option('bland_ai_encrypted_key');

    if (empty($api_key) || empty($encrypted_key)) {
        return ['error' => 'API key or encrypted key missing for BYOT check'];
    }

    if (empty($phone_numbers) || !is_array($phone_numbers)) {
        return ['error' => 'No phone numbers provided for check'];
    }

    try {
        $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Bland_ai');
        $bland_ai = new Bland_ai();

        $response = $bland_ai->check_byot_numbers($phone_numbers);

        if (isset($response['data'])) {
            return $response['data'];
        }

        return $response;
    } catch (Exception $e) {
        log_message('error', 'Bland.ai check BYOT numbers exception: ' . $e->getMessage());
        return ['error' => 'Exception: ' . $e->getMessage()];
    }
}

/**
 * Find the correct encrypted key for a BYOT phone number
 *
 * @param string $phone_number The phone number to find the key for
 * @return string|null The encrypted key ID or null if not found
 */
function alm_bland_ai_find_encrypted_key_for_number($phone_number)
{
    $CI = &get_instance();

    // Check if we have API key
    $api_key = get_option('bland_ai_api_key');
    if (empty($api_key)) {
        return null;
    }

    try {
        $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/Bland_ai');
        $bland_ai = new Bland_ai();

        // Get all encrypted keys
        $keys_response = $bland_ai->get_encrypted_keys();
        if (!isset($keys_response['data']) || !is_array($keys_response['data'])) {
            log_message('error', 'Bland.ai get encrypted keys failed: ' . json_encode($keys_response));
            return null;
        }

        // Check each encrypted key to find which one contains our phone number
        foreach ($keys_response['data'] as $key_data) {
            $encrypted_key = $key_data['id'] ?? '';
            if (empty($encrypted_key)) {
                continue;
            }

            // Get Twilio numbers for this key
            $twilio_response = $bland_ai->get_twilio_numbers($encrypted_key);
            if (isset($twilio_response['data']) && is_array($twilio_response['data'])) {
                // Check if our phone number is in this key's numbers
                if (in_array($phone_number, $twilio_response['data'])) {
                    log_message('info', 'Found encrypted key for ' . $phone_number . ': ' . $encrypted_key);
                    return $encrypted_key;
                }
            }
        }

        log_message('info', 'No encrypted key found for phone number: ' . $phone_number);
        return null;
    } catch (Exception $e) {
        log_message('error', 'Bland.ai find encrypted key exception: ' . $e->getMessage());
        return null;
    }
}

/**
 * Auto-detect and set the correct encrypted key for a selected BYOT phone number
 *
 * @param string $selected_phone_number The selected phone number
 * @return bool True if key was found and set, false otherwise
 */
function alm_bland_ai_auto_set_encrypted_key($selected_phone_number)
{
    // Only process if the selected number looks like a BYOT number (starts with +)
    if (empty($selected_phone_number) || !str_starts_with($selected_phone_number, '+')) {
        return false;
    }

    // Check if this is a BYOT number by trying to find its encrypted key
    $encrypted_key = alm_bland_ai_find_encrypted_key_for_number($selected_phone_number);

    if (!empty($encrypted_key)) {
        // Store the found encrypted key
        update_option('bland_ai_encrypted_key', $encrypted_key);
        log_message('info', 'Auto-set encrypted key for BYOT number ' . $selected_phone_number . ': ' . $encrypted_key);
        return true;
    }

    return false;
}
