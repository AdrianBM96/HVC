<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Campaigns_model extends App_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Get campaigns with optional filtering
     *
     * @param array $where
     * @return array
     */
    public function get($id = '', $where = [])
    {
        if (is_numeric($id)) {
            $this->db->where('id', $id);
            return $this->db->get(db_prefix() . 'alm_campaigns')->row_array();
        }

        if (!empty($where)) {
            $this->db->where($where);
        }

        $this->db->order_by('created_at', 'DESC');
        return $this->db->get(db_prefix() . 'alm_campaigns')->result_array();
    }

    /**
     * Add new campaign
     *
     * @param array $data
     * @return int|bool
     */
    public function add($data)
    {
        $data['created_by'] = get_staff_user_id();
        $data['created_at'] = date('Y-m-d H:i:s');

        $result = $this->db->insert(db_prefix() . 'alm_campaigns', $data);
        
        if (!$result) {
            log_message('error', 'Failed to insert campaign into database: ' . $this->db->error()['message']);
            return false;
        }

        $insert_id = $this->db->insert_id();

        if ($insert_id) {
            log_activity('New AI Campaign Added [ID: ' . $insert_id . ', Name: ' . $data['name'] . ']');
        } else {
            log_message('error', 'Campaign insert succeeded but no insert ID returned');
        }

        return $insert_id;
    }

    /**
     * Update campaign
     *
     * @param int $id
     * @param array $data
     * @return bool
     */
    public function update($id, $data)
    {
        $this->db->where('id', $id);
        $result = $this->db->update(db_prefix() . 'alm_campaigns', $data);

        if ($result) {
            log_activity('AI Campaign Updated [ID: ' . $id . ']');
        }

        return $result;
    }

    /**
     * Delete campaign and all associated numbers
     *
     * @param int $id
     * @return bool
     */
    public function delete($id)
    {
        $campaign = $this->get($id);
        if (!$campaign) {
            return false;
        }

        // Delete associated campaign numbers (CASCADE should handle this)
        $this->db->where('campaign_id', $id);
        $this->db->delete(db_prefix() . 'alm_campaign_numbers');

        // Delete campaign
        $this->db->where('id', $id);
        $result = $this->db->delete(db_prefix() . 'alm_campaigns');

        if ($result) {
            log_activity('AI Campaign Deleted [ID: ' . $id . ', Name: ' . $campaign['name'] . ']');
        }

        return $result;
    }

    /**
     * Add numbers to campaign from CSV data
     *
     * @param int $campaign_id
     * @param array $numbers_data
     * @return bool
     */
    public function add_campaign_numbers($campaign_id, $numbers_data)
    {
        if (empty($numbers_data)) {
            log_message('error', 'No numbers data provided for campaign ID: ' . $campaign_id);
            return false;
        }

        $this->db->trans_start();

        $inserted_count = 0;
        foreach ($numbers_data as $number_data) {
            // Build extra_data with all optional fields
            $extra_data = [
                'email' => $number_data['email'] ?? null,
                'company' => $number_data['company'] ?? null,
                'address' => $number_data['address'] ?? null,
                'city' => $number_data['city'] ?? null,
                'state' => $number_data['state'] ?? null,
                'country' => $number_data['country'] ?? null,
                'zip_code' => $number_data['zip_code'] ?? null,
                'description' => $number_data['description'] ?? null
            ];
            
            // Remove null values from extra_data
            $extra_data = array_filter($extra_data, function($value) {
                return $value !== null;
            });

            $insert_data = [
                'campaign_id' => $campaign_id,
                'phone_number' => $number_data['phone_number'],
                'customer_name' => $number_data['customer_name'],
                'customer_email' => $number_data['email'] ?? null,
                'extra_data' => !empty($extra_data) ? json_encode($extra_data) : null,
                'created_at' => date('Y-m-d H:i:s')
            ];

            $result = $this->db->insert(db_prefix() . 'alm_campaign_numbers', $insert_data);
            if ($result) {
                $inserted_count++;
            } else {
                log_message('error', 'Failed to insert campaign number: ' . $number_data['phone_number'] . ' - ' . $this->db->error()['message']);
            }
        }

        if ($inserted_count === 0) {
            log_message('error', 'No campaign numbers were inserted for campaign ID: ' . $campaign_id);
            $this->db->trans_rollback();
            return false;
        }

        // Update campaign total numbers
        $total_numbers = $inserted_count;
        $this->db->where('id', $campaign_id);
        $update_result = $this->db->update(db_prefix() . 'alm_campaigns', ['total_numbers' => $total_numbers]);
        
        if (!$update_result) {
            log_message('error', 'Failed to update campaign total numbers for ID: ' . $campaign_id);
            $this->db->trans_rollback();
            return false;
        }

        $this->db->trans_complete();

        $status = $this->db->trans_status();
        if (!$status) {
            log_message('error', 'Transaction failed for adding campaign numbers to ID: ' . $campaign_id);
        } else {
            log_message('info', 'Successfully added ' . $inserted_count . ' numbers to campaign ID: ' . $campaign_id);
        }

        return $status;
    }

    /**
     * Get campaign numbers
     *
     * @param int $campaign_id
     * @param string $status
     * @return array
     */
    public function get_campaign_numbers($campaign_id, $status = '')
    {
        $this->db->where('campaign_id', $campaign_id);
        
        if (!empty($status)) {
            $this->db->where('status', $status);
        }

        $this->db->order_by('created_at', 'ASC');
        return $this->db->get(db_prefix() . 'alm_campaign_numbers')->result_array();
    }

    /**
     * Update campaign number status
     *
     * @param int $number_id
     * @param array $data
     * @return bool
     */
    public function update_campaign_number($number_id, $data)
    {
        $this->db->where('id', $number_id);
        return $this->db->update(db_prefix() . 'alm_campaign_numbers', $data);
    }

    /**
     * Get next pending number for campaign
     *
     * @param int $campaign_id
     * @return array|null
     */
    public function get_next_pending_number($campaign_id)
    {
        $this->db->where('campaign_id', $campaign_id);
        $this->db->where('status', 'pending');
        $this->db->order_by('created_at', 'ASC');
        $this->db->limit(1);

        return $this->db->get(db_prefix() . 'alm_campaign_numbers')->row_array();
    }

    /**
     * Get campaign statistics
     *
     * @param int $campaign_id
     * @return array
     */
    public function get_campaign_stats($campaign_id)
    {
        // Basic campaign numbers stats
        $this->db->select('
            COUNT(*) as total_contacts,
            SUM(CASE WHEN status = "pending" THEN 1 ELSE 0 END) as pending,
            SUM(CASE WHEN status = "calling" THEN 1 ELSE 0 END) as calling,
            SUM(CASE WHEN status = "completed" THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN status = "failed" THEN 1 ELSE 0 END) as failed,
            SUM(CASE WHEN status = "skipped" THEN 1 ELSE 0 END) as skipped,
            SUM(CASE WHEN attempts > 1 THEN 1 ELSE 0 END) as rescheduled_attempts
        ');
        $this->db->where('campaign_id', $campaign_id);
        $basic_stats = $this->db->get(db_prefix() . 'alm_campaign_numbers')->row_array();
        
        // Get call outcome statistics from call logs using the new campaign_id column
        $this->db->select('
            COUNT(*) as total_calls,
            SUM(CASE WHEN call_length > 0 THEN 1 ELSE 0 END) as answered_calls,
            SUM(CASE WHEN call_length = 0 OR call_length IS NULL THEN 1 ELSE 0 END) as unanswered_calls,
            AVG(CASE WHEN call_length > 0 THEN call_length END) as avg_call_duration,
            SUM(price) as total_cost
        ');
        $this->db->where('campaign_id', $campaign_id);
        $call_stats = $this->db->get(db_prefix() . 'alm_call_logs')->row_array();
        
        // Merge statistics
        $stats = array_merge($basic_stats, $call_stats ?: [
            'total_calls' => 0,
            'answered_calls' => 0,
            'unanswered_calls' => 0,
            'avg_call_duration' => 0,
            'total_cost' => 0
        ]);
        
        // Calculate success rate (answered calls / total calls made)
        $total_calls = (int) $stats['total_calls'];
        $answered_calls = (int) $stats['answered_calls'];
        $stats['success_rate'] = $total_calls > 0 ? round(($answered_calls / $total_calls) * 100, 1) : 0;
        
        // Calculate completion rate (completed / total contacts)
        $total_contacts = (int) $stats['total_contacts'];
        $completed = (int) $stats['completed'];
        $stats['completion_rate'] = $total_contacts > 0 ? round(($completed / $total_contacts) * 100, 1) : 0;
        
        // Ensure all fields are properly typed
        $stats['total_contacts'] = (int) $stats['total_contacts'];
        $stats['pending'] = (int) $stats['pending'];
        $stats['calling'] = (int) $stats['calling'];
        $stats['completed'] = (int) $stats['completed'];
        $stats['failed'] = (int) $stats['failed'];
        $stats['skipped'] = (int) $stats['skipped'];
        $stats['rescheduled_attempts'] = (int) $stats['rescheduled_attempts'];
        $stats['answered_calls'] = (int) $stats['answered_calls'];
        $stats['unanswered_calls'] = (int) $stats['unanswered_calls'];
        $stats['avg_call_duration'] = round((float) $stats['avg_call_duration'], 1);
        $stats['total_cost'] = round((float) $stats['total_cost'], 2);
        
        return $stats;
    }

    /**
     * Update campaign status
     *
     * @param int $campaign_id
     * @param string $status
     * @return bool
     */
    public function update_campaign_status($campaign_id, $status)
    {
        $data = ['status' => $status];

        if ($status === 'running' && !$this->get($campaign_id)['started_at']) {
            $data['started_at'] = date('Y-m-d H:i:s');
        }

        if (in_array($status, ['completed', 'cancelled'])) {
            $data['completed_at'] = date('Y-m-d H:i:s');
        }

        return $this->update($campaign_id, $data);
    }

    /**
     * Get campaigns that are ready to process (scheduled campaigns that are due)
     *
     * @return array
     */
    public function get_ready_campaigns()
    {
        $this->db->where('status', 'scheduled');
        $this->db->where('scheduled_at <=', date('Y-m-d H:i:s'));
        
        return $this->db->get(db_prefix() . 'alm_campaigns')->result_array();
    }

    /**
     * Get current AI provider from options
     *
     * @return string
     */
    public function get_current_ai_provider()
    {
        return get_option('alm_voice_assistant');
    }

    /**
     * Get current phone number from options
     *
     * @return string
     */
    public function get_current_phone_number()
    {
        return get_option('twilio_account_number');
    }

    /**
     * Get current assistant ID from options based on provider
     *
     * @return string
     */
    public function get_current_assistant_id()
    {
        $provider = $this->get_current_ai_provider();
        
        if ($provider === 'vapi_ai') {
            return get_option('vapi_ai_assistant_id');
        }
        
        return 'default'; // For Bland AI or other providers
    }

    /**
     * Parse CSV file and return phone numbers data
     * Required fields: phone_number, customer_name
     * Optional fields: email, company, address, city, state, country, zip_code, description
     *
     * @param string $file_path
     * @param string $default_country Default country for phone formatting (optional)
     * @return array
     */
    public function parse_csv_file($file_path, $default_country = 'US')
    {
        if (!file_exists($file_path)) {
            return ['error' => 'File not found'];
        }

        // Load phone number formatter
        $CI = &get_instance();
        $CI->load->library(AI_LEAD_MANAGER_MODULE_NAME . '/PhoneNumberFormatter');

        $numbers_data = [];
        $headers = [];
        $row_count = 0;
        $errors = [];
        $phone_format_warnings = [];

        if (($handle = fopen($file_path, 'r')) !== FALSE) {
            while (($data = fgetcsv($handle, 5000, ',')) !== FALSE) {
                if ($row_count === 0) {
                    // First row is headers
                    $headers = array_map('trim', $data);
                    $headers = array_map('strtolower', $headers);
                    
                    // Check required headers
                    $required_fields = ['phone_number', 'customer_name'];
                    $missing_fields = [];
                    
                    foreach ($required_fields as $field) {
                        if (!in_array($field, $headers)) {
                            $missing_fields[] = $field;
                        }
                    }
                    
                    if (!empty($missing_fields)) {
                        return ['error' => 'Missing required columns: ' . implode(', ', $missing_fields) . '. Required: phone_number, customer_name'];
                    }
                } else {
                    // Data rows
                    if (count($data) >= count($headers)) {
                        $row_data = array_combine($headers, $data);
                        
                        // Validate required fields
                        $phone_number_raw = trim($row_data['phone_number'] ?? '');
                        $customer_name = trim($row_data['customer_name'] ?? '');
                        
                        if (empty($phone_number_raw)) {
                            $errors[] = "Row " . ($row_count + 1) . ": phone_number is required";
                            $row_count++;
                            continue;
                        }
                        
                        if (empty($customer_name)) {
                            $errors[] = "Row " . ($row_count + 1) . ": customer_name is required";
                            $row_count++;
                            continue;
                        }

                        // Format phone number to E.164 standard
                        $country_from_data = strtoupper(trim($row_data['country'] ?? ''));
                        $format_country = !empty($country_from_data) ? $country_from_data : $default_country;
                        
                        $phone_format_result = PhoneNumberFormatter::formatToE164($phone_number_raw, $format_country);
                        
                        if (!$phone_format_result['success']) {
                            // Only reject if it's truly unusable (very rare now with lenient formatter)
                            $errors[] = "Row " . ($row_count + 1) . ": Cannot process phone number '{$phone_number_raw}' - {$phone_format_result['error']}";
                            $row_count++;
                            continue;
                        }
                        
                        $phone_number = $phone_format_result['formatted'];
                        
                        // Add formatting info to warnings if number was significantly modified
                        if ($phone_number !== $phone_number_raw) {
                            $original_digits = preg_replace('/[^\d]/', '', $phone_number_raw);
                            $formatted_digits = preg_replace('/[^\d]/', '', $phone_number);
                            
                            // Only show warning if digits were actually changed (not just formatting)
                            if ($original_digits !== substr($formatted_digits, -strlen($original_digits))) {
                                $phone_format_warnings[] = "Row " . ($row_count + 1) . ": '{$phone_number_raw}' auto-corrected to '{$phone_number}'";
                            } else {
                                $phone_format_warnings[] = "Row " . ($row_count + 1) . ": '{$phone_number_raw}' formatted to '{$phone_number}'";
                            }
                        }

                        // Build number entry with required fields
                        $number_entry = [
                            'phone_number' => $phone_number,
                            'customer_name' => $customer_name,
                            'email' => trim($row_data['email'] ?? '') ?: null,
                            'company' => trim($row_data['company'] ?? '') ?: null,
                            'address' => trim($row_data['address'] ?? '') ?: null,
                            'city' => trim($row_data['city'] ?? '') ?: null,
                            'state' => trim($row_data['state'] ?? '') ?: null,
                            'country' => trim($row_data['country'] ?? '') ?: null,
                            'zip_code' => trim($row_data['zip_code'] ?? '') ?: null,
                            'description' => trim($row_data['description'] ?? '') ?: null
                        ];

                        $numbers_data[] = $number_entry;
                    } else {
                        $errors[] = "Row " . ($row_count + 1) . ": insufficient data columns";
                    }
                }
                $row_count++;
            }
            fclose($handle);
        }

        if (empty($numbers_data)) {
            $error_message = 'No valid records found in CSV.';
            if (!empty($errors)) {
                $error_message .= ' Errors: ' . implode('; ', array_slice($errors, 0, 5));
                if (count($errors) > 5) {
                    $error_message .= ' and ' . (count($errors) - 5) . ' more errors.';
                }
            }
            return ['error' => $error_message];
        }

        $result = ['success' => true, 'data' => $numbers_data, 'count' => count($numbers_data)];
        
        // Combine errors and phone format warnings
        $all_warnings = array_merge($errors, $phone_format_warnings);
        
        if (!empty($all_warnings)) {
            $result['warnings'] = array_slice($all_warnings, 0, 15); // Show more warnings since phone formatting is important
            if (count($all_warnings) > 15) {
                $result['warnings'][] = 'And ' . (count($all_warnings) - 15) . ' more messages...';
            }
        }
        
        // Add phone formatting summary
        if (!empty($phone_format_warnings)) {
            $result['phone_formatting_applied'] = count($phone_format_warnings);
        }

        return $result;
    }
}